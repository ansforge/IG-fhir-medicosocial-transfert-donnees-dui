# TDDUI PP PA Task Action 2 IDE Example - Médicosocial - Transfert de données DUI v2.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI PP PA Task Action 2 IDE Example**

## Example Task: TDDUI PP PA Task Action 2 IDE Example

Profil: [TDDUI Task Action](StructureDefinition-tddui-task-action.md)

**identifier**: `https://identifiant-medicosocial-action.esante.gouv.fr`/3480787529/123456789-ACTI-12342

**basedOn**: [CarePlan Projet personnalisé de Hugo en IME](CarePlan-tddui-pp-ime-careplan-example.md)

**status**: In Progress

**intent**: plan

**description**: Pesée mensuelle et dépistage dénutrition

**owner**: [Practitioner Élodie Bernard ](Practitioner-tddui-pp-pa-practitioner-ide-example.md)

> **input****type**: Titre de l'action à mener.**value**: Action de l'IDE pour atteindre l'objectif 2

> **input****type**: Objectif(s).**value**: [Goal : extension = ->CarePlan Projet personnalisé de Mme Jeanne L.; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1235; lifecycleStatus = active; description = ; note = Objectif 2](Goal-tddui-pp-pa-goal-objectif-2-example.md)



## Resource Content

```json
{
  "resourceType" : "Task",
  "id" : "tddui-pp-pa-task-action-2-ide-example",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"]
  },
  "identifier" : [{
    "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
    "value" : "3480787529/123456789-ACTI-12342"
  }],
  "basedOn" : [{
    "reference" : "CarePlan/tddui-pp-ime-careplan-example"
  }],
  "status" : "in-progress",
  "intent" : "plan",
  "description" : "Pesée mensuelle et dépistage dénutrition",
  "owner" : {
    "reference" : "Practitioner/tddui-pp-pa-practitioner-ide-example"
  },
  "input" : [{
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-action",
        "code" : "titre"
      }]
    },
    "valueString" : "Action de l'IDE pour atteindre l'objectif 2"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-action",
        "code" : "objectif"
      }]
    },
    "valueReference" : {
      "reference" : "Goal/tddui-pp-pa-goal-objectif-2-example"
    }
  }]
}

```

# Mapping FHIR du modèle de contenu DUI - Médicosocial - Transfert de données DUI v2.2.0-ballot

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Mapping FHIR du modèle de contenu DUI**

## Mapping FHIR du modèle de contenu DUI

 Ce mapping représente les données fonctionnelles trouvant leur équivalence dans l'actuelle version des spécifications techniques. 

### Mapping Usager

### Mapping Entité Juridique

### Mapping Professionnel

### Mapping Sejour

### Mapping Evènement

### Mapping Transport

### Mapping Evaluation

### Vue globale du Projet Personnalisé

#### Mapping Projet Personnalisé

##### Mapping Accord

#### Mapping Besoin

#### Mapping Objectif

#### Mapping MoyenRessource

#### Mapping Action

#### Mapping Prestation

#### Mapping Attente

#### Mapping Bilan


# TDDUI Patient INS Example - Médicosocial - Transfert de données DUI v2.4.0

## Example Patient: TDDUI Patient INS Example

-------

**English**

-------

Profile: [TDDUI Patient INS](StructureDefinition-tddui-patient-ins.md)

DUPONT Male, DoB: 1947-04-03 ( Patient internal identifier: 3480787529/194704032)

-------

| | |
| :--- | :--- |
| Other Ids: | * NIR définitif/147720425367411 (use: official, )
* Driver's license number/822146819 (, period: 1980-01-01 --> (ongoing))
 |
| Alt. Name: | Jean DUPONT (Official) |
| Contact Detail | 12 rue des Lilas 76748 99100 (home) |
| [Patient Birth Place](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-birthPlace.html) | Mazoires FRA |
| TDDUI Household Situation: | * familySituation: Seul
 |
| FR Core Patient Ident Reliability Extension: | * identityStatus: [FR Core CodeSystem v2-0445: VALI](https://hl7.fr/ig/fhir/core/2.1.0/CodeSystem-fr-core-cs-v2-0445.html#fr-core-cs-v2-0445-VALI) (Identité validée)
 |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "tddui-patient-ins-example",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "identityStatus",
      "valueCoding" : {
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0445",
        "code" : "VALI"
      }
    }],
    "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/patient-birthPlace",
    "valueAddress" : {
      "extension" : [{
        "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-address-insee-code",
        "valueCoding" : {
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R13-CommuneOM/FHIR/TRE-R13-CommuneOM",
          "code" : "63220"
        }
      }],
      "city" : "Mazoires",
      "country" : "FRA"
    }
  },
  {
    "extension" : [{
      "url" : "familySituation",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R317-SituationVieQuotidienne/FHIR/TRE-R317-SituationVieQuotidienne",
          "code" : "01",
          "display" : "Seul"
        }]
      }
    }],
    "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-household-situation"
  }],
  "identifier" : [{
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
        "code" : "INS-NIR"
      }]
    },
    "system" : "urn:oid:1.2.250.1.213.1.4.8",
    "value" : "147720425367411"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "PI",
        "display" : "Patient internal identifier"
      }]
    },
    "system" : "https://identifiant-medicosocial-localusager.esante.gouv.fr",
    "value" : "3480787529/194704032"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "DL"
      }]
    },
    "system" : "https://ants.gouv.fr/",
    "value" : "822146819",
    "period" : {
      "start" : "1980-01-01"
    }
  }],
  "name" : [{
    "extension" : [{
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-birth-list-given-name",
      "valueString" : "Jean Stéphane Patrick"
    }],
    "use" : "official",
    "family" : "DUPONT",
    "given" : ["Jean"]
  },
  {
    "use" : "usual",
    "family" : "DUPONT"
  }],
  "gender" : "male",
  "birthDate" : "1947-04-03",
  "address" : [{
    "use" : "home",
    "line" : ["12 rue des Lilas"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "12"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameBase",
        "valueString" : "rue des Lilas"
      }]
    }],
    "postalCode" : "76748",
    "country" : "99100"
  }]
}

```

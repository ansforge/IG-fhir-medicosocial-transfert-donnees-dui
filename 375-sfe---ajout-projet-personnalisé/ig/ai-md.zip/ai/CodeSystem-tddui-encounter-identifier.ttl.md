# TDDUI Encounter FR Core CodeSystem v2-0203 - TTL Representation - Médicosocial - Transfert de données DUI v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Encounter FR Core CodeSystem v2-0203**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](CodeSystem-tddui-encounter-identifier.md) 
*  [XML](CodeSystem-tddui-encounter-identifier.xml.md) 
*  [JSON](CodeSystem-tddui-encounter-identifier.json.md) 
*  [TTL](#) 

## : TDDUI Encounter FR Core CodeSystem v2-0203 - TTL Representation

| |
| :--- |
| Active as of 2025-10-07 |

[Raw ttl](CodeSystem-tddui-encounter-identifier.ttl) | [Download](CodeSystem-tddui-encounter-identifier.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-tddui-encounter-identifier.json.md) | [top](#top) |  [next>](CodeSystem-tddui-identifier.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


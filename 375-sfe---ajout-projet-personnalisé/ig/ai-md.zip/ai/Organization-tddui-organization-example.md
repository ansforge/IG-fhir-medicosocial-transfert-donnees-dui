# tddui-organization-example - Médicosocial - Transfert de données DUI v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-organization-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](Organization-tddui-organization-example.xml.md) 
*  [JSON](Organization-tddui-organization-example.json.md) 
*  [TTL](Organization-tddui-organization-example.ttl.md) 

## Example Organization: tddui-organization-example

Profil: [TDDUI Organization](StructureDefinition-tddui-organization.md)

**identifier**: Identification nationale de structure définie par l’ANS dans le CI_SIS/1480787529

**name**: Les Chênes Verts

| | | |
| :--- | :--- | :--- |
|  [<prev](Encounter-tddui-encounter-sejour-example.ttl.md) | [top](#top) |  [next>](Organization-tddui-organization-example.xml.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


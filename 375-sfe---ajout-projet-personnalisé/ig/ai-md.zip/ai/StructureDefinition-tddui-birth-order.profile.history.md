#  - Médicosocial - Transfert de données DUI v2.0.0

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-birth-order.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-birth-order-definitions.md) 
*  [Mappings](StructureDefinition-tddui-birth-order-mappings.md) 
*  [XML](StructureDefinition-tddui-birth-order.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-birth-order.profile.json.md) 
*  [TTL](StructureDefinition-tddui-birth-order.profile.ttl.md) 

## Extension: TDDUIBirthOrder - Change History

| |
| :--- |
| Active as of 2025-10-07 |

Changes in the tddui-birth-order extension.

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


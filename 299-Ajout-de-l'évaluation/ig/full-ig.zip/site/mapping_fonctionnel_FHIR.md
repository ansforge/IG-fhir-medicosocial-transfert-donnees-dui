# Mapping FHIR du modèle de contenu DUI - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Mapping FHIR du modèle de contenu DUI**

## Mapping FHIR du modèle de contenu DUI

 Ce mapping représente les données fonctionnelles trouvant leur équivalence dans l'actuelle version des spécifications techniques. 

 **Note :** Pour visualiser l’entièreté du mapping, il est nécessaire de dézoomer. 

### Mapping global

### Mapping Usager

### Mapping Sejour & EntiteJuridique

### Mapping Professionnel

### Mapping Evènement

### Mapping Transport

### Mapping Evaluation


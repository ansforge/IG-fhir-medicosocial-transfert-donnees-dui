#  - Médicosocial - Transfert de données DUI v2.0.0-ballot

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-human-name.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-human-name-definitions.md) 
*  [Mappings](StructureDefinition-tddui-human-name-mappings.md) 
*  [XML](StructureDefinition-tddui-human-name.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-human-name.profile.json.md) 
*  [TTL](StructureDefinition-tddui-human-name.profile.ttl.md) 

## Data Type Profile: tddui-humanname - Examples

| |
| :--- |
| Active as of 2025-10-01 |

**No examples are currently available for the Profile.**

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


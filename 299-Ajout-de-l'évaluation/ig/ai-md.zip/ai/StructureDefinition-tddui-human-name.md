# TDDUI Human Name DataType - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Human Name DataType**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-human-name-definitions.md) 
*  [Mappings](StructureDefinition-tddui-human-name-mappings.md) 
*  [XML](StructureDefinition-tddui-human-name.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-human-name.profile.json.md) 
*  [TTL](StructureDefinition-tddui-human-name.profile.ttl.md) 

## Data Type Profile: TDDUI Human Name DataType 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-human-name | *Version*:2.0.0-ballot |
| Active as of 2025-10-06 | *Computable Name*:tddui-humanname |

 

| | |
| :--- | :--- |
| French profile of datatype HumanName with constraints on prefix and suffix | Profilage du type de données HumanName pour prise en compte de la civilté au niveau de l'élément prefix et du titre au niveau de l'élément suffix |

 

**Usages:**

* Use this DataType Profile: [TDDUI Patient INS](StructureDefinition-tddui-patient-ins.md), [TDDUI Patient](StructureDefinition-tddui-patient.md) and [TDDUI Practitioner](StructureDefinition-tddui-practitioner.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-human-name)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreHumanNameProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-human-name.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreHumanNameProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-human-name.html) 

**Résumé**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [FRCoreHumanNameProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-human-name.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreHumanNameProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-human-name.html) 

**Résumé**

 

Other representations of profile: [CSV](StructureDefinition-tddui-human-name.csv), [Excel](StructureDefinition-tddui-human-name.xlsx), [Schematron](StructureDefinition-tddui-human-name.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-task-transport-usager.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-human-name-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


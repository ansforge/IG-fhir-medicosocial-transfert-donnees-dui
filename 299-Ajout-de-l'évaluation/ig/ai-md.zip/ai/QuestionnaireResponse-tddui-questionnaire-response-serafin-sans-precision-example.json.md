# tddui-questionnaire-response-serafin-sans-precision-example - JSON Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-questionnaire-response-serafin-sans-precision-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.md) 
*  [XML](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.xml.md) 
*  [JSON](#) 
*  [TTL](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.ttl.md) 

## : tddui-questionnaire-response-serafin-sans-precision-example - JSON Representation

[Raw json](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.json) | [Download](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.xml.md) | [top](#top) |  [next>](QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.ttl.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


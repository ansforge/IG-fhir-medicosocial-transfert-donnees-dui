# Libellé mode de sortie - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Libellé mode de sortie**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-exit-mode-label.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-exit-mode-label-definitions.md) 
*  [Mappings](StructureDefinition-tddui-exit-mode-label-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-tddui-exit-mode-label.profile.json.md) 
*  [TTL](StructureDefinition-tddui-exit-mode-label.profile.ttl.md) 

## Extension: TDDUIExitModeLabel - XML Profile

| |
| :--- |
| Active as of 2025-10-01 |

XML representation of the tddui-exit-mode-label extension.

[Raw xml](StructureDefinition-tddui-exit-mode-label.xml) | [Download](StructureDefinition-tddui-exit-mode-label.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-exit-mode-label-testing.md) | [top](#top) |  [next>](StructureDefinition-tddui-exit-mode-label.profile.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Libellé mode d'entrée - TTL Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Libellé mode d'entrée**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-entry-mode-label.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-entry-mode-label-definitions.md) 
*  [Mappings](StructureDefinition-tddui-entry-mode-label-mappings.md) 
*  [XML](StructureDefinition-tddui-entry-mode-label.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-entry-mode-label.profile.json.md) 
*  [TTL](#) 

## Extension: TDDUIEntryModelabel - TTL Profile

| |
| :--- |
| Active as of 2025-10-08 |

TTL representation of the tddui-entry-mode-label extension.

[Raw ttl](StructureDefinition-tddui-entry-mode-label.ttl) | [Download](StructureDefinition-tddui-entry-mode-label.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-entry-mode-label.profile.json.md) | [top](#top) |  [next>](StructureDefinition-tddui-exit-mode-label.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


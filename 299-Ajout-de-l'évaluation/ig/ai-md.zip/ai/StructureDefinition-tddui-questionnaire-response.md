# TDDUI QuestionnaireResponse - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI QuestionnaireResponse**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-questionnaire-response-definitions.md) 
*  [Mappings](StructureDefinition-tddui-questionnaire-response-mappings.md) 
*  [Examples](StructureDefinition-tddui-questionnaire-response-examples.md) 
*  [XML](StructureDefinition-tddui-questionnaire-response.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-questionnaire-response.profile.json.md) 
*  [TTL](StructureDefinition-tddui-questionnaire-response.profile.ttl.md) 

## Resource Profile: TDDUI QuestionnaireResponse 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response | *Version*:2.0.0-ballot |
| Active as of 2025-10-06 | *Computable Name*:TDDUIQuestionnaireResponse |

 
Profil de la ressource QuestionnaireResponse utilisé pour transmettre les réponses aux questionnaires dans le cadre des évaluations. 

**Usages:**

* Examples for this Profile: [QuestionnaireResponse/tddui-questionnaire-response-aggir-pa-example](QuestionnaireResponse-tddui-questionnaire-response-aggir-pa-example.md), [QuestionnaireResponse/tddui-questionnaire-response-aggir-ph-example](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.md) and [QuestionnaireResponse/tddui-questionnaire-response-situation-ssiad-example](QuestionnaireResponse-tddui-questionnaire-response-situation-ssiad-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-questionnaire-response)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [QuestionnaireResponse](http://hl7.org/fhir/R4/questionnaireresponse.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [QuestionnaireResponse](http://hl7.org/fhir/R4/questionnaireresponse.html) 

**Résumé**

Mandatory: 4 elements

**Structures**

This structure refers to these other structures:

* [TDDUI Patient(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient)](StructureDefinition-tddui-patient.md)
* [TDDUI Patient INS(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins)](StructureDefinition-tddui-patient-ins.md)
* [TDDUI Encounter Evenement(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-evenement)](StructureDefinition-tddui-encounter-evenement.md)
* [TDDUI Practitioner(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner)](StructureDefinition-tddui-practitioner.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-qr-participant](StructureDefinition-tddui-qr-participant.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-attachment](StructureDefinition-tddui-attachment.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment](StructureDefinition-tddui-comment.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of QuestionnaireResponse.item.answer.value[x]
* The element 1 is sliced based on the value of QuestionnaireResponse.item.item.answer.value[x]
* The element 1 is sliced based on the value of QuestionnaireResponse.item.item.item.answer.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [QuestionnaireResponse](http://hl7.org/fhir/R4/questionnaireresponse.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [QuestionnaireResponse](http://hl7.org/fhir/R4/questionnaireresponse.html) 

**Résumé**

Mandatory: 4 elements

**Structures**

This structure refers to these other structures:

* [TDDUI Patient(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient)](StructureDefinition-tddui-patient.md)
* [TDDUI Patient INS(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins)](StructureDefinition-tddui-patient-ins.md)
* [TDDUI Encounter Evenement(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-evenement)](StructureDefinition-tddui-encounter-evenement.md)
* [TDDUI Practitioner(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner)](StructureDefinition-tddui-practitioner.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-qr-participant](StructureDefinition-tddui-qr-participant.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-attachment](StructureDefinition-tddui-attachment.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment](StructureDefinition-tddui-comment.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of QuestionnaireResponse.item.answer.value[x]
* The element 1 is sliced based on the value of QuestionnaireResponse.item.item.answer.value[x]
* The element 1 is sliced based on the value of QuestionnaireResponse.item.item.item.answer.value[x]

 

Other representations of profile: [CSV](StructureDefinition-tddui-questionnaire-response.csv), [Excel](StructureDefinition-tddui-questionnaire-response.xlsx), [Schematron](StructureDefinition-tddui-questionnaire-response.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-practitioner-role.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-questionnaire-response-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Usager présent - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Usager présent**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-patient-present-definitions.md) 
*  [Mappings](StructureDefinition-tddui-patient-present-mappings.md) 
*  [XML](StructureDefinition-tddui-patient-present.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-patient-present.profile.json.md) 
*  [TTL](StructureDefinition-tddui-patient-present.profile.ttl.md) 

## Extension: Usager présent 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-present | *Version*:2.0.0-ballot |
| Active as of 2025-10-08 | *Computable Name*:TDDUIPatientPresent |

Evènement nécessitant ou non la présence physique de l’usager.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-patient-present)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type boolean: Evènement nécessitant ou non la présence physique de l’usager.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type boolean: Evènement nécessitant ou non la présence physique de l’usager.

 

Other representations of profile: [CSV](StructureDefinition-tddui-patient-present.csv), [Excel](StructureDefinition-tddui-patient-present.xlsx), [Schematron](StructureDefinition-tddui-patient-present.sch) 

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-profession.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-patient-present-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# TDDUI Profession - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Profession**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-profession-definitions.md) 
*  [Mappings](StructureDefinition-tddui-profession-mappings.md) 
*  [XML](StructureDefinition-tddui-profession.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-profession.profile.json.md) 
*  [TTL](StructureDefinition-tddui-profession.profile.ttl.md) 

## Extension: TDDUI Profession 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-profession | *Version*:2.0.0-ballot |
| Active as of 2025-10-07 | *Computable Name*:TDDUIProfession |

Extension permettant de représenter la profession du professionnel.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [TDDUI Practitioner Role](StructureDefinition-tddui-practitioner-role.md)
* Examples for this Extension: [PractitionerRole/tddui-practitioner-role-example](PractitionerRole-tddui-practitioner-role-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-profession)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type CodeableConcept: Extension permettant de représenter la profession du professionnel.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type CodeableConcept: Extension permettant de représenter la profession du professionnel.

 

Other representations of profile: [CSV](StructureDefinition-tddui-profession.csv), [Excel](StructureDefinition-tddui-profession.xlsx), [Schematron](StructureDefinition-tddui-profession.sch) 

#### Terminology Bindings

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-ressources-used.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-profession-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


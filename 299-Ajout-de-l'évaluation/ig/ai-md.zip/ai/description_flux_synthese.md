# Synthèse des flux - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Volume 2 - Détail des transactions**](description_flux.md)
* **Synthèse des flux**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Synthèse des flux

* Processus métier: * Transfert des données d'un logiciel DUI

  * Flux techniques: * Flux 1.1 - Transmission de données DUI : interaction « create » de FHIR
* Flux 1.2 - Résultat de la transmission de données DUI : réponse à la requête HTTP POST
Lien vers la description détaillée :[flux 1](description_flux_1_transmission_donnees_dui.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](description_flux.md) | [top](#top) |  [next>](description_flux_1_transmission_donnees_dui.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


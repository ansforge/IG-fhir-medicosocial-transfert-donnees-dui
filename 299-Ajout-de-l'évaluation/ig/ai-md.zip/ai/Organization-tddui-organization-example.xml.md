# tddui-organization-example - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-organization-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](Organization-tddui-organization-example.md) 
*  [XML](#) 
*  [JSON](Organization-tddui-organization-example.json.md) 
*  [TTL](Organization-tddui-organization-example.ttl.md) 

## : tddui-organization-example - XML Representation

[Raw xml](Organization-tddui-organization-example.xml) | [Download](Organization-tddui-organization-example.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](Organization-tddui-organization-example.md) | [top](#top) |  [next>](Organization-tddui-organization-example.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


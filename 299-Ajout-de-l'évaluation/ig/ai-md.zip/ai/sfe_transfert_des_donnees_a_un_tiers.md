# Transfert des données à un tiers - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Volume 1 - Etude fonctionnelle**](sfe.md)
* **Transfert des données à un tiers**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Transfert des données à un tiers

* [Définition des Processus collaboratif](#définition-des-processus-collaboratif)
* [Liste des acteurs pour l’ensemble des processus](#liste-des-acteurs-pour-lensemble-des-processus)
* [Identification des flux](#identification-des-flux)

### Définition des Processus collaboratif

* Service attendu: Pré-conditions
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: * Un SI Tiers a demandé à l’ESSMS de lui transmettre tout ou partie des données médico-sociales de l’usager.

* Service attendu: Post-conditions
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: N/A
* Service attendu: Contraintes fonctionnelles
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: N/A
* Service attendu: Scénario nominal
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: Scénario conforme aux cas d'usages décrits dans["Cas d'usage"](sfe_cas_usage.md).

### Liste des acteurs pour l’ensemble des processus

#### Le producteur

Le rôle de producteur incarné par un système est l’acteur à l’origine de l’export des données.

* Processus collaboratif: Export des données d’un logiciel DUI
  * Producteur: **DUI**: Logiciel Métier utilisé par les ESSMS permettant de gérer les dossiers des usagers avant, pendant et après son accompagnement

#### Le consommateur

Le rôle de consommateur incarné par un système est de réceptionner et d’importer les données dans son système (SI-tiers).

### Identification des flux

* Processus métier: * Transfert des données d'un logiciel DUI

  * Flux techniques: * Flux 1.1 - Transmission de données DUI
* Flux 1.2 - Résultat de la transmission de données DUI
Lien vers la description détaillée :[flux 1](description_flux_1_transmission_donnees_dui.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](sfe_organisation_contexte_metier.md) | [top](#top) |  [next>](sfe_modelisation_contenu.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


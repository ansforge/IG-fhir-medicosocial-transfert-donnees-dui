# tddui-patient-example - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-patient-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](Patient-tddui-patient-example.xml.md) 
*  [JSON](Patient-tddui-patient-example.json.md) 
*  [TTL](Patient-tddui-patient-example.ttl.md) 

## Example Patient: tddui-patient-example

Profil: [TDDUI Patient](StructureDefinition-tddui-patient.md)

DUPONT Male, Date de Naissance :1947-04-03 ( Patient internal identifier: 3480787529/194704032)

-------

| | |
| :--- | :--- |
| Nom alternatif : | Jean DUPONT (Official) |
| Contact Detail | 12 rue des Lilas, 76748 Vittefleur, France(home) |
| [Patient Birth Place](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-birthPlace.html) | Mazoires FRA |

| | | |
| :--- | :--- | :--- |
|  [<prev](Organization-tddui-organization-example.ttl.md) | [top](#top) |  [next>](Patient-tddui-patient-example.xml.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


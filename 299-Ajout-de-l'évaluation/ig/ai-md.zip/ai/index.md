# Accueil - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* **Accueil**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/ImplementationGuide/ans.fhir.fr.tddui | *Version*:2.0.0-ballot |
| Active as of 2025-10-07 | *Computable Name*:TDDUI |

* [Introduction](#introduction)
* [Lectorat cible](#lectorat-cible)
* [Utilisation](#utilisation)
* [Standards utilisés](#standards-utilisés)
* [Flux](#flux)
* [Dépendances](#dépendances)

 **Brief description of this Implementation Guide**
 The Digital User File (DUI) centralizes all information concerning the person being cared for in social and medico-social facilities and services. The aim of this implementation guide is to define the specifications for DUI data transfer. 

> **Attention !**
Cet Implementation Guide est actuellement en concertation. La version courante est accessible à l'adresse : http://interop.esante.gouv.fr/ig/fhir/tddui

### Introduction

Le Programme ESMS numérique, porté par la Caisse Nationale de Solidarité pour l'Autonomie (CNSA), vise à généraliser l’utilisation du numérique dans les établissements et services sociaux et médico-sociaux (ESSMS). Il repose principalement sur le déploiement d’un Dossier Usager Informatisé (DUI) pour chaque personne accompagnée. Ce DUI centralise l’ensemble des informations qui concerne la personne accompagnée en structure et service sociale et médico-sociale, et son parcours de santé et de vie. Ce dossier unique comprend :

* Des données administratives ;
* Des données liées à l’accompagnement de l’usager ;
* Des données liées à la coordination des différents acteurs ;
* Des données médicales.

Les logiciels DUI doivent permettre, entre autres, de mieux construire et de suivre le projet personnalisé de la personne accompagnée, d’éviter les ruptures de parcours en cas d’évolution des besoins, de changement d’établissement médico-social, de retour à domicile ou d’hospitalisation.

Dans la continuité des travaux menés dans le cadre du programme ESMS numérique, la CNSA et l’ANS créent un nouveau volet « Transfert de données DUI ». L’objectif de ce volet est de définir la nature et le format des données à transmettre lors d’un export depuis un logiciel DUI afin d’assurer le transfert de données des usagers.

Ce guide d'implémentation contient :

* L'étude des normes et standards au format pdf : [Etude des normes et standards](NormesStandards_TransfertDonneesDUI_V1.0.pdf)
* Les spécifications fonctionnelles : section [Spécifications fonctionnelles](sfe.md)
* La spécification technique de contenu : 
 Il existe deux représentations techniques pour le contenu de l'export des données d'un logiciel DUI : 
* une représentation basée sur le standard FHIR afin de s’aligner sur les recommandations européennes et pour s’adapter aux évolutions des [cas d'usage](sfe_cas_usage.md) de ce volet.
 La représentation FHIR décrite dans ce guide est à privilégier pour toute nouvelle implémentation : section [Ressources de conformité](artifacts.md)
* une représentation basée sur le standard CDA qui est spécifiée dans le guide d'implémentation [Médicosocial - Transfert de données DUI CDA](https://interop.esante.gouv.fr/ig/cda/tddui/). Ce guide est restreint au cas d'usage SSIAD. Les évolutions de ce guide d’implémentation sont limitées à des corrections techniques. Ce guide d'implementation sera déprécié lorsque la transition des éditeurs de CDA vers FHIR sera achevée.
 
* La spécification technique de transport : sections [Volume 2 - Détail des transactions](description_flux.md) et [Ressources de conformité](artifacts.md)
* Les annexes : 
* [Mapping FHIR du modèle de contenu DUI](mapping_fonctionnel_FHIR.md)
* [Documents de référence](annexes_documents_reference.md)
* [Acronymes](annexes_acronymes.md)
* [Professions du médico-social](annexes_codes_professions_roles_modes_exercices.md)
* [Sécurité](securite.md)
* [Télerchargement et usages](downloads.md)
 

### Lectorat cible

Ce document s'adresse aux chefs de projets qui spécifient des projets avec des interfaces interopérables et aux développeurs des interfaces interopérables des systèmes implémentant le volet « Transfert de données DUI ». Il s'adresse également à toute autre personne intervenant dans le processus de mise en place de ces interfaces et à tout porteur de SI cherchant à transporter de manière interopérable des données usagers vers un autre SI ainsi que les éditeurs de logiciels DUI.

L’hypothèse est faite que le lecteur est familier du standard FHIR R4.

### Utilisation

Les spécifications d'interopérabilité présentées dans ce volet ne présagent pas des conditions de leur mise en œuvre dans le cadre d'un système d'information partagé. Il appartient à tout responsable de traitement de s'assurer que les services utilisant ces spécifications respectent les cadres et bonnes pratiques applicables à ce genre de service (ex.: cadre juridique, bonnes pratiques de sécurité, ergonomie, accessibilité …).

### Standards utilisés

Les données véhiculées dans ce volet ainsi que les interactions entre les systèmes reposent sur le standard HL7 FHIR Release 4.

Les interactions font référence à un certain nombre de ressources du standard ainsi qu’aux spécifications de l’API REST FHIR, basées sur le protocole HTTP. Les syntaxes retenues sont la syntaxe XML et JSON.

#### Ressources FHIR profilées

Les ressources profilées dans le cadre de ce guide d'implémentation sont les suivantes :

| | | |
| :--- | :--- | :--- |
| [Bundle](https://hl7.org/fhir/R4/bundle.html) | [TDDUIBundle](StructureDefinition-tddui-bundle.md) | Profil générique créé pour transmettre des données d'un logiciel DUI |
| [Encounter](https://hl7.org/fhir/R4/encounter.html) | [TDDUIEncounterSejour](StructureDefinition-tddui-encounter-sejour.md) | Profil de la ressource Encounter permettant de regrouper les informations relatives au séjour d'un usager dans une structure ESSMS |
| [Organization](https://hl7.org/fhir/R4/organization.html) | [TDDUIOrganization](StructureDefinition-tddui-organization.md) | Profil de la ressource FRCoreOrganizationProfile permettant de représenter les entités juridiques. |
| [Patient](https://hl7.org/fhir/R4/Patient.html) | [TDDUIPatient](StructureDefinition-tddui-patient.md) | Profil de la ressource FrCorePatientProfile permettant de représenter un usager lorsque l'INS n'est pas transmis. |
| [Patient](https://hl7.org/fhir/R4/Patient.html) | [TDDUIPatientINS](StructureDefinition-tddui-patient-ins.md) | Profil de la ressource FRCorePatientINSProfile permettant de représenter un usager lorsque l'INS est transmis. |
| [Encounter](https://hl7.org/fhir/R4/encounter.html) | [TDDUIEncounterEvenement](StructureDefinition-tddui-encounter-evenement.md) | Profil de la ressource Encounter permettant de regrouper les informations relatives au séjour d'un usager dans une structure ESSMS |
| [Practitioner](https://hl7.org/fhir/R4/Practitioner.html) | [TDDUIPractitioner](StructureDefinition-tddui-practitioner.md) | Profil de la ressource FRCorePractitionerProfile permettant de représenter un Profesionnel. |
| [PractitionerRole](https://hl7.org/fhir/R4/PractitionerRole.html) | [TDDUIPractitionerRole](StructureDefinition-tddui-practitioner-role.md) | Profil de la ressource FRCorePractitionerRole permettant de représenter un Professionnel. |
| [QuestionnaireResponse](https://hl7.org/fhir/R4/QuestionnaireResponse.html) | [TDDUIQuestionnaireResponse](StructureDefinition-tddui-questionnaire-response.md) | Profil de la ressource QuestionnaireResponse utilisé pour transmettre les réponses aux questionnaires dans le cadre des évaluations. |
| [Task](https://hl7.org/fhir/R4/Task.html) | [TDDUITaskTransport](StructureDefinition-tddui-task-transport.md) | Profil de la ressource Task permettant de représenter le transport. |
| [Task](https://hl7.org/fhir/R4/Task.html) | [TDDUITaskTransportProfessionnel](StructureDefinition-tddui-task-transport-professionnel.md) | Profil de la ressource TDDUITaskTransport permettant de représenter le transport du professionnel. |
| [Task](https://hl7.org/fhir/R4/Task.html) | [TDDUITaskTransportUsager](StructureDefinition-tddui-task-transport-usager.md) | Profil de la ressource TDDUITaskTransport permettant de représenter le transport de l'usager. |

#### Instances de Questionnaire

| | |
| :--- | :--- |
| [Évaluation AGGIR PA SSIAD](Questionnaire-tddui-questionnaire-aggir-pa-ssiad.md) | Grille d'évaluation AGGIR PA SSIAD |
| [Évaluation AGGIR PH SSIAD](Questionnaire-tddui-questionnaire-aggir-ph-ssiad.md) | Grille d'évaluation AGGIR PH SSIAD |
| [Évaluation SERAFIN](Questionnaire-tddui-questionnaire-serafin.md) | Grille d'évaluation SERAFIN |
| [Évaluation de la situation SSIAD](Questionnaire-tddui-questionnaire-situation-ssiad.md) | Grille d'évaluation de la situation SSIAD |

### Flux

Les flux décrits dans ce guide d'implémentation sont les suivants.

| | | |
| :--- | :--- | :--- |
| [Flux 1 : Transmission de données DUI](description_flux_1_transmission_donnees_dui.md) | Logiciel DUI | SI tiers |

Pour en savoir davantage, rendez-vous sur la page [Synthèse des flux](description_flux_synthese.md).

### Dépendances








| | | |
| :--- | :--- | :--- |
|  [<prev](toc.md) | [top](#top) |  [next>](sfe.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


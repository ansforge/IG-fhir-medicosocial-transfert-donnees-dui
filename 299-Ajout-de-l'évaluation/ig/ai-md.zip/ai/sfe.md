# Volume 1 - Etude fonctionnelle - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* **Volume 1 - Etude fonctionnelle**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Volume 1 - Etude fonctionnelle

* [Cas d'usage](sfe_cas_usage.md)
* [Organisation du contexte métier](sfe_organisation_contexte_metier.md)
* [Transmission des données à un tiers](sfe_transfert_des_donnees_a_un_tiers.md)
* [Modélisation du contenu du DUI](sfe_modelisation_contenu.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](index.md) | [top](#top) |  [next>](sfe_cas_usage.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


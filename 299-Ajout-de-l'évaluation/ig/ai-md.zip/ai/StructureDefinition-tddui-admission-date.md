# Date d’admission - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Date d’admission**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-admission-date-definitions.md) 
*  [Mappings](StructureDefinition-tddui-admission-date-mappings.md) 
*  [XML](StructureDefinition-tddui-admission-date.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-admission-date.profile.json.md) 
*  [TTL](StructureDefinition-tddui-admission-date.profile.ttl.md) 

## Extension: Date d’admission 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-admission-date | *Version*:2.0.0-ballot |
| Active as of 2025-10-06 | *Computable Name*:TDDUIAdmissionDate |

Date d’admission dans la structure ESSMS.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md)
* Examples for this Extension: [Bundle/ExampleTDDUIBundle](Bundle-ExampleTDDUIBundle.md) and [Encounter/tddui-encounter-sejour-example](Encounter-tddui-encounter-sejour-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-admission-date)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type dateTime: Date d’admission dans la structure ESSMS.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type dateTime: Date d’admission dans la structure ESSMS.

 

Other representations of profile: [CSV](StructureDefinition-tddui-admission-date.csv), [Excel](StructureDefinition-tddui-admission-date.xlsx), [Schematron](StructureDefinition-tddui-admission-date.sch) 

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-comment.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-admission-date-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


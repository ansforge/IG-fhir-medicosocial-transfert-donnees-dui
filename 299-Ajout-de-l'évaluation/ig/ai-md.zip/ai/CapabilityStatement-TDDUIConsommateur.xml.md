# TDDUI-Consommateur - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI-Consommateur**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](CapabilityStatement-TDDUIConsommateur.md) 
*  [XML](#) 
*  [JSON](CapabilityStatement-TDDUIConsommateur.json.md) 
*  [TTL](CapabilityStatement-TDDUIConsommateur.ttl.md) 

## : TDDUI-Consommateur - XML Representation

| |
| :--- |
| Active as of 2024-06-20 |

[Raw xml](CapabilityStatement-TDDUIConsommateur.xml) | [Download](CapabilityStatement-TDDUIConsommateur.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](CapabilityStatement-TDDUIConsommateur-testing.md) | [top](#top) |  [next>](CapabilityStatement-TDDUIConsommateur.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


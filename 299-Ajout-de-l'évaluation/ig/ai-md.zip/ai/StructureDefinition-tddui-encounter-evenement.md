# TDDUI Encounter Evenement - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Encounter Evenement**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-encounter-evenement-definitions.md) 
*  [Mappings](StructureDefinition-tddui-encounter-evenement-mappings.md) 
*  [Examples](StructureDefinition-tddui-encounter-evenement-examples.md) 
*  [XML](StructureDefinition-tddui-encounter-evenement.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-encounter-evenement.profile.json.md) 
*  [TTL](StructureDefinition-tddui-encounter-evenement.profile.ttl.md) 

## Resource Profile: TDDUI Encounter Evenement 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-evenement | *Version*:2.0.0-ballot |
| Active as of 2025-10-07 | *Computable Name*:TDDUIEncounterEvenement |

 
Profil de la ressource Encounter permettant de regrouper les évènements liés à la prise en charge de l’usager dans une structure ESSMS. 

 
>  
**Note**: Le profil TDDUI ne peut pas hériter de FR Core Encounter à cause du type d'évènement qui est restreint à 1. Cependant, ce profil suit la plupart des règles de FR Core Encounter via un RuleSet. 
 

**Usages:**

* Refer to this Profile: [TDDUI QuestionnaireResponse](StructureDefinition-tddui-questionnaire-response.md) and [TDDUI Task Transport](StructureDefinition-tddui-task-transport.md)
* Examples for this Profile: [Encounter/tddui-encounter-evenement-example](Encounter-tddui-encounter-evenement-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-encounter-evenement)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

**Résumé**

Mandatory: 10 elements(11 nested mandatory elements)
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [FR Core Organization Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-organization)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html)
* [TDDUI Patient(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient)](StructureDefinition-tddui-patient.md)
* [TDDUI Patient INS(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins)](StructureDefinition-tddui-patient-ins.md)
* [TDDUI Practitioner(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner)](StructureDefinition-tddui-practitioner.md)
* [TDDUI Practitioner Role(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner-role)](StructureDefinition-tddui-practitioner-role.md)
* [FR Core Appointment Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-appointment)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-appointment.html)
* [FR Core Location Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-location)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-location.html)
* [TDDUI Organization(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization)](StructureDefinition-tddui-organization.md)
* [TDDUI Encounter Sejour(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-sejour)](StructureDefinition-tddui-encounter-sejour.md)

**Extensions**

This structure refers to these extensions:

* [https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-estimated-discharge-date](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-estimated-discharge-date.html)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-ressources-used](StructureDefinition-tddui-ressources-used.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-label](StructureDefinition-tddui-event-label.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment](StructureDefinition-tddui-comment.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-report](StructureDefinition-tddui-event-report.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-attachment](StructureDefinition-tddui-attachment.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-outside-service](StructureDefinition-tddui-outside-service.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-reason](StructureDefinition-tddui-event-reason.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-present](StructureDefinition-tddui-patient-present.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-meal](StructureDefinition-tddui-meal.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-cancel-reason](StructureDefinition-tddui-event-cancel-reason.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.type

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

**Résumé**

Mandatory: 10 elements(11 nested mandatory elements)
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [FR Core Organization Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-organization)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html)
* [TDDUI Patient(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient)](StructureDefinition-tddui-patient.md)
* [TDDUI Patient INS(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins)](StructureDefinition-tddui-patient-ins.md)
* [TDDUI Practitioner(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner)](StructureDefinition-tddui-practitioner.md)
* [TDDUI Practitioner Role(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner-role)](StructureDefinition-tddui-practitioner-role.md)
* [FR Core Appointment Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-appointment)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-appointment.html)
* [FR Core Location Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-location)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-location.html)
* [TDDUI Organization(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization)](StructureDefinition-tddui-organization.md)
* [TDDUI Encounter Sejour(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-sejour)](StructureDefinition-tddui-encounter-sejour.md)

**Extensions**

This structure refers to these extensions:

* [https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-estimated-discharge-date](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-estimated-discharge-date.html)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-ressources-used](StructureDefinition-tddui-ressources-used.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-label](StructureDefinition-tddui-event-label.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment](StructureDefinition-tddui-comment.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-report](StructureDefinition-tddui-event-report.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-attachment](StructureDefinition-tddui-attachment.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-outside-service](StructureDefinition-tddui-outside-service.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-reason](StructureDefinition-tddui-event-reason.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-present](StructureDefinition-tddui-patient-present.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-meal](StructureDefinition-tddui-meal.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-event-cancel-reason](StructureDefinition-tddui-event-cancel-reason.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.type

 

Other representations of profile: [CSV](StructureDefinition-tddui-encounter-evenement.csv), [Excel](StructureDefinition-tddui-encounter-evenement.xlsx), [Schematron](StructureDefinition-tddui-encounter-evenement.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-bundle.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-encounter-evenement-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


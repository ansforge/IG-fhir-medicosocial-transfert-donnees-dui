# TDDUI Task Transport - Definitions - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Task Transport**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-task-transport.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-tddui-task-transport-mappings.md) 
*  [Examples](StructureDefinition-tddui-task-transport-examples.md) 
*  [XML](StructureDefinition-tddui-task-transport.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-task-transport.profile.json.md) 
*  [TTL](StructureDefinition-tddui-task-transport.profile.ttl.md) 

## Resource Profile: TDDUITaskTransport - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-07 |

Definitions for the tddui-task-transport resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-task-transport.md) | [top](#top) |  [next>](StructureDefinition-tddui-task-transport-mappings.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# TDDUI Profession - TTL Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Profession**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-profession.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-profession-definitions.md) 
*  [Mappings](StructureDefinition-tddui-profession-mappings.md) 
*  [XML](StructureDefinition-tddui-profession.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-profession.profile.json.md) 
*  [TTL](#) 

## Extension: TDDUIProfession - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the tddui-profession extension.

[Raw ttl](StructureDefinition-tddui-profession.ttl) | [Download](StructureDefinition-tddui-profession.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-profession.profile.json.md) | [top](#top) |  [next>](StructureDefinition-tddui-patient-present.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


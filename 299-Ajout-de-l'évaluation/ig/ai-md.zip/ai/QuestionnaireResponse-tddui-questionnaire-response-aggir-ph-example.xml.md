# tddui-questionnaire-response-aggir-ph-example - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-questionnaire-response-aggir-ph-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.md) 
*  [XML](#) 
*  [JSON](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.json.md) 
*  [TTL](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.ttl.md) 

## : tddui-questionnaire-response-aggir-ph-example - XML Representation

[Raw xml](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.xml) | [Download](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.md) | [top](#top) |  [next>](QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


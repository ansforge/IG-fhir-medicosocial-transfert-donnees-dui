# TDDUI Human Name DataType - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Human Name DataType**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-human-name.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-human-name-definitions.md) 
*  [Mappings](StructureDefinition-tddui-human-name-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-tddui-human-name.profile.json.md) 
*  [TTL](StructureDefinition-tddui-human-name.profile.ttl.md) 

## Data Type Profile: tddui-humanname - XML Profile

| |
| :--- |
| Active as of 2025-10-01 |

XML representation of the tddui-human-name data type profile.

[Raw xml](StructureDefinition-tddui-human-name.xml) | [Download](StructureDefinition-tddui-human-name.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-human-name-testing.md) | [top](#top) |  [next>](StructureDefinition-tddui-human-name.profile.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


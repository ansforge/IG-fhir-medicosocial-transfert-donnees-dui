# Acronymes - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Acronymes**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Acronymes

* Sigle / Acronyme: ANS
  * Définition: L’Agence du Numérique en Santé
* Sigle / Acronyme: ARS
  * Définition: Agence Régionale de Santé
* Sigle / Acronyme: CDA
  * Définition: Clinical Document
* Sigle / Acronyme: CI-SIS
  * Définition: Cadre d’Interopérabilité des Systèmes d’Information de Santé
* Sigle / Acronyme: CNIL
  * Définition: Commission nationale de l'informatique et des libertés
* Sigle / Acronyme: CNSA
  * Définition: Caisse Nationale de Solidarité pour l’Autonomie
* Sigle / Acronyme: DUI
  * Définition: Dossier Usager Informatisé
* Sigle / Acronyme: DSR
  * Définition: Dossier de Spécifications de Référenceement
* Sigle / Acronyme: ESSMS (ou ESMS)
  * Définition: Etablissement et Services sociaux ou Médico-Sociaux
* Sigle / Acronyme: GIR
  * Définition: Groupe Iso-Ressource
* Sigle / Acronyme: HL7
  * Définition: Health Level 7
* Sigle / Acronyme: INS
  * Définition: Identité Nationale de Santé
* Sigle / Acronyme: IPS
  * Définition: International Patient Summary
* Sigle / Acronyme: MDPH
  * Définition: Maison Départementale des Personnes Handicapées
* Sigle / Acronyme: NIA
  * Définition: Numéro d'Immatriculation d'Attente
* Sigle / Acronyme: NIR
  * Définition: Numéro d'Inscription au Répertoire
* Sigle / Acronyme: RGPD
  * Définition: Règlement Général sur la Protection des Données
* Sigle / Acronyme: SI
  * Définition: Système d’Information
* Sigle / Acronyme: SIDOBA
  * Définition: Système d’Information de l’Offre de la Branche Autonomie
* Sigle / Acronyme: TRE
  * Définition: Terminologie de REférence
* Sigle / Acronyme: JDV
  * Définition: Jeu De Valeur

| | | |
| :--- | :--- | :--- |
|  [<prev](annexes_documents_reference.md) | [top](#top) |  [next>](annexes_codes_professions_roles_modes_exercices.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


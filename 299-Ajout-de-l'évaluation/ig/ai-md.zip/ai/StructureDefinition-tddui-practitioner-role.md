# TDDUI Practitioner Role - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Practitioner Role**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-practitioner-role-definitions.md) 
*  [Mappings](StructureDefinition-tddui-practitioner-role-mappings.md) 
*  [Examples](StructureDefinition-tddui-practitioner-role-examples.md) 
*  [XML](StructureDefinition-tddui-practitioner-role.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-practitioner-role.profile.json.md) 
*  [TTL](StructureDefinition-tddui-practitioner-role.profile.ttl.md) 

## Resource Profile: TDDUI Practitioner Role 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner-role | *Version*:2.0.0-ballot |
| Active as of 2025-10-01 | *Computable Name*:TDDUIPractitionerRole |

 
Profil de la ressource FRCorePractitionerRole permettant de représenter un Professionnel. 

**Usages:**

* Refer to this Profile: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md)
* Examples for this Profile: [PractitionerRole/tddui-practitioner-role-example](PractitionerRole-tddui-practitioner-role-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-practitioner-role)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePractitionerRole](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePractitionerRole](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html) 

**Résumé**

**Structures**

This structure refers to these other structures:

* [TDDUI Practitioner(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner)](StructureDefinition-tddui-practitioner.md)
* [TDDUI Organization(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization)](StructureDefinition-tddui-organization.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-profession](StructureDefinition-tddui-profession.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [FRCorePractitionerRole](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePractitionerRole](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html) 

**Résumé**

**Structures**

This structure refers to these other structures:

* [TDDUI Practitioner(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner)](StructureDefinition-tddui-practitioner.md)
* [TDDUI Organization(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization)](StructureDefinition-tddui-organization.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-profession](StructureDefinition-tddui-profession.md)

 

Other representations of profile: [CSV](StructureDefinition-tddui-practitioner-role.csv), [Excel](StructureDefinition-tddui-practitioner-role.xlsx), [Schematron](StructureDefinition-tddui-practitioner-role.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-practitioner.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-practitioner-role-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


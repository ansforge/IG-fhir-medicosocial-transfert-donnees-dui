# Motif de l’évènement - TTL Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Motif de l’évènement**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-event-reason.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-event-reason-definitions.md) 
*  [Mappings](StructureDefinition-tddui-event-reason-mappings.md) 
*  [XML](StructureDefinition-tddui-event-reason.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-event-reason.profile.json.md) 
*  [TTL](#) 

## Extension: TDDUIEventReason - TTL Profile

| |
| :--- |
| Active as of 2025-10-06 |

TTL representation of the tddui-event-reason extension.

[Raw ttl](StructureDefinition-tddui-event-reason.ttl) | [Download](StructureDefinition-tddui-event-reason.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-event-reason.profile.json.md) | [top](#top) |  [next>](StructureDefinition-tddui-birth-order.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


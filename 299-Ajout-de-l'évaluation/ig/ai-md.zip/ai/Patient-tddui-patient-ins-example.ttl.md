# tddui-patient-ins-example - TTL Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-patient-ins-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](Patient-tddui-patient-ins-example.md) 
*  [XML](Patient-tddui-patient-ins-example.xml.md) 
*  [JSON](Patient-tddui-patient-ins-example.json.md) 
*  [TTL](#) 

## : tddui-patient-ins-example - TTL Representation

[Raw ttl](Patient-tddui-patient-ins-example.ttl) | [Download](Patient-tddui-patient-ins-example.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](Patient-tddui-patient-ins-example.json.md) | [top](#top) |  [next>](Practitioner-tddui-practitioner-example.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


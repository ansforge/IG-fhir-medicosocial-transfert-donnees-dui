# TDDUI Encounter Evenement - Mappings - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Encounter Evenement**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-encounter-evenement.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-encounter-evenement-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-tddui-encounter-evenement-examples.md) 
*  [XML](StructureDefinition-tddui-encounter-evenement.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-encounter-evenement.profile.json.md) 
*  [TTL](StructureDefinition-tddui-encounter-evenement.profile.ttl.md) 

## Resource Profile: TDDUIEncounterEvenement - Mappings

| |
| :--- |
| Active as of 2025-10-08 |

Mappings for the tddui-encounter-evenement resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-encounter-evenement-definitions.md) | [top](#top) |  [next>](StructureDefinition-tddui-encounter-evenement-testing.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


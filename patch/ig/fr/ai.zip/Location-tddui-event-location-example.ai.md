# TDDUI Event Location Example - Médicosocial - Transfert de données DUI v2.3.0

## Exemple Location: TDDUI Event Location Example

-------

**French**

-------

Profil: [FR Core Location Profile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-location.html)

**address**: 12 rue des Lilas Vittefleur 76748 FR 



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "tddui-event-location-example",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-location"]
  },
  "address" : {
    "line" : ["12 rue des Lilas"],
    "city" : "Vittefleur",
    "postalCode" : "76748",
    "country" : "FR"
  }
}

```

# tddui-pp-ime-bundle-example - Médicosocial - Transfert de données DUI v2.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-pp-ime-bundle-example**

## Example Bundle: tddui-pp-ime-bundle-example



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "tddui-pp-ime-bundle-example",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-bundle"
    ]
  },
  "type" : "transaction"
}

```

# TDDUI PP PA ServiceRequest Besoin 2 Example - Médicosocial - Transfert de données DUI v2.3.0-ballot

## Example ServiceRequest: TDDUI PP PA ServiceRequest Besoin 2 Example

Profile: [TDDUI ServiceRequest Besoin](StructureDefinition-tddui-service-request-besoin.md)

**identifier**: Identifiant du besoin/3480787529/123456789-BESO-1235

**basedOn**: [CarePlan Projet personnalisé de Mme Jeanne L.](CarePlan-tddui-pp-pa-careplan-example.md)

**status**: Active

**intent**: Plan

**code**: Besoin en terme de nutrition et alimentation.

**subject**: [Jeanne L. (official) Female, DoB: 1947-04-03 ( Patient internal identifier: 3480787529/123456789)](Patient-tddui-pp-pa-patient-example-pp.md)



## Resource Content

```json
{
  "resourceType" : "ServiceRequest",
  "id" : "tddui-pp-pa-servicerequest-besoin-2-example",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-service-request-identifier",
        "code" : "BES"
      }]
    },
    "system" : "https://identifiant-medicosocial-besoin.esante.gouv.fr",
    "value" : "3480787529/123456789-BESO-1235"
  }],
  "basedOn" : [{
    "reference" : "CarePlan/tddui-pp-pa-careplan-example"
  }],
  "status" : "active",
  "intent" : "plan",
  "code" : {
    "text" : "Besoin en terme de nutrition et alimentation."
  },
  "subject" : {
    "reference" : "Patient/tddui-pp-pa-patient-example-pp"
  }
}

```

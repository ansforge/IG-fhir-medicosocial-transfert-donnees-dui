# Volume 2 - Détail des transactions - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* **Volume 2 - Détail des transactions**

## Volume 2 - Détail des transactions

* [Synthèse des flux](description_flux_synthese.md)
* [Flux 1 - Transmission de données DUI](description_flux_1_transmission_donnees_dui.md)


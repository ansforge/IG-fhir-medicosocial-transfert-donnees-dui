# Mapping FHIR du modèle de contenu DUI - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Mapping FHIR du modèle de contenu DUI**

## Mapping FHIR du modèle de contenu DUI

 Ce mapping représente les données fonctionnelles trouvant leur équivalence dans l'actuelle version des spécifications techniques. 

### Mapping Usager

### Mapping Entité Juridique

### Mapping Professionnel

### Mapping Sejour

### Mapping Evènement

### Mapping Transport


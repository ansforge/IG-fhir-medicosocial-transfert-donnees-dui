# TDDUI Encounter Sejour - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Encounter Sejour**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-encounter-sejour-definitions.md) 
*  [Mappings](StructureDefinition-tddui-encounter-sejour-mappings.md) 
*  [Examples](StructureDefinition-tddui-encounter-sejour-examples.md) 
*  [XML](StructureDefinition-tddui-encounter-sejour.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-encounter-sejour.profile.json.md) 
*  [TTL](StructureDefinition-tddui-encounter-sejour.profile.ttl.md) 

## Resource Profile: TDDUI Encounter Sejour 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-sejour | *Version*:2.0.0-ballot |
| Active as of 2025-10-01 | *Computable Name*:TDDUIEncounterSejour |

 
Profil de la ressource Encounter permettant de regrouper les informations relatives au séjour d'un usager dans une structure ESSMS 

**Usages:**

* Use this Profile: [TDDUI Bundle](StructureDefinition-tddui-bundle.md)
* Refer to this Profile: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md)
* Examples for this Profile: [Encounter/tddui-encounter-sejour-example](Encounter-tddui-encounter-sejour-example.md)
* CapabilityStatements using this Profile: [TDDUI-Consommateur](CapabilityStatement-TDDUIConsommateur.md) and [TDDUI-Producteur](CapabilityStatement-TDDUIProducteur.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-encounter-sejour)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

**Résumé**

Mandatory: 5 elements

**Structures**

This structure refers to these other structures:

* [TDDUI Patient(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient)](StructureDefinition-tddui-patient.md)
* [TDDUI Patient INS(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins)](StructureDefinition-tddui-patient-ins.md)
* [TDDUI Organization(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization)](StructureDefinition-tddui-organization.md)

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedStartDate](http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.plannedStartDate)
* [http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedEndDate](http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.plannedEndDate)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-admission-date](StructureDefinition-tddui-admission-date.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-entry-mode-label](StructureDefinition-tddui-entry-mode-label.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-exit-mode-label](StructureDefinition-tddui-exit-mode-label.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment](StructureDefinition-tddui-comment.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.identifier

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Encounter](http://hl7.org/fhir/R4/encounter.html) 

**Résumé**

Mandatory: 5 elements

**Structures**

This structure refers to these other structures:

* [TDDUI Patient(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient)](StructureDefinition-tddui-patient.md)
* [TDDUI Patient INS(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins)](StructureDefinition-tddui-patient-ins.md)
* [TDDUI Organization(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization)](StructureDefinition-tddui-organization.md)

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedStartDate](http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.plannedStartDate)
* [http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedEndDate](http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.plannedEndDate)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-admission-date](StructureDefinition-tddui-admission-date.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-entry-mode-label](StructureDefinition-tddui-entry-mode-label.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-exit-mode-label](StructureDefinition-tddui-exit-mode-label.md)
* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment](StructureDefinition-tddui-comment.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.identifier

 

Other representations of profile: [CSV](StructureDefinition-tddui-encounter-sejour.csv), [Excel](StructureDefinition-tddui-encounter-sejour.xlsx), [Schematron](StructureDefinition-tddui-encounter-sejour.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-encounter-evenement.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-encounter-sejour-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


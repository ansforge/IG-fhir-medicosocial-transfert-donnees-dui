# TDDUI Patient - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Patient**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-patient-definitions.md) 
*  [Mappings](StructureDefinition-tddui-patient-mappings.md) 
*  [Examples](StructureDefinition-tddui-patient-examples.md) 
*  [XML](StructureDefinition-tddui-patient.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-patient.profile.json.md) 
*  [TTL](StructureDefinition-tddui-patient.profile.ttl.md) 

## Resource Profile: TDDUI Patient 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient | *Version*:2.0.0-ballot |
| Active as of 2025-10-02 | *Computable Name*:TDDUIPatient |

 
Profil de la ressource FrCorePatientProfile permettant de représenter un usager lorsque l'INS n'est pas transmis. 

**Usages:**

* Use this Profile: [TDDUI Bundle](StructureDefinition-tddui-bundle.md)
* Refer to this Profile: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md) and [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md)
* Examples for this Profile: [Patient/tddui-patient-example](Patient-tddui-patient-example.md)
* CapabilityStatements using this Profile: [TDDUI-Consommateur](CapabilityStatement-TDDUIConsommateur.md) and [TDDUI-Producteur](CapabilityStatement-TDDUIProducteur.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-patient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePatientProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePatientProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient.html) 

**Résumé**

Mandatory: 2 elements(5 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [TDDUI Human Name DataType(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-human-name)](StructureDefinition-tddui-human-name.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-birth-order](StructureDefinition-tddui-birth-order.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [FRCorePatientProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePatientProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient.html) 

**Résumé**

Mandatory: 2 elements(5 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [TDDUI Human Name DataType(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-human-name)](StructureDefinition-tddui-human-name.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-birth-order](StructureDefinition-tddui-birth-order.md)

 

Other representations of profile: [CSV](StructureDefinition-tddui-patient.csv), [Excel](StructureDefinition-tddui-patient.xlsx), [Schematron](StructureDefinition-tddui-patient.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-organization.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-patient-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


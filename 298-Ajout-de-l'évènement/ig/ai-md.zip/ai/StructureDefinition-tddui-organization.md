# TDDUI Organization - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Organization**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-organization-definitions.md) 
*  [Mappings](StructureDefinition-tddui-organization-mappings.md) 
*  [Examples](StructureDefinition-tddui-organization-examples.md) 
*  [XML](StructureDefinition-tddui-organization.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-organization.profile.json.md) 
*  [TTL](StructureDefinition-tddui-organization.profile.ttl.md) 

## Resource Profile: TDDUI Organization 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization | *Version*:2.0.0-ballot |
| Active as of 2025-10-08 | *Computable Name*:TDDUIOrganization |

 
Profil de la ressource FRCoreOrganizationProfile permettant de représenter les entités juridiques. 

**Usages:**

* Use this Profile: [TDDUI Bundle](StructureDefinition-tddui-bundle.md)
* Refer to this Profile: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md), [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md), [TDDUI Practitioner Role](StructureDefinition-tddui-practitioner-role.md) and [TDDUI Task Transport](StructureDefinition-tddui-task-transport.md)
* Examples for this Profile: [Les Chênes Verts](Organization-tddui-organization-example.md)
* CapabilityStatements using this Profile: [TDDUI-Consommateur](CapabilityStatement-TDDUIConsommateur.md) and [TDDUI-Producteur](CapabilityStatement-TDDUIProducteur.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-organization)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreOrganizationProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreOrganizationProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html) 

**Résumé**

Mandatory: 2 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [FRCoreOrganizationProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreOrganizationProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html) 

**Résumé**

Mandatory: 2 elements

 

Other representations of profile: [CSV](StructureDefinition-tddui-organization.csv), [Excel](StructureDefinition-tddui-organization.xlsx), [Schematron](StructureDefinition-tddui-organization.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-encounter-sejour.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-organization-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


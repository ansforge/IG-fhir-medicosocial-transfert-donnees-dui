# TDDUI Practitioner - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Practitioner**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-practitioner-definitions.md) 
*  [Mappings](StructureDefinition-tddui-practitioner-mappings.md) 
*  [Examples](StructureDefinition-tddui-practitioner-examples.md) 
*  [XML](StructureDefinition-tddui-practitioner.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-practitioner.profile.json.md) 
*  [TTL](StructureDefinition-tddui-practitioner.profile.ttl.md) 

## Resource Profile: TDDUI Practitioner 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner | *Version*:2.0.0-ballot |
| Active as of 2025-10-07 | *Computable Name*:TDDUIPractitioner |

 
Profil de la ressource FRCorePractitionerProfile permettant de représenter un Profesionnel. 

**Usages:**

* Refer to this Profile: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md), [TDDUI Practitioner Role](StructureDefinition-tddui-practitioner-role.md) and [TDDUI Task Transport Professionnel](StructureDefinition-tddui-task-transport-professionnel.md)
* Examples for this Profile: [Practitioner/tddui-practitioner-example](Practitioner-tddui-practitioner-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-practitioner)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePractitionerProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePractitionerProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner.html) 

**Résumé**

Mandatory: 2 elements

**Structures**

This structure refers to these other structures:

* [TDDUI Human Name DataType(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-human-name)](StructureDefinition-tddui-human-name.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [FRCorePractitionerProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCorePractitionerProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner.html) 

**Résumé**

Mandatory: 2 elements

**Structures**

This structure refers to these other structures:

* [TDDUI Human Name DataType(https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-human-name)](StructureDefinition-tddui-human-name.md)

 

Other representations of profile: [CSV](StructureDefinition-tddui-practitioner.csv), [Excel](StructureDefinition-tddui-practitioner.xlsx), [Schematron](StructureDefinition-tddui-practitioner.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-patient-ins.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-practitioner-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


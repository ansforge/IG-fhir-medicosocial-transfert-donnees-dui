# tddui-encounter-sejour-example - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-encounter-sejour-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](Encounter-tddui-encounter-sejour-example.xml.md) 
*  [JSON](Encounter-tddui-encounter-sejour-example.json.md) 
*  [TTL](Encounter-tddui-encounter-sejour-example.ttl.md) 

## Example Encounter: tddui-encounter-sejour-example

Profil: [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md)

**Date d’admission**: 2023-04-11

**Libellé mode d'entrée**: Date de début du suivi post-opératoire : 14/04/2023

**Libellé mode de sortie**: Sortie prévisionnelle prévue pour le 5 mai 2023

**Extension Definition for Encounter.plannedEndDate for Version 5.0**: 2023-05-05

**identifier**: Identifiant du séjour/3480787529/147720425367411-SEJOUR-1012

**status**: In Progress

**class**: [ActCode HH](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html#v3-ActCode-HH): home health

**subject**: [DUPONT Male, Date de Naissance :1947-04-03 ( NIR définitif (use: official, ))](Patient-tddui-patient-ins-example.md)

**period**: 2023-04-14 --> (ongoing)

**serviceProvider**: [Organization Les Chênes Verts](Organization-tddui-organization-example.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](Encounter-tddui-encounter-evenement-example.ttl.md) | [top](#top) |  [next>](Encounter-tddui-encounter-sejour-example.xml.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


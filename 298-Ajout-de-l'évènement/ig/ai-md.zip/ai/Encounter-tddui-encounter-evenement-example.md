# tddui-encounter-evenement-example - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-encounter-evenement-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](Encounter-tddui-encounter-evenement-example.xml.md) 
*  [JSON](Encounter-tddui-encounter-evenement-example.json.md) 
*  [TTL](Encounter-tddui-encounter-evenement-example.ttl.md) 

## Example Encounter: tddui-encounter-evenement-example

Profil: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md)

> **Ressources utilisées**
* TDDUIRessourceType: Vehicle

**Rapport de l’évènement**: Observations cliniques : ; Recommandations pour les jours à venir : ; Prochaine visite : 15 avril 2023, 10h30 ; Remarque : Monsieur Dupont a compris les consignes pour la gestion de sa douleur et la mobilisation de sa hanche opérée.

**Commentaire**: Cet évènement a débuté plus tard l’usager était sous la douche à l’heure du début du rendez-vous.

**Libellé de l'évènement**: Visite à domicile pour soins infirmier.

**Motif de l’évènement**: Suivi post-opératoire suite à intervention chirurgicale de la hanche.

**identifier**: Visit Number/3480787529/147720425367411-EVN-12548

**status**: Finished

**class**: [ActCode HH](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html#v3-ActCode-HH): home health

**type**: Intervention d'un infirmer salarié, Intervention

**subject**: [DUPONT Male, Date de Naissance :1947-04-03 ( NIR définitif (use: official, ))](Patient-tddui-patient-ins-example.md)

### Participants

| | |
| :--- | :--- |
| - | **Individual** |
| * | [Practitioner Claire Martin](Practitioner-tddui-practitioner-example.md) |

**period**: 2023-04-14 10:30:00+0200 --> 2023-04-14 11:15:00+0200

### Locations

| | |
| :--- | :--- |
| - | **Location** |
| * | [Location](Location-tddui-event-location-example.md) |

**serviceProvider**: [Organization Les Chênes Verts](Organization-tddui-organization-example.md)

**partOf**: [Encounter : extension = 2023-04-11,Date de début du suivi post-opératoire : 14/04/2023,Sortie prévisionnelle prévue pour le 5 mai 2023,2023-05-05; identifier = Identifiant du séjour: 3480787529/147720425367411-SEJOUR-1012; status = in-progress; class = home health (ActCode#HH); period = 2023-04-14 --> (ongoing)](Encounter-tddui-encounter-sejour-example.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-tddui-identifier.ttl.md) | [top](#top) |  [next>](Encounter-tddui-encounter-evenement-example.xml.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


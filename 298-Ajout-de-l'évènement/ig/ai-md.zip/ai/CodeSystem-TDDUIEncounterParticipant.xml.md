# TDDUI Encounter Participant Type - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI Encounter Participant Type**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](CodeSystem-TDDUIEncounterParticipant.md) 
*  [XML](#) 
*  [JSON](CodeSystem-TDDUIEncounterParticipant.json.md) 
*  [TTL](CodeSystem-TDDUIEncounterParticipant.ttl.md) 

## : TDDUI Encounter Participant Type - XML Representation

| |
| :--- |
| Active as of 2025-10-07 |

[Raw xml](CodeSystem-TDDUIEncounterParticipant.xml) | [Download](CodeSystem-TDDUIEncounterParticipant.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-TDDUIEncounterParticipant-testing.md) | [top](#top) |  [next>](CodeSystem-TDDUIEncounterParticipant.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Libellé de l'évènement - Definitions - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Libellé de l'évènement**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-event-label.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-tddui-event-label-mappings.md) 
*  [XML](StructureDefinition-tddui-event-label.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-event-label.profile.json.md) 
*  [TTL](StructureDefinition-tddui-event-label.profile.ttl.md) 

## Extension: TDDUIEventLabel - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-02 |

Definitions for the tddui-event-label extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-event-label.md) | [top](#top) |  [next>](StructureDefinition-tddui-event-label-mappings.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


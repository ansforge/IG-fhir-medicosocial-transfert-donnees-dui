# Ressources utilisées - Mappings - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ressources utilisées**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-ressources-used.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-ressources-used-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-tddui-ressources-used.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-ressources-used.profile.json.md) 
*  [TTL](StructureDefinition-tddui-ressources-used.profile.ttl.md) 

## Extension: TDDUIRessourcesUsed - Mappings

| |
| :--- |
| Active as of 2025-10-02 |

Mappings for the tddui-ressources-used extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-ressources-used-definitions.md) | [top](#top) |  [next>](StructureDefinition-tddui-ressources-used-testing.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Ordre de naissance dans le registre d'état civil - TTL Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ordre de naissance dans le registre d'état civil**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-birth-order.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-birth-order-definitions.md) 
*  [Mappings](StructureDefinition-tddui-birth-order-mappings.md) 
*  [XML](StructureDefinition-tddui-birth-order.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-birth-order.profile.json.md) 
*  [TTL](#) 

## Extension: TDDUIBirthOrder - TTL Profile

| |
| :--- |
| Active as of 2025-10-01 |

TTL representation of the tddui-birth-order extension.

[Raw ttl](StructureDefinition-tddui-birth-order.ttl) | [Download](StructureDefinition-tddui-birth-order.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-birth-order.profile.json.md) | [top](#top) |  [next>](StructureDefinition-tddui-attachment.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


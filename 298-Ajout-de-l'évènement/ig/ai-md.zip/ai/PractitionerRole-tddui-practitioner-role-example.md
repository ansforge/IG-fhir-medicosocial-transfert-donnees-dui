# tddui-practitioner-role-example - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-practitioner-role-example**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](PractitionerRole-tddui-practitioner-role-example.xml.md) 
*  [JSON](PractitionerRole-tddui-practitioner-role-example.json.md) 
*  [TTL](PractitionerRole-tddui-practitioner-role-example.ttl.md) 

## Example PractitionerRole: tddui-practitioner-role-example

Profil: [TDDUI Practitioner Role](StructureDefinition-tddui-practitioner-role.md)

**Mode d'exercice**: Salarié

**practitioner**: [Practitioner Claire Martin](Practitioner-tddui-practitioner-example.md)

**organization**: [Organization Les Chênes Verts](Organization-tddui-organization-example.md)

**code**: Coordonnateur de parcours

| | | |
| :--- | :--- | :--- |
|  [<prev](Practitioner-tddui-practitioner-example.ttl.md) | [top](#top) |  [next>](PractitionerRole-tddui-practitioner-role-example.xml.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Documents de référence - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Documents de référence**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Documents de référence

* [Annexe – Source des données personnes et structures](https://esante.gouv.fr/annexe-sources-des-donnees-personnes-et-structures)
* [Annexe – Prise en Charge de l'INS dans les volets du CI-SIS](https://esante.gouv.fr/annexe-prise-en-charge-de-lins-dans-les-volets-du-ci-sis)
* [Référentiel Identifiant national de santé](https://industriels.esante.gouv.fr/sites/default/files/media/document/asip_referentiel_identifiant_national_sante-liste-des-oid-des-autorites-d-affectation-des-ins_v0.1.pdf)
* [Terminologies de Santé](https://interop.esante.gouv.fr/terminologies/)
* [Site de l'ANS](https://esante.gouv.fr/)
* [Spécifications FHIR](https://hl7.org/fhir/R4/index.html)
* [Documentation des guides d'implémentation de l'ANS](https://interop.esante.gouv.fr/ig/documentation/)

| | | |
| :--- | :--- | :--- |
|  [<prev](mapping_fonctionnel_FHIR.md) | [top](#top) |  [next>](annexes_acronymes.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Pièce jointe de l’évènement - JSON Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pièce jointe de l’évènement**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-attachment.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-attachment-definitions.md) 
*  [Mappings](StructureDefinition-tddui-attachment-mappings.md) 
*  [XML](StructureDefinition-tddui-attachment.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-tddui-attachment.profile.ttl.md) 

## Extension: TDDUIAttachment - JSON Profile

| |
| :--- |
| Active as of 2025-10-02 |

JSON representation of the tddui-attachment extension.

[Raw json](StructureDefinition-tddui-attachment.json) | [Download](StructureDefinition-tddui-attachment.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-attachment.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-tddui-attachment.profile.ttl.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# InputTaskTransportCodeSystem - XML Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **InputTaskTransportCodeSystem**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](CodeSystem-input-tddui-task-transport-codesystem.md) 
*  [XML](#) 
*  [JSON](CodeSystem-input-tddui-task-transport-codesystem.json.md) 
*  [TTL](CodeSystem-input-tddui-task-transport-codesystem.ttl.md) 

## : InputTaskTransportCodeSystem - XML Representation

| |
| :--- |
| Active as of 2025-10-08 |

[Raw xml](CodeSystem-input-tddui-task-transport-codesystem.xml) | [Download](CodeSystem-input-tddui-task-transport-codesystem.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-input-tddui-task-transport-codesystem-testing.md) | [top](#top) |  [next>](CodeSystem-input-tddui-task-transport-codesystem.json.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


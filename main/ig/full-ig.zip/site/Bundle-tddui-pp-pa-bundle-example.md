# tddui-pp-pa-bundle-example - Médicosocial - Transfert de données DUI v2.2.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **tddui-pp-pa-bundle-example**

## Example Bundle: tddui-pp-pa-bundle-example



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "tddui-pp-pa-bundle-example",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-bundle"
    ]
  },
  "type" : "transaction",
  "entry" : [
    {
      "fullUrl" : "https://test-server.fr/Patient/tddui-pp-pa-patient-example-pp",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "tddui-pp-pa-patient-example-pp",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_tddui-pp-pa-patient-example-pp\"> </a><p class=\"res-header-id\"><b>Narratif généré : Patient tddui-pp-pa-patient-example-pp</b></p><a name=\"tddui-pp-pa-patient-example-pp\"> </a><a name=\"hctddui-pp-pa-patient-example-pp\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-patient.html\">TDDUI Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</p><hr/></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "PI",
                  "display" : "Patient internal identifier"
                }
              ]
            },
            "system" : "https://identifiant-medicosocial-localusager.esante.gouv.fr",
            "value" : "3480787529/123456789"
          }
        ],
        "name" : [
          {
            "use" : "official",
            "family" : "L.",
            "given" : ["Jeanne"]
          }
        ],
        "gender" : "female"
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIPatient"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Consent/tddui-pp-pa-consent-accord-example",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "tddui-pp-pa-consent-accord-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-consent-accord"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_tddui-pp-pa-consent-accord-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Consent tddui-pp-pa-consent-accord-example</b></p><a name=\"tddui-pp-pa-consent-accord-example\"> </a><a name=\"hctddui-pp-pa-consent-accord-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-consent-accord.html\">TDDUI Consent Accord</a></p></div><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/consentscope patient-privacy}\">Privacy Consent</span></p><p><b>category</b>: <span title=\"Codes :{http://loinc.org 59284-0}\">Consent Document</span></p><p><b>dateTime</b>: 2024-01-15 09:00:00+0100</p><p><b>performer</b>: <a href=\"Practitioner-tddui-pp-pa-practitioner-ide-example.html\">Practitioner Élodie Bernard </a></p><h3>Policies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Authority</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://www.cnsa.fr/\">https://www.cnsa.fr/</a></td></tr></table></div>"
        },
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "patient-privacy",
              "display" : "Privacy Consent"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "59284-0"
              }
            ]
          }
        ],
        "dateTime" : "2024-01-15T09:00:00+01:00",
        "performer" : [
          {
            "reference" : "Practitioner/tddui-pp-pa-practitioner-ide-example"
          }
        ],
        "policy" : [
          {
            "authority" : "https://www.cnsa.fr/"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIConsentAccord"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/CarePlan/tddui-pp-pa-careplan-example",
      "resource" : {
        "resourceType" : "CarePlan",
        "id" : "tddui-pp-pa-careplan-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-projet-personnalise"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_tddui-pp-pa-careplan-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : PlanDeSoins tddui-pp-pa-careplan-example</b></p><a name=\"tddui-pp-pa-careplan-example\"> </a><a name=\"hctddui-pp-pa-careplan-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-careplan-projet-personnalise.html\">TDDUI CarePlan Projet Personalise</a></p></div><p><b>Pièce jointe</b>: <a href=\"DocumentReference-tddui-pp-pa-documentreference-entrant-example.html\">DocumentReference : masterIdentifier = 3480787529/123456789-PPER-entrant-1234; status = current</a></p><p><b>identifier</b>: <code>https://identifiant-medicosocial-projetpersonnalise.esante.gouv.fr</code>/3480787529/123456789-PPER-1234</p><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>title</b>: Projet personnalisé de Mme Jeanne L.</p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>supportingInfo</b>: <a href=\"Consent-tddui-pp-pa-consent-accord-example.html\">Consent : status = active; scope = Privacy Consent; category = Consent Document; dateTime = 2024-01-15 09:00:00+0100</a></p></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-attachment",
            "valueReference" : {
              "reference" : "DocumentReference/tddui-pp-pa-documentreference-entrant-example"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-projetpersonnalise.esante.gouv.fr",
            "value" : "3480787529/123456789-PPER-1234"
          }
        ],
        "status" : "active",
        "intent" : "plan",
        "title" : "Projet personnalisé de Mme Jeanne L.",
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "supportingInfo" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-discriminator",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-discriminator-cs",
                      "code" : "accordStructure"
                    }
                  ]
                }
              }
            ],
            "reference" : "Consent/tddui-pp-pa-consent-accord-example"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUICarePlanProjetPersonnalise"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/DocumentReference/tddui-pp-pa-documentreference-bilan-objectif-1-example",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "tddui-pp-pa-documentreference-bilan-objectif-1-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_tddui-pp-pa-documentreference-bilan-objectif-1-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : RéférenceDocument tddui-pp-pa-documentreference-bilan-objectif-1-example</b></p><a name=\"tddui-pp-pa-documentreference-bilan-objectif-1-example\"> </a><a name=\"hctddui-pp-pa-documentreference-bilan-objectif-1-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-document-reference.html\">TDDUI DocumentReference</a></p></div><p><b>masterIdentifier</b>: 3480787529/123456789-PPER-bilanObj-1234</p><p><b>status</b>: Current</p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>author</b>: <a href=\"Organization-tddui-organization-example.html\">Organization Les Chênes Verts</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Language</b></td><td><b>Data</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>application/pdf</td><td>French</td><td>(données base64 - 75,368 caractères base64)</td><td>bilanobj1.pdf</td></tr></table></blockquote></div>"
        },
        "masterIdentifier" : {
          "value" : "3480787529/123456789-PPER-bilanObj-1234"
        },
        "status" : "current",
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "author" : [
          {
            "reference" : "Organization/tddui-organization-example"
          }
        ],
        "content" : [
          {
            "attachment" : {
              "contentType" : "application/pdf",
              "language" : "fr",
              "data" : "JVBERi0xLjUNCiW1tbW1DQoxIDAgb2JqDQo8PC9UeXBlL0NhdGFsb2cvUGFnZXMgMiAwIFIvTGFuZyhlbi1VUykgL1N0cnVjdFRyZWVSb290IDE1IDAgUi9NYXJrSW5mbzw8L01hcmtlZCB0cnVlPj4+Pg0KZW5kb2JqDQoyIDAgb2JqDQo8PC9UeXBlL1BhZ2VzL0NvdW50IDEvS2lkc1sgMyAwIFJdID4+DQplbmRvYmoNCjMgMCBvYmoNCjw8L1R5cGUvUGFnZS9QYXJlbnQgMiAwIFIvUmVzb3VyY2VzPDwvRm9udDw8L0YxIDUgMCBSL0YyIDEyIDAgUj4+L0V4dEdTdGF0ZTw8L0dTMTAgMTAgMCBSL0dTMTEgMTEgMCBSPj4vUHJvY1NldFsvUERGL1RleHQvSW1hZ2VCL0ltYWdlQy9JbWFnZUldID4+L01lZGlhQm94WyAwIDAgNjEyIDc5Ml0gL0NvbnRlbnRzIDQgMCBSL0dyb3VwPDwvVHlwZS9Hcm91cC9TL1RyYW5zcGFyZW5jeS9DUy9EZXZpY2VSR0I+Pi9UYWJzL1MvU3RydWN0UGFyZW50cyAwPj4NCmVuZG9iag0KNCAwIG9iag0KPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAzNzU+Pg0Kc3RyZWFtDQp4nK1S20rDQBB9X9h/mMdEaDK73WQbW/LQpC0KBcWAD+JDqbEtmKT28n/+jn/hTJJKpRUUGsjJnNm5nJkN+HcwGPjT5CYFjGMYpgm8S4Ee8hMpDQghoY00bHIpHq+glGKYSeGPFSj0ghCyVykUxSEosIGH2oClk6gHWUFxkweFsNhSUVg0VLV0IsXTAFEHiCaJO4ZsM44j/hjEQMWWTOwStbVpekwbc4w4DGsz0ESDxptyUGOGdNKmJfRG38VU2rSiSs+Q3Uoxomnupfjr2PrM2Fp1PWuPx66HbUZ0wP3RCEbTBOBo8eqfiz+noF18GEWeOhHwAW7HOKEbOVC41qlWBFsguGZAhvmSYL8jyJn264wZZdS+qmTg3FVOAHOme4K3in0b9hWHjB2XL9sq1slqymk7LrVinzYEvuaMHqvqcwH3YtdxWEbPelqfbGO25r5r6rv5pL5LllZuWVp1EF6w9cKndUjuXU6bRusZ9Zu2c7/KF6T7vgsNCmVuZHN0cmVhbQ0KZW5kb2JqDQo1IDAgb2JqDQo8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMC9CYXNlRm9udC9BQkNERUUrQ291cmllck5ld1BTTVQvRW5jb2RpbmcvSWRlbnRpdHktSC9EZXNjZW5kYW50Rm9udHMgNiAwIFIvVG9Vbmljb2RlIDIzIDAgUj4+DQplbmRvYmoNCjYgMCBvYmoNClsgNyAwIFJdIA0KZW5kb2JqDQo3IDAgb2JqDQo8PC9CYXNlRm9udC9BQkNERUUrQ291cmllck5ld1BTTVQvU3VidHlwZS9DSURGb250VHlwZTIvVHlwZS9Gb250L0NJRFRvR0lETWFwL0lkZW50aXR5L0RXIDEwMDAvQ0lEU3lzdGVtSW5mbyA4IDAgUi9Gb250RGVzY3JpcHRvciA5IDAgUi9XIDI1IDAgUj4+DQplbmRvYmoNCjggMCBvYmoNCjw8L09yZGVyaW5nKElkZW50aXR5KSAvUmVnaXN0cnkoQWRvYmUpIC9TdXBwbGVtZW50IDA+Pg0KZW5kb2JqDQo5IDAgb2JqDQo8PC9UeXBlL0ZvbnREZXNjcmlwdG9yL0ZvbnROYW1lL0FCQ0RFRStDb3VyaWVyTmV3UFNNVC9GbGFncyAzMi9JdGFsaWNBbmdsZSAwL0FzY2VudCA4MzMvRGVzY2VudCAtMTg4L0NhcEhlaWdodCA2MTMvQXZnV2lkdGggNjAwL01heFdpZHRoIDc0NC9Gb250V2VpZ2h0IDQwMC9YSGVpZ2h0IDI1MC9TdGVtViA2MC9Gb250QkJveFsgLTEyMiAtMTg4IDYyMyA2MTNdIC9Gb250RmlsZTIgMjQgMCBSPj4NCmVuZG9iag0KMTAgMCBvYmoNCjw8L1R5cGUvRXh0R1N0YXRlL0JNL05vcm1hbC9jYSAxPj4NCmVuZG9iag0KMTEgMCBvYmoNCjw8L1R5cGUvRXh0R1N0YXRlL0JNL05vcm1hbC9DQSAxPj4NCmVuZG9iag0KMTIgMCBvYmoNCjw8L1R5cGUvRm9udC9TdWJ0eXBlL1RydWVUeXBlL05hbWUvRjIvQmFzZUZvbnQvQUJDREVFK0NvdXJpZXJOZXdQU01UL0VuY29kaW5nL1dpbkFuc2lFbmNvZGluZy9Gb250RGVzY3JpcHRvciAxMyAwIFIvRmlyc3RDaGFyIDMyL0xhc3RDaGFyIDIzMy9XaWR0aHMgMjYgMCBSPj4NCmVuZG9iag0KMTMgMCBvYmoNCjw8L1R5cGUvRm9udERlc2NyaXB0b3IvRm9udE5hbWUvQUJDREVFK0NvdXJpZXJOZXdQU01UL0ZsYWdzIDMyL0l0YWxpY0FuZ2xlIDAvQXNjZW50IDgzMy9EZXNjZW50IC0xODgvQ2FwSGVpZ2h0IDYxMy9BdmdXaWR0aCA2MDAvTWF4V2lkdGggNzQ0L0ZvbnRXZWlnaHQgNDAwL1hIZWlnaHQgMjUwL1N0ZW1WIDYwL0ZvbnRCQm94WyAtMTIyIC0xODggNjIzIDYxM10gL0ZvbnRGaWxlMiAyNCAwIFI+Pg0KZW5kb2JqDQoxNCAwIG9iag0KPDwvQ3JlYXRvcij+/wBNAGkAYwByAG8AcwBvAGYAdACuACAAVwBvAHIAZAAgADIAMAAxADYpIC9DcmVhdGlvbkRhdGUoRDoyMDI1MTEyNzE1NTA1OSswMScwMCcpIC9Nb2REYXRlKEQ6MjAyNTExMjcxNTUwNTkrMDEnMDAnKSAvUHJvZHVjZXIo/v8ATQBpAGMAcgBvAHMAbwBmAHQArgAgAFcAbwByAGQAIAAyADAAMQA2KSA+Pg0KZW5kb2JqDQoyMSAwIG9iag0KPDwvVHlwZS9PYmpTdG0vTiA3L0ZpcnN0IDQ2L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjk5Pj4NCnN0cmVhbQ0KeJyNUlFrwjAQfhf8D/cPLunWrYIIYyobYpFW2IP4ENtbLbaJxBT03y9nKxb0YRCS+y7f9+XuiByBgCCAUIKMQIoAZOjXCOQbBKEA+Q6vkQ8FhGIE4zGumCcgwRRXuL4cCVNnm8zNKqpxsQGxBVwV8MKcyWQ4+IdEPpWEN4my7qmKK0+4dn9soRP2iGtLlBjjMDEVLdWRW2JLb0j6esvdcYbdotamdxvT2S3oArKznnsvbRxhzNtM53ew9tSdOWNKmcMvUjnZNmbNLf7WVakp3SuukBMf2jsoVxrdYevKX+WDK/ox9rAz5oBTkzW1r+maOe2JXDuTpcqs6eHPvd97eFqqyhS9RFqVOfW47TueVlhV47wsGktdr3FTnzb8M8R9ug8jHw7+AHYlrUINCmVuZHN0cmVhbQ0KZW5kb2JqDQoyMyAwIG9iag0KPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAzMDY+Pg0Kc3RyZWFtDQp4nGVSy27DIBC88xUc00NkQ3CiSJal1GkkH/pQ3X6ADesUqcYIk4P/vnhJ0zRBMmi8M7OrgaSs9pXRniZvbpA1eNppoxyMw8lJoC0ctSFMUKWlPyPcZd9YkgRxPY0e+sp0A8lzmryH4ujdRBc7NbTwQJJXp8Bpc6SLz7IOuD5Z+w09GE9TUhRUQReMnhv70vRAE5QtKxXq2k/LoPljfEwWKEfM4jByUDDaRoJrzBFInoZV0PwQVkHAqJv6KqraTn41DtmrwE5TnhYzYntEqx0iniESHJ3OGv7rcGkoRKRt8Vgz1Ioy/oyG6+3ZIorY7RTiEGnldSd21yljSMt4ZD/9M+W3ptkGaRuBAz2uA+Ip2163mAOa7/GSvjw5F4LHy8bE56y1gct7sIOdVfP3A7TQrLMNCmVuZHN0cmVhbQ0KZW5kb2JqDQoyNCAwIG9iag0KPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA1MTQxOC9MZW5ndGgxIDExMjUwMD4+DQpzdHJlYW0NCnic7Hx5fIzX9/8595kkI2QVhIjMGImQxL7GkMlmiyUkmEErixDFR9RSS5FqdYkouqAoWm0/bVGTSCtBK0oXSnVBF/qhLdVWVTfdSJ7f+96ZiYhq+3v9vn98f99vn+O8733ufs8999xznySIiSgEYCBbSsaAfgetWycSP1ZJFF7WLyW174S94z4keruYSFvYL31oRsKvyzcRvdeA6J5n+2WMSHqvOHs28cgyomTfoRntOzWMLbydiN9Eq1kjUwbbO5UObk0U8QhR0CO5U7MLTse81JGoYzSReDJ39kzT8/55IUSpY4l8iicUTJw69slsf6LOh4m8D03MnlFAMVQP/TdHe4ETp8ydcHRtdinRoC+JurXLz8sef3au3wvobxDyu+UjwfcFPoD3e/DeKn/qzDnvPLJzHvpCf+FTpkzLzV474anfie4OxXv+1Ow5BQ2b138R5Z9FedPUvJnZ2iavbPQXK8f/r+ypefH3DJ9OtKmQKG5ewbQZM6ujaATRkauyfMHteQXbK5tg7PFriHz3k5Sl94UlvwwuSxoXYL1srGck+WyOHJYtwxPtHwjQfX5fYbhijMFrPVVePgi9n6t6DItwRPfRRxuu1OR4Hk2m+O+gQgokG94EwvbkQMbX6FcgVzMc4RXkRUavtV6d0WS4K9SyaYII9vISPlo9IbyEwXCG2umVNCdZjQBP5uBkE9o0RR42nK9eKEciJtqIdV1H7RzDQ3Km1MhwhCbK0gjlgC+wL+2ms+Bq/lTcwnH0Ga3gGNrFR+gLOoecLbSfTtABDqb36Tw35CPcg3Iojx7hhvQBBdEoWkQbyE4bMafJqLEFsymkUGpH+bQDbKcKWk4ZmGckpVMuHRe96XO2omXiPbSC4lBjIWp8QAuwIi9TGe3FaBrRFFqJvELkHqWHaAz1oh7o9VG6yI8KKz+CMkGgRWhf9pSBlq7RFtRz0S43ydY8NMZNV3kYRnEnLedpatRKLLybE9BPMMY6FS3l0CPg0eSE/najf9OnHM1R1BuzKaAv+ALm+QCVYCwZmNki1JNjygcH00r9e8z/JFdxJNpZh5HnQvI+NFlkkj81pCuQZAydQVtBmINkO6TnonxFGYp2sRV9WjkeylHCu7gXH4P0RqLPCkjmOF0UVr2K7kLrj6K/OKyeP8/mEZzr1ji5LgvQpiy9CPOUvFA/Jw6gzxWKN+C9Cr0XKi5Eyx5uB7lJzofU7KgnWbazHCsiOQNSlIxRKF6EGY6GvF7kMFpD79B8/RwHI+5Pghd4WCI9B1k9RitEuNwgIlyES3Sx5+EFyJWl1XOz+M0fMdETAQW4+QWsdxT2HXYeJ1I5Zikwv40cgHHXw6ogGeu1G3mCJ/EkegG6IWXkkZxHSi5JLajhydDdydQHct5di19GjTJo1l7IyiPPQrc8PTJ1yXNejSw9HAl9l2v6geo/GBqXTgXYlTLdw8iHflnpfoy+AcrVpzBhhH7sZiPZ9KuYT6L+M7XVj9EPaqfmocfjapc6IA25Rx/GOMZDbw5gDLnoIZysyM2lHKzaUt5No9hAfXkkLaUdIgCakkiZNJBTMfZDGPcorGEqzeJoxFaCZylNXgSqUHq8hSyQfxDdQbHoRY5AWouBZNev0O0UDboDJUIxItcoFmEUsWocDmqDk8yg1m4UtLsxxrsCspsPvRqNMARv8aA51JkiUH8lWFqSZzD+OzDPwdSXzKA0tP4MLaZWdDdqPYja0p68DItQRp31b7Fic1BjMnpegx3ekfKF/QZqrDgOWv2AsGqL6Xk+DN3ewI1oM23iO3gAVjefZ2CtyqgSVmMJ9l9zGor4D/Q7/YeepNdoKx2mTVjlJcjdS7/QGL4D5R/VL+oXUe4w5CX5HUWelidyfK12l6g2ZYs17aGNDcj7nbaKZC7mLG7Fb/AbdEVgU/EpXg0+xZvBh/gkf8TjYdl+4kWcyd3ZyD7cmlbx9/SFGMjv8o/sx605CCt7bf8dEppgofGT/BRv4ak8HGnrOYezoHuRqkh98lYlAzEO+ayA5OXeko8vSD7Pw1J+R6vB36HUBuwFEEYi7bQrfTXfzccx8mf5EMqHYx1iakJP/L/gwdjXsy/LUYVgl/vSW5DQamh+Je/hX9U4lbFA3D0/fhP+h2eunjT3XG8IN/AwyUoGkr1dsqkJ6z4N3PJxh9yMm9cOPbKF9p5QYRn2u8w30nQVlnKpSq+GVsv3H5WvRHI+ai7P02z1PhF7dDE9QethScCiKVYbekHZNAjyOAnd8IMGbIYkboF/4IV1OAQ6jtW4G7myl/W0nr/my3wZ+3syv8g/8eccJXIhNSf2TSJF8RmkfM7f8j60+AaksAF9fQC/4W06wrfxTIzwCO3BGK3Q5QeggUH0LbR9D+gNWgv7cS/fAnoFtIfX8ulr0q6RgtQUKedwpQ/E/UB2+pE+5l+xXm8jSdpT2E2M4TFewwf4La6EHXwNmlvBMdgZoXwrp2gL6E1VfyO/zE/zft4JilEUrUivoQOQQO33a5SE0uCa8/Pvcu2z44/4HKySPDM8p8Pf5bonR23OVX6Hi+UYZB83qcPtOYQug2ELYZ9DYEfnKJ4MykF9yenQ7DawrfK8S8KY0Rb0oZjHcH/eC+qv6A61i6QmerSxzi76u+FNd9tf7MI/5NXgdbV26M247s79ix18w479q1DuaA97geTjsZruXX5D6LGmfxHWWIebhB5r8VdhjTxhVeB1/qjiCMFv1qzrzTgAu9RtTd3r77JEMhztInni4DZhx6lSyZuwh2dA33z5WxECS1PJM/gwzwRto47KKnzLlXVXwSN1WPJSJT0NJ/162umxc7UZ7cXAl1sigkUYxvAg/cZ+yhdZrXyVRvCDgqFvw+B9GMDSi26M3DjFssQW+McypZBexE7FvRixXqh3jj5X3t1uWMFGSJWenRW7qzHq7VCe3QH4Tg/Bskp/2Ypd1hulpKf8hKKT8EYOQOceojjcac5THm4URpAvxmPEfvUB+aIv7FxuX+MHenxO2bPHBjxBxdAVV12Z54sRSG+zru1x2Zhd13mgkj12wOPdbwG5fNp76bwasacVueOjr7M/0rbk4w7XVnlgtyEm73ND1AmfT/eBFoC20FMoOwLn0UR6Gb6k9JB341YZBMk1cksvHiWG4JRZSTMUbYGETgEfBB3FPUvSuxidvA+WYz3knTARbxdxMyumbdCwMvAW9DofvcoZVNC/4NkVqhxfN+XUxJ7DbTIYNJXjuC0ojr7EacjwjXBr4yrhL/xx37KpW+A8mie64UTZA7TinNojzwJVYo0iK/TYnzvzYHZwV7bh3YrbHxB3IHl3S8De6cVW1D6OMB4k+4jUmqq2XC2cv9aanKusA39+Fx9TfZpla6om7oPyNHWFmPsXqGfl57kF7xeE/vZgnNFo3SjrQauOo0XX+XYb73RvoNZ468DpHMVNuCdrWIl3IYVeOAG6umYJDe4Hb5bAK6kTzmq51sVYh40gG24ExTiV5cq5dGUWZF2Bm8h+dWe/C1qzR8XKUG8L/QbdicZ7PPb5KvjlPZX9DJI3LljANjhXZDgXOzIcNwrZUzOsruQW8O9tNA71QjBTWXsR2iyDlK3CT/gRg6LR7iiaoHZuJHXBDl2hTq4m8PvljdwX+2gU9re8wS2H3W0AkqeYF2yV5HM1550F94nJbpIlQikCXrhnF8ndJ/cATj5VQ/azH3KQ/Uv27Ii74HHFYld4WLYk0NZM7IxAzEju6mGwg75qv4YoOWFc8LOf5VOiMbyuVXyC2+nfa4cQW6XFwy9/Dfq1E7pwCimp/D5wE8qf4l1avP49v4pa7UFyjT/h+W5r4bFhLju2Rd70b+A/8kQ2wm5eu9Vez9JDkRZEWh8P1/5mIDkUWuFhzzeE2t8SavMOZSvjaixR7e8Mddnz3aHu94faHAidkey5I0uPRbK0Up7vFJJHoH4PpK3AXHPqUK1HD9PDuBbVzsMeuJ7q1BN+fA6rtEqxb51PgVJvV9YiWWc96IB+QJ1NtYn0maAw7LHrifRv9JGghaAw3UeOXY0RY+FC3qLaHaXu5bP+ao5/NZe/03ctkrtO3t2DsEe7QQ7Qy1ptCzdNVqd7NCxwiJKu/Dgqvxsgz5VTI4FDIBnmgmRNeDSwbtG1xuNp0yqiYRUeg656HvlNMQr2LZ6+kN8EcJ99ks+CSmAne4Gi+Qh/5SZpYQfwWdjTeNwQZKlQ4e9uR2ppL9w/IqGJ8iuCpBW0kxn76CislDy9FoO3QNss3EpJ/xm6G/QMjcSIQnEKyRPrImo5kbcGb5ORFw6b8ymdwO07iBvDGjdRt/MJ8MSvcBM6Rt/DUwrmNB7E3djC9ekTtcs1eo+qYbc7wF53BGmw5dGw4b1g0a3gKOT2QluDoN+XUdNBVfDMTTjl0mHnmyBNpnSUKbWUcgX8qnv5IZ6LurfgXviKaAbf3nOv9Tzx5Ae71QInfjh8nRbwTuIkQTY7KKGmVAh4kbSg8Hz7gYKUDSrEzj0KGczRlmIdwngTSlmUlyVpDT8lGotGuEHY6RTugp+pW8UR6MLHGOd/1S2i9l3d7VfWvX/f1Kv3eOp1Qs99vO69/AbP2uOJ171tEM69V4DyRF+H884Bbb9IQ7gpfE6Cn3kW2jeSugEXYkUDar6SxyldLIEu5aH8aKzJQqxBD7Tto74/lqB2MbSjJwfgFtyRx4M0eArpogPPAuXAO7bSafih79JxpIdAd0I4k4co7enPDXFbv8zTFXXhZKlZ/A007IjyH6KgfV3VTzPsWL1dda0MWnJRAxfVtWzsBaqdLj32l7E72sKWB6izSHoQmQgDEJM2fIui3eqLnce2y3MYJzePchHto31YX+xdzF3u1ZkoXwDfxK58bXmKyVNLngKu2+18fp3PcKza/Vb01Y4KeZHrKzrP4XzY0jmgQo7EiVWoTpVZ9BniveA9NIMk4vhT0ALQBUVWCuE3+CUuR60JvA2n9i70fBb+zVyqRx0oAPecX3HHuQyL8x68s3dBH/MXfBKn/kfAF0UwvMvf6+ptja5Ab2ryQhgOK12quXHVDT23svbQDfANbXlCz02zH3Z0H2rC6TQYvktbSoUU7uFf+AD/UnOTq7sHbtI3r4H2jcN+30TDYTMcLL29nTQee6keLIc/Qn+sxAasrQ88ofrImaxWR349epE6Kil/Bt/TACsSBDsSjDvBSliwqXQZ/sBx17aBt7qJTyFczRPVly3izfL7p/yCCT4J/o1XKirmL/knyLyAC+hZugpyQCZNKew6Xq2+MbmwjgVRnmMDuuHr3A1f5WrfeeVzF3qSXxo10OtY8bd4M7/KW0VL6Mk2F8L2poMP83r+D/9HsIv4MXi6+/kpdY+VX3dveJBqxNy/g9VU341pE3zBNdg/s3HvbIoTaTt4OLWmFNx3HoLODsB+ehM+XlN4S42wHk3QdgZGGoQbWnfEmiJtOj1M36ifieTTY7wP7T/BfXgPdHgq7PojlIx71VC1X6fDO3fQFA7HHfl+9DiCPoFHvAp1f9E/pd+Rk4QV/AGn/hjsthBYrAXY4SHUFSfgEoxefhmU99busCGSGoN3qLOju36oxpLvUPba83hsboFoq/bCO7ih75I/51Qrlqy8eH83BWCUwZj5qzUW3fMldTNybnZySMvsWbu6X2I9lnw8Pw6Z/sCTeRpWb5uqKX+Cu41acR86xOGukbJ8vDRN7dNQr2/qV9KvRh0z9tarId96kJuvwvpUHwj9AvoBr2L0fsAAhYHkDwyiANw8ghU2pEB1CwkCNgL+DtkFA5tQQ2Aohei/YS0bA5spDKMmwObAX7H7QoEtqCkwQqGJwvRf4B9JbEnNgRYK13/GDUpipMIoagFsTRH6Zdx3JLYhM7At8Cfsl5bAWLIA4xS2o1b6j9hhkcAOCjtSFLATtdZ/wBq1BXahGGBX4Pc43WKB3SkO2ENhT2qnfwfbIbEXtQdaqSOwN/AS7FQnYAJ1BtrUz3MSqQswiboCkxWmUDf9Is7W7sC+1APYj3oC+wO/wV6IBw6kXsA04AUaRFbgYIVDqA9wKCXoX+OckTiMbMDhlAjMAH6FvZQEHKFwJKXqX0Kr+gHtCh3UHziaBujnof8Sx9JA4C0Kb6U0/QtYyEHALBoMzKYh+jmcnEN1+VM4ieMpHZhHw/SzuOFKnEjDgfkKJ1Gm/jndRiOAkxVOoZH6Z9ilo4D/UjiN7MAC4KfYrQ7g7TQGOAN4BmfjWOAsugU4W+EddKt+Gns1CziXsoHzKAc4n3L1/9CdNB64gPKAC4Gf4CSeACykicC7FC6mfP0U/F6J99BtwCU0GXgv8CTdR1OA99NU4APAj6mI/gVcqrCYpgGXUYH+EfbZdOByuh24gmYAVwI/hBWbCXxY4SM0S/8AfsFs4CqFq2kOcA3N1U/A65a4lu4ErlO4nhbox+lxWgjcoHAjLdKPwW7eBXxC4ZO0GLiZ7tbfh02U+DTdA3xG4b9pif4ezo97gc/RfcDn6X79XfgZDwC3KtxGRcAXgO/A/i4FOqkYWKKwlB7Uj8LKLQeWKXyRVuhv00sKd9JKYDk9BKwAHoFf9TBwNz2qS2u5Wj8MC7oG+Ao9BtyrsJLW6m/B85H4Kq0D7qf1wAP0OOzoa7QB+DptBL4BPIgTYBPwoMJD9ATwLXpSf5MOKzxCTwHfpqeBR4Fv0Dv0DPBdhe/Rv/XX6X16FnhM4XF6DngCdvg1nN0SP6StwI8UfkzbcKs9SS8ATyn8hLbr++k/VAo8TTuAZ6gM+Cm9qL+KM1/i5/QS8KzCc7RT34f7WznwvMIvqUKvpK9oN/BrhRdoD/Ab4F54di8Dv6VXgJcUfkd79Vdwl6oE/kD7gD/Sq/rL9JPCy7Qf+DMdAP4C3EO/0mvA3+hN4O8Kr9BBfTd8BolVdAhYTW/pu0hXWNum+yqb7vu/0qZH/2PT/7Hp/9j0/webvuYfm/6PTf9vZdP/J/npKf+XNj3tH5v+pzZ9+j82/R8//U9t+q7/Vjad1Lcjyc3dv51/yvVb+fwZGbA6BMtoQqwBrGsHWMAusHY9YNOSYGsysbNvww6dBS2Uv5P5lbbQ1DTysPryZIIV9ZSOh32TpbOw+6dgF9cprX/+J5Srf6R/o993ddOZx88+fcPfD/zFw9507Y8RhJDfo+oUwNQNXrUSgoIb4lBqoj58hrdQSa0ir2V3cAXda9VITknt26//AEobNJiGpg8bnkEjRo6y32xEBX823GV/OhnSttZEX/rzktc9/9+voi3ZPiLTltCnt7VXfM8e3bt26dypY4f27eJiY9q2iW4dFdnK0tJsimgR3jysWdPQJo0bhTQMDgoM8PdrUN+3ntHH28ugCabYVEvfLJMzKstpiLL07x8n3y3ZSMiulZDlNCGp7/VlnKYsVcx0fUkbSk6oU9LmKmmrKcmBJitZ42JNqRaT80iKxVTOo4fZEV+WYnGYnBdVfLCKr1BxP8TNZlQwpYbmp5icnGVKdfadnV+UmpWC5krq+yZbkvN842KpxLc+ovURczaxFJRwkz6sIqJJanyJIKMfBuVsZklJdTa1pMgROLXI1OzxzvRh9tSUMLPZERfr5ORcS46TLEnOgBhVhJJVN07vZKeP6sY0Sc6GlppKYiuLissDKScrpsF4y/jssXanlu2QfQTFoN8UZ5N5Z0OvvaLx4GT7fbVzw7Si1NBJJvlaVHSfyblpmL12rlmiw4E2UFdE9s0q6ouuiyHEtAwTehNLHHYnL0GXJjkTOSvX/PIsqTIl6zaTs54lyZJfdFsWlqZZkZOGzzWXNmtmq4Bz0CzVVJRpt5idCWEWR3ZK85IQKho+d0dTm6np9TlxsSWBQS7BlvgHuCMN/GpH8mryVEwVl7G04TWSZTkiywAohNOUa8JI7BbMqYeEvB5UlNsDxfA4GLWc47Eik5z1krOKAuNluqzv9IoMtJiKLhM0wHLxm+tTst0p3pGBl0lGpZ7UqBryPXFnTIyzbVupIj7JWFOMsY967xoXO7tcTLIUBJoQQHyUDtlmO+LbQ/xms1zgpeU2ysGLs3CY3fVuopywUrK1j3E4RZbMqfTkNBohcwo9OTXVsyzQ5DK13Rs5jVE1/wICGzdMzY93cuM/yc5z5adlWNKGjbabUouy3LJNy7zuzZXfoybPHXM2TLZrYcIdE2GayoVSjq0pLF/sDZyGSPzzVko9vtzHCK1UKWzq6wzM6u9Ch6/Z/DcrlevfyVoquFbNPUxnfMz1772ue79ueA2KNAzYECXSMkcXFflel9cXFqioqK/F1Lcoqyi7XC/MsZgCLUUVWpQWVVSQmuVZ0XJ919IwZ99iByaRz/HQVkFJJRa+f1iJje/PGG2vCISRvz/TXipYJGclOUpaIc9eYYLVValCpspE+WKSL5TGUPRSYVTlwypsRIUq16AS1HtuOZNKM3rSmHLLhSst0NVRlOrIhiM5t9zgyrF5ShuQZnSlFbpKR7tLG5ETKHN2kfyzDpXpeqTVSM6019YHtcmUwUCOky3O+ZY55hJUct5umasiRU4TbAtKOXObO4qKTCAL2s8daXchxO/kMRLVP9VgSTeyNEfbDmnknYU5aKBobNFoixk2JBytuJLM8tW/uUO1gHVY0xybgeASZ+qVWmXpiM62cgTxKtjh36pToQzr+6mwtF7nhMT2WiUVgLeDj4INNA64yJ2iUQQwASxTl6v8TdpucoIrwe+AZcoupOxCyi6k7EJKglZOrO3UXiptFYGuy3Y0bdXpUmIzbQfpYKGt1JbiMh2h3eoOx7nD5QjbIlzhDpdpS0t7RQQk1sM70yWgDhaY2/rSfkM7VahId6uKrPOkrNuBlIjEptp6jGo9RrUeo1qPUV0CMlpdh/R1SF+H9HUqfR2xasrcxt2UO7K+NKCxOwWRRF/NoY2EpxKh2d3hKG1kaaeIvYlZ2gg0vV3hJi0TuFzhOIVDFS5SuYtUfJqKT1PxBBVPcMcltq+FEQoDJGrDtQxqg5Rh2kAVpmupFIlwKN5lOEQboMLBWj8VDkJ6KMI0lAtGOFBTv1upDcB7CsL+eJdhP61vaUpEh8QCvI9DnkB/Mj0FY0jBmFIgJJmyHLwJfFqljAMuAh8Fa6okaymgZFCilogaNrRhQ46NNM0GSgD10fogpzfK9gbaNKuaoxWlrOjJCllZ0bIVy2PF8ljJR7MCTVpX6gC2gdPBWWAvtBOLerEYVyx6iNXiqBXaMotiCkFococRYqn8fVathVha2iLCllhPlFE6OAtcAC4UZaVewQGJISgny7YHDwWPAy8CbwRvBxspwZVjqy8SRII2VAzVDNDuNjus1k4q7NzNFTYPd4UNmnUKSLxdawMxtaGNYA1DboMht8FUPW8RYAHVaU17wUfBp8FS4K0hjNYQRmtMsDXqt1alvFW5S2AdrEGJWqP968t4qdoR4Pa1WpGp0UiJxls06kSjbDRSTwNZ1ZD56eDl4L3uvJZKmVsq5WyJtlpitO2BCSoWAIzQWpaKegHlkC/HByQmQO5DwcgUyyDNZZDbMmlKhNzEAQrbu+PFiBWTp8Zy8Hawt1YBagNqDYoGtQSZQSYQVlRrgdVcAVoOehC0DFQMWorVCdkeszdGjOs6reuirsu7buy6veverj67RTYoS2TZfKlxY/gCwUHGZomBwkBjyY9/V7hN4e0KbQqb2JqN9Ts71u/NsX6PjfV7dKyffazfkLF+fcf6tR/rV845tiYxfidj/FbE+I2M8esW49c1xq9zjF+bGL/EIHbwKPKjVxQmKeyksKXCcB5V6kf19vAYMhuxA7h1mfmuiHPmcgOXRtxtLjciWOx6G+MKesnElyI6mCdGxLpSolxBK/PLBrRAI3gr+XCMLdbnoM84H5tPT592PnE+0T6tfSw+ET4hxmBjoNHf2MDoazQavY0GozCSMaRcP2OLkTfUEO9AGXgbJBpUPFD+xqe6zMozkI2CBpKzoZYm0jKSOM1ZmUtpOSbnzxmWcvaFV+FlSWJncBqlZSaFOrvHpJX76MOdPWLSnPXSx9hLmB904M0p7sepnWkvZ10mLQmTDnwFMccuWRbmDh0OWcdeYuBlyxzUeHZCaEJwn6CefVP+ALLcGHPtCY2p/YKRhDtXpWXYnc+HO5ydZEQPd6RBctLfrxA9RLfUlArRXQYOe4VvoeiROlym+xamOK6VIxPSUyrILANVjkyyHJnqlGshustykTJwlWuhyrW4rlxJb3NqSonZ7CnTW5XpfX2ZideXmajKTHSX0VxlzLXK+Jwhsypj9jlzQ5kWf6NM5B+WqSXNvKSYP3m4ggbyiZLkefKylGVJzQNnOZfOzg+VzoqpgpL5hPseFZWVk5svw+y8cj5hyUtxJltSTCUD592Y75wnswdaUkpoXmqmvWSeLS+ldKBtYKolO8Wxo192223XdfeAp7uSttl/0Fi2bKyt7Kvftj/I3iaz+8m+tsm+tsm++tn6qb6U1kMtjZTkgHeuwh2ivi8UOAt+WlLjwII+Spt7mUMXhu0yyP8Xoz4uKw1w8fUDy6y4xLhEmYVdJrP85Z3YnRW6sJc5bBc/684KRHKQJYlCUyel4N+MGe7I3/w3Qz4zb51xqwrVvxkzZ4HlQsk/85lJmENiA2WVI2CfhbLM0iJLq63NmOGYSWpVZ8wi2d5MCdear4nNQss8o7Ya0Iy6j9SNGHIxmpsxi1FKFpzlVhz5p2IxaIbkIN2tGM4TGR6iMIQttByc4KSfdvNn8n/akPnVVbouPoCBynSz68kEPaowkwe7QhpPx9Tf1KxGWmd+m54jGwUg/RhpTGwnKz1Md9BxGqF/j1QzbaZLFEs9KV+vVr9DXc0LaDO7/leDHvS+/D1iYdViDBdgHNtyB20LL6Y4tJJJq6gJHUWLbXVfvO8Q4cKKWpn0ljbOGKt30H/gSsNBPYeeZKs4YXiBDtNFbmmg6rv1pfo6fT35009aeNV+vaM+FbVGUBbNojsxgkLaQEfYIXqLvfoD6v+uyEPqTnqLY6BQWfDwhqP0PbSGKugVOkof0jlmDuBoLuT3+ZgXVR2oPqAP0HP0aZRKQyidCpEbzpGcKEZro7Vt2gdVn1ef0Vug7UyaTXNoPi1X/6/HB/QRnWRN+IpMMULbRmHUW/2PEyshsw2Q5EE6zUbuwvFs43t5q5ht0KoO4MQ3UCNIsL+S/kpaB5k+TdvpAL1D76LN79Vv0jfF0o/gsbyAl/CD/Ag/zVv5Bb4gvMSHmqbdZXjdcKH6hO6rr9WfQ79h1JxM8H1jsQaDsJ5H6GvMry3HcgK/J2JErMaGBlXV1Z31fvoi/TX9A7JQa5TtDT83lQbTKIx6Lt1Nu+l11D1Cb9MX9AukpLEvB0MWJrbwcM7gWRjFNr7EVaIx1q+HmCJKxTEtRjtiGGV4oaqsulF1afWlal3fojv1/fphtb7y62UyVuAWKsAGkyv2Ivp5jc7SV3QZfXhzBMban9Mw3zVo/zRfhToZxUKxVejwhldoBw1NDWuqh1RPrV5TvUPvog+W/zMNnLCm1AUUD22Sv0M9Q/29w2b1N3c7oD0n6FsO5RbcgQfwSLZzFufzNC7g6Tyf74RUn+My3s0n+CR/i9uzt2gEOcWIXLFYPCzKxAFxQpzVSMvAnWa6Nl97WCvT3tG+NAQaYg0dDIMNWYa5hnle5KV5NzYevtrk6tSqnKq1Vfur21WnVE+uXlq9r/pE9Wd6fX2vfg6uaQeM0UETMcYFmP+99CBthH48jzF+SufpAtb8B8hC43rcDCOOUOuWjHEPxshHwWWaAMrn2yD/Qt7CpbyHK3kfH+S3+D0+xZcEY/TtQL2wC0aICZjDWrFFOMVHoMviNy0Kt4BOWmfcMrIwm/u0+zGf1dop7ZxBGBoZOhoyDIsMb3hpXuO9Vnmt8zrg9abX196B3mPcNuKaBcGjHRb7DH20KbQJtwVN+1q8J6y8QFzhf4tw3ofewnH/ShfJohd8o93Q8qkU4rPO2+xtFiEU6JMl2xCPiThtlCFKa0Az5V/bidHiXpFFz/AeuiL6Q9Nma0fEJjFOW2d4yNCHP8B9Y5+BhB//TImUyH2wdu/TdKxQnLbdIP/enryM2lWvqcJPv89w3kto78EO9mahHeLRfJHTRWNIq5d4kCx4D+SLCAdgB34Eza+A29nDcEYrFgPFSaRNoYd5H+a4m6aI3fwk1qUH9uPtnM7rtY60kKdDGj3pNvEItRQFoiX0eQT9yIu5EXbuFaxNKzGBDJqfyKVjwoFVf4eDRTteCD2dSku5iGK5iivpsFhJ3ThPe+Vq06powVcvconWn0r4iuGg4SCc7yuQZDg01wiH+1Po9Dr08jqZtShoTQ/yErjXYT9lYa8Hict8p5hCk3iN9hU/LRJpKOVpM0RfXlV92ZCodYbEdsGaJHv3NJKX1Svc0AUrfp76qL99Je98w2mvxTKuva/9pDt0c/U4L//qUzQP0ukP67YUe6k/fcyN+VYeZtBFmkHXR9IWsd1wSm/CDdhM7+rYYdUvspVb6SaertfnYdDwW+X/PWVYalhimGW4E2fTFVjNe+khWkuv4jR5CudWa8hxEKQ5FrZnEs4I+ZORrphdH0qCVRqAvHQaCXuaBSs5gf5F02F5H6etVIITKg3yuBX15M9OpmNX3YHWF2L/30fFsAGr6Bl6VzwvNuLOe794TcwWk+hj+lh7Q7PxSDpmeMCwiDJwJx7GDdFzd6xSBOoV6++jtzYUBuvfBbsUeq9f0E/oz1YdRXvPyL/09U6iC97JFE1D+WdDM/aCfYMMDRO95M/wfKhvibdPOTcoE0xeBhnRyNfbC5GXNE00q+cj015iamocOj80ZkjgT9bBVdYhgT9bBwdW4ZJvrbJK7tihc5A56P+Q9iVwTlTZ3vdWVSqVVJJaUqmkslUq6SSdpLvT+0IvKbZGRWl0QDZbFMUFcaBFZBDfAM9R3EZQRB9u4BNccWtoiI0K40PFcQEVN0Zl+RAdx3bQ16Izks67t5KGhnnMN9/vw9StWzeV7qp7zvn//+fU7RjVBO1yChwLkduP6SbwCwhR21E8/SV/kDhoMhl/f9Chcx+xX7IEY7YCHjqv9aIfv0V32oGXlZ/l26C1LfAsSqPM0PwScSZihwE4DnhS/NHOvkOH+EOHQCbTx/dBQWxCr6pKBIskTUfCsTgZq6utr6mWXRJptHQEjaIhYkuMcAuim4gS6UikYmY81dqWxA11d25qyOsNEY952HBFRcR6jGlNlbW0JstbcH5kJR4n/0C9b/wN+UUvOExZ4mbdCq0W/E1l1o8tvcQ6wBKv6LaQsE3YJewT/iqYhF4oA4J4ZSODYj9LrOupZOagvOwlYjVi8+/h+MJ99PfxOXQ3/X1o7lr4FjSf6Da04l2c6KDf1U6HFCVEw8uNrscbMlHvD3hjqhqDhwt7lGG9kz+IJM/3KAn1o+vrZljqE1ZxXP0iDALDWueg39NXVRk9eVImljSOP7cBN993NA4bhzd0X4fzk8hvTFcDHlytD7NYZKhYyEbQZGmHZ1qmWa6yXAd/Y7mVudVyL1xtWQ+ftGwGm+Eb8E3LR/Aw/LPlKPzZ4mYtkM3CnT0k2wamWbKwG13UNOblNAnJj4Us3PrCS2gS+jtz6P4PgXQftmBnJ2JT47oaYH3RhPtzFwg+QbESj7KSQ1BMJX+fHFU4m8v0hNuhcCzy4C/RfX9twmyahs9sFAlrpDf/AyDz/d3lTGK4BfVL8/0gnv8JyGhz5X/a7HdYHIyD6M3/DPj8D90BRzn+RDL/gx5JmPwO1REWr2aCfhFUwLjJHo44tFaxrNUkmkx2byuy59ubq0paHUrlI72QBh6U2hamlz+KZjjDI68Um7BTCrhBrjlyoT6VqOBjHsWtyIpLkRQT7fcFfEGf6qPoeKw0loglYxTN2qw2i42xmW0mmoyFhRIdhJxeHaboqA7KqbQOI5ymQ5+CmpitTAcVBGoMoW1I6yT6l1oKGov/YOPQfygr0F1C0KlkpKDgzgi4kYNBMRPO5n/RddSJS34BNT4eNQqHGrcjE8FNXJLtqIcaUkLnkUGRzZRbUSPjXkBSNPxDvtXdqMNJbhV/Ss0QVl5oc+MG/i85Jb7sKdDFmw0fj6FXXR3fgG3ultHLXItG4rFImHC5JHTslmuqxTry66Uz7z/rxorAaM6NemP/vSI4ipcnjEwqpU1jfr92ZMpT2nTGHWuJP+0e+P7hG5rrtLtbz5+3G/K4H7675fzFC95pjSiRgf3bX1zwbmtYKYHadlwEeRrB38fIg1Kw4QVicmqyzifsQpQKW30+qTVsYk2IZacBK0jn3q7J9NWkEYg0VVb5XkQO9YVe5iupPYO73nFz/ObSmxOPlT6W2GrblLTYRatcZ2tMUolIMpiS4sHSiE1i8TQp34h98t/FnEyVMqVJ0TNiYspoGaKXeBKY4GdboMlEwFcY08vwELAAFtpRdE/bZLFYbd4s/NsmfE1gK7oi5P1onDkgtEaH24k5iIPcaDSIzmeJqxFT3zXonvzRfuydqMEY0Jdp4XOHEHbyuVaxKe0B/I/9O5CRqioBclW/WiJ65Ggo5tI8OnBGBB26VUmHYglqiq62dCnoLPoV6IJdqSkNWhFzXVpdSUMbUVeLbEebaXMhnIvBTNNmYM4RN3mcoufYHgh+6JqgPrvo108ptMXGC+4rX7z4oYOxadcNfNI7QQt6vcH5Nxz+bs4VHaWzH/ttp8dsdfOV6y7ce9uwi+ddO/DZIyjyP8J2Q1oggPK693Q74rAQEdRMAdUvK1l4eHMg8IrMucQsvEgXHY5XXCFNu5wgJYIgCU0NZeG0LSRJmbSgPYj63ShByxIIDQJ+PLcy4NCY7CKzxI06B02OywMBFXBBiOY32Ev8Gmhwms4iw0AlTFEuG8KC99Fkl9yUQhgAER50nYPAvasFIXuuhT8E+JY+3Pmuhe9DWI/hPtciNJmWVaT+jd+BTICs8eOelsE9V1XZBbU6WCMMovVgRzPms6ZGECKQJHMfwA+ea1e9XrXdaAd24vahsoFJcPrFZPzY22401QM/4tYjOt1wOrEvpyGvEfMHKS/y+AiohE/ptoqwVFIbDqaCWjDWmz+KU3HdUUc1MyOpscxEaipDR7P5LzYiTw8V92FjH6ktyeb36FY0kECfLmHsWfTJxRRFMRIlMTEqxiSdw5xjndOcs5wLnbc4byrZ6uwp2cvuFf9id7LQxJhDdEzhSkJRbWboEm2htrB0Xnpu5cbw1uRHtoPWwzZxKoNAjxfEkFNSXUE54FZ4jz0MSuy2KBuzwso0UVGGAilhTiVNbtphL6lCVlzfU95KkhZfFn6hy2qrZIq3WuyeA3QrSPLJULIySSVfJt5Beq0ElgAb8diWcGulAzqUqq2wES49Dumd5+CQyXXmkNjoQ3GDgqXvUEFxuI3NwHZ/tCykUU6eEziRI2mbnbUTdBmV1GHIGc7CDboLxKwIy6MlpQwaTJnKdahxKn6HhVF7XAcJM2qKQM63GEi+dOlSxIc4wAy0LERbapAVC6CJaLKNqKl2FwYwWgKXhOCzprreiD8zDWePWz/z5t2vPH71y/UjM5VrP7xhQqNHFuxiovW/BrYpsUfnzF2zdubFU1sI57xf71t3799uvv2Z9x++5co1M8OcIrqt0sALX2nvbX7wuTtu3PCrBhRfXyGu/crg2iiogsv0UeLj4T+C78B3NspLBVyp8kmpmYSJdVAen0Py3Oa5B97P3M+ujK9JPVj+JHw03kNss/baelPvWP+Yci6E6zWiSipHoNjtjwSz+c+7KyMVvfnPEUn/vElgSktL8FiyNNyb/xZE8990x8MaRlAxVaozkdZEgg60Ok3pVtoeycJPEWonZD7WSh7wtmbkDpmQs7BPZ2tCrfyBslaLUn0KXSPT9mP1heyZPmwYGNvXMGlleZVPFVwUExRDOvBLiIQrzIhrK00xHapCAJGwCzXlTFoHVYiYT5Awstv/wsCgE3Z2ga6RuJCcyn+9EbEoupGvNyJyxXu9EnGryYOOTB7Ug7gHPcaYZMu4POh0Fx5z4TEXHjuJUqdAuegTCBkaDMcouImZbjBwGFEo8gnnkD7pvPKq/WvX7r9q1gXJYR/ee9+eYQn7I/OvfWTNdQvWuDcsWbLhmcWLnyFur3n8olV7966a/nhtXdO5M27bteu2GeOH/Xn2Aw/OmrFy5YB5zrp1v77miScQnhjak5yBtKcPVOkWrltmmW5Ai1uRDlYABeUellUU/wkxinKGAhlhSQpPkqTO0wnUEw05Y3xD8zi85ZYfV60EbMwnSWBchQdM1oXtjt2OT/j9jj/zRxx/481uZxY+tbGSg1wWenULuj7uv/k/yCjrkHU7W+t4n5OhvFcBdPEqQQYiB+nHCIDguw91cZrRefLFkhqki5KVmBBt7BjfgJpzL4DMwJcuRfCE6CGX+vZAZVgMumz4i1FRLgGobdTdIIlE5mY9VS80iU2+trKG8jHimd6zy9rLx4vj5ene6WXjy39OcimQTJZVQIIot/Ion9Bl+3L7Gjuxzw7tCcFu54WAVRAjCfyWIxarScZiiWQgkiyzkMYQTdcQNE0SAQtRrjiNIVk+X5RlpxhQRCHsx0NnqEBdoq5Qyd0qVBM+VUUaNezzesuSyaDPK/l8XlEQgkQ54s/ykkjEamEADKa4CrWCqKiwKOVlMa8z5lUIby+cjMRHmy4lYz6ds2SAADkkdff7jvgoBMllmyuJmFAeE3thGxDy2zcK1oyQzW/XeXQuJ0AgdKAcKi9QKEso25gePduTLWiYzi7k9ljDFLo5I3HCrIojuNNIPxGvLjMZlLqswpNa9m+IWZmiyoH8951d6f4dQwf+nw6NT5sRd+PN8ASNPIWUYcEpajR4yhskGSHJRblPuh7BumbgddwOh/N+xnv4OLx/uDH8BibvtSu/Vg/AZQPvDJI2+Y3b6XT/8upxEl9GXJJ7CGfsk5APTUE+5AdxUA0v019+Lvl06nXra+zHVtPy5G2ph0IPRNekno3Si0oWR+el5pcvty6Xbi9ZHmUm8jP5xda5/FxhrjjXaT4rdI52ZsnY1M0OUzXXHBqmDYtmks2p0dwYnrGklZBf80V9SV86wiVTzEL+pZI30mR76MzodaGbQ7dVrgqtD/WEmDIGya4UAAGZYEwpCANMZchBRkod1aF4IBGT4zEmGAhWVVfLDCEzkShnU21pW8bWYZtum4OSniy8UU+UR4HACwQnrBC2C7uF/cIRgRa8tfFSJLxQNkocQXJdqTlrYcEnMEd3FasQnYbgwhkYshdyBowvyDHEJoiZ+lSBZcB8sKRMlKysM5aKJqXychi1RsphmZgoByVsrByCE5gOujphVxdKUDs7o8KgkQ2INaD3uKGdWnVDvcG+mqBVGz3UhaAL25fgH3pt/Y3Xj19/ce4OfPwaTEzvaB11z4KBjfDJc3/TNuXh2wfen1Awd8/1909PP3jhhNtnYJMT9RH/rIaOm47JZ8xq0n/ThibBg2y/Hdm+kWjUMwcDh4NEOzircTvYDT6An/jfCxwFR+HRgDUK4oF4MNY4xj/J/0TwxeAesAfuCXwDvw7YJwchtAniiIkgm9/fgzs2EeOAcw2CSE7lCC7h5DjRGbCpUTzOg/D4MBFOxMLhaCygpuvwIFtdU19dXVcfSLMm45ipoRjGRAVYn6vwwzyQ86gewpOQPB6XFPBVlBr4A1LjU0QqEU+lSuOBimz+dt0fgCDkDwSCkJAgboONACCPkdAQ0nQBnQ1GY6oaDPoDMYiPz/L7fY0NBOmK+YiKdLw+lk6zrI1yxmxMLN7YGAgGAw31QSStdkE1Pj0+J/5cfFvcFNfjidq4LtZx8eXx3fH98SNoLEsc0F0BFU6HxHK4C3+5AOX3UwRBBbLEQl12hkhKooIdzl3Ofc6/Oimn0vTqHE9RIiLM8Sp8n0doShdenV3osDOV6vLwh72GzMejfAvI5LDuNxKCFtRvKaQBfcYY8laMXAiyljEIukwIwlIoLRhEnx87ERgNOeo66fD0B//4MZznwWu6OlHiFoH/mFZEBqEMnjbziBAPXzTwMv+AgVl/xO2YOty+C9tg07sYw2oLychbiDfUB0ScdRyTT4azXBmxB++HjuMFKcirW5BXR8CdepKz2Op4PmAJ+9X6SCTgR7BSh2HFqcj1IiKuiIh+PmFhGJTszdnM80IQJfOoq4d4f9p/kX+Xn+L8GX+Hf7p/rn+5/zn/Pj/j/3MUWw7DRX8xM8sYZUuI1AgGhiI+nHyEZuwfZkETCpLrRIdYsRdPQ+4n3O4deALfGfkMvkuqbeh9DnyOZwcuGLjV2EdQEvkSmSNFUxVCOE23ATNvvsg817zEbDK/BH8AHBJQPwFbug+k+zrRpbgHFX9R6RH2b2VSETn3twpqTYG3FRMrKtLbiN0VpDRW5PdR55NLQCmohzP0c58yr1OfqiBj5qjaTF3rXOC9zrdEusl7t7TK+7R5rbTO+2y6x/yS4wVpk/fF4FuO/iqXFSowCcn7hXu8xKKK2yoeqHjK8XTFa1UfVn1ZxZSGs8Szujea1qLRsBYuFQNOd6JeA/UJSNbYLGX1WbhfnwpvKQXWGo1kLRoo48vmlpFliWabrVR6kNcCZvyGHYRCmm6XM5wG01pG69Cma2u057Rt2j6N0byN7uWVGo3fn0OvobfR+2iKVhqSW0/wAEydkzs8riANMCWcSNnSnaiXaTGUPqICnMA14ercSTFTVQnGPq/8auzzJedOnbwNmPM/g9r8EVCHNiXfv1FkKpiClp8CkJQf+zyLTpXQqVtBEJ3izG/H7yCW6NTqikoc17KKeVhBINYb9S3XoCeRMeO9giBvICdv2X3fU/s/HnZLx5IlM14IWXi31XHJg+PXdM/FXvJa8+/O3HL5uAXXXL31koX3r55z/WaOv2X0ZU1WjyhYOW/yoUtye7CHwf8U+I7m886+YtJ0rDLLke0nUV8hhVAKS16wO7GtWD4t8bxTCtv9Mj52KmmXosiusD9oJiEbitk62Sy8pCemWUIaiqdL9CTpR3LDbGEDGodmnqC9ycgEYAu5JCzvOGmOtE8iJSVx4Z1DzYGNcAgbBBeeM5kWhT/kQSinHPIcEgoF0tMCmGEMW9EY+oRZFljJVpaMKT2/9NLSJ8PrS7bAF9mXgpvjO0xvMXuoz5hDpm8YQaaqYLWplR0JO9gzg+fDiaZOcyd7KbzMNJudTyyyLgouVG8N9qovh3uiMszmj3SzfGk2/80LQblQyEIUPwUKyEYojQYovFyRU0ARDsmgYPI/Ps5CeuCnns9WvoYDvsvgePLhvXffvRdv1Fe5D14f+PHVHQNHXl+PA59qM+peO9d8/vkatOG6I7LOWBSZSXCkR7OyXMaVzR/Vy1DnDddn0U/j+9X92l+i38TNJa64PCp0TvSc+MRQZ3RqfBY3S7kyeqtik7P5H/R5TmmK83zXVdHL4ke9JhqRkcub4BNi1Hsb/wB/r2eVd71rPTo3EhMFTpF8EJCMQ/G7OTsgBRbcImgJM7uRov3/6dYirKOZmbJWhSvU7SqhesskLYaNvDYGuZgaWxEjY0pqxxA7o2g7p68gv/oLxUX036FCgaQgvbCtC89oAK5oQDTPSFgN1gvpYgH4+MQ2DOaukTCoqwU11eRraPY80O0U3AT93D1bX/3oqRlvnefiBffMR3e+NfALZN/6A2n34yh5RfW6fWOWfHPfo3vOGC+5hdSIqyD5xlvQhmPht2i2n8arTtB8H9h8ZvKKJMEQOAAcwARNaaPoGmaCHjzE+9Jun8/jDgetcrjU0mlFYbCxVEPzjcIhFNakILCxkhkvoXOrltASvB4DQm9ZVFvCQz4L79iYSi4ZzFu6ivOTw3yPQwHT/SH06sdxcHrirqoc+7xcDIKNDkZkMMSciIsXQTL/bXdIiuPnGLH8VxsjTIlyHKOOE1bEwKNiEdY96MpDiwEUUYCYuw9c897Che/N++xe43juJ6vu/eSTe1d9Qn31y9UYWx7fuXD/gt/su34n3Fvw5LWffbYWezIBlqC5TSNPVkAI7NavtMqrXUQ1MYI4j7iEeJ143flHZa+4V/nM9388X6p/l+2KP+mvJRqDZ/nOVi/wTVXn+Garv/Xd4VvtXx3cYuLmy73+HeQO8U3/m0GaeU3whkKII4WA5jZTmsDaJnib1wI4F0VQFn6pu8OhZti8VoJzpG3SLgRFlKRoyQ1DXPScPiNl7Ds0WOUx0oOTQKZblmgECZt8khoksvlvj0M9RC9NPskxj3smMBt+a6bKjz0hf/nkhe8Odzp4D1/549JPBvZBbue70DpJ+XDlyj1e+NCjb7TVcIog8NWToO/NLQg5/nvp7c9u+D1+/vAxUj1TkWfWgrf0qG4bb1piutG2tGqtrdu2KfVqak/K6maQGNrJ82FLbQWoglVZgtoMQLgCSaIs1HUvRJ5bUhoG0c6EFgBADCkV5R7awljDyBd1az3Kx0PeXYZrrtLtaZfumuva7aJcSt38F+HboChl+3ES3cIfNiRRC06oc0a585TsqfOUNMqRTPmQQctUkPIlVIgXhC1ditJjQTuNtjRi3y2fqFvSLlfxXCINDRzNzcHtW5txu3nDnQuW1bg8EuO874pfL4C3GkBrz40ZlFTEi9gfF896UGZkUXST7tmjF+MRPLcT0dxejea2EV6jl6/2/hIiKOiCl9Lz6RXwHmItXEc8DzcS1vX0Y+ZNph7z6+ZPzPu8Zi8juA0c4CRVIqQLPJLk9oSFRNog0LILKsvK0pXhBG8t4Icd2i+w2O1WS5gv6CE2ekFRDzVW4+NIXbqqrq66KtwIQwm/RiVKS5ErNALKzFsZS0jZ54EIdx7V2WFAC1Vtq9xVSVRm4V82No25+Hj1AzutYaEihBhZg3BaAPknacCpb71A4799eRH/sQSu7SNu3N+Nkm6U/04xDMx7fSYzHfWZFBV6zf6CifFDoLHPi8fBiM7394RsqlRg0ymwExOqYBSsT2ie465Q0EXm06Uf8LzxK6fNuPWCC1VFUQf+iuHowhvnXzA8PXu6kXV8h9vphqcgnv1l0pjRyztyPx33B3La9eWhBblvBwcK1Itw6mXkDbJJACRSRIv1ZFipVnTlPOUS5Vrld4rZaecnS0gX0TbLZJMpbJP9yioX0kXka0QW3rPZT9ttVvwNidON/+PRft1BUaaQq0OCkhI4d3EhiLDqQXmFsSAic7TvlLLDibhB8eGK1DlPiRFtcAKIFTcshmfh+855jCLRWT/iZMokfPrpwLnHfhji+YgbMbttGvgt2WjcWQCs0VM8QMFO8OQ0boofqQX/tdwSsAQuIZaQqzjHOGY5s4Z52t/rN/kZX2++H/jz/d0mlsnCZzZTVJgt3LDuYGnvBCUkOh3yyiBOrabrAkGQZFC12UOBQAcFKSXYC3vge2Dw5ovVuOOpVe5Q5mju+E0DXBNHgIrv/PgdS/gpYfHIVF1fR+y7YemAPehVVGLM5MmtEwZ+NCbActXv8N3njhncc8lVK8pVlFp54B2XoyjfiuwqoSj3gE69doZrnutGF4kQczJGTISRkzE+ih7XKkEIewCCRQBDAs938Nt4kleUobbDZvsnNjutve462Vo/YGsNEucQF0TX6sKVX8SV7URSb+EauEZHEzeMa+FaOZ0byY22iDFbvW2Tr7uMisN6SEz0zzDP8F9rvtZvqjdX+0ebR/snmk2VTEOrgT37hsFh7W3DhrW2hRtcHB4KhkQ4Xtwt7hePiBQQeVEXSbHdIYqcI+yKqgasgTAfJsLtwXBYDYaj9ZWFwRq+hqhpT9fUVKbD9e06Hpy5byQc2Z4ZOVLPhMvTdDBWUV4a8NPQnGzQm0E7ndRIr2axkOaG+vpo1GW1O0JuWVfrKuUlMiEfiwWCoXgMH8eWxIjYsTaQDmXacBoH2ra17Woj25QxyWc8QzIG1Em1HN8ha2Ccyxj1kUxLn1DM38QmcLoSxz87OqVsMgT6aAR9sgF9p0JgEQNDpQmPYrVRJjaaoOIqNNGK1a3CUlNShR6bVy1UC/HTO+MRUGcnAkdfERyH46+6+Q5QaDPn96LftRdB7QdFidEFC8+FzPgKvG10trDHV9KN9oWFEp1Ol5FPGhruBJxGhMJz9pOPh+DqqRnM11fNHj5Da5w3bFr9mDHYUx8YV1Nx2fB2o9tRVV7WOtIYPmhUdYwuOWPivNHt7aObz56a68HeTNynTxg9M/eB0b9r5KRA4tLCwQkqRl4+G3n5JOTljXCZ3vAh/SFD7KB3MMSjTDfdzZBd5iVm4hLzpcylPvIB33qaWKRuhJsI0q/OUgkAKYIIongtMLBLdRGudsXl8ihh8VQGFtgCAzugo93qcLDWsFBgYB5E+ShxCg3b69oLNFzd3EjDXrgfhJCedwY0yowYWUSptMUa8u5ToILJmDfIeEXlWkTGCmbiEwBf5OGCc+b6kar8l8pv/18sLPn8JsbM0AxB+03I4XxMoMDESYOJB52tW5XQR794wScV3KvLKF13diK+qS/Krn/wjpO96B/IeNLkO6dc1NE4zfCHA8Zqg3+/+lfXdw3l4qKvLJ4yKhG8/czcX09w8ZRFI2/KfX+KgyDGugvlDC3IQ1jghmfojaJMyZJbJt+Eb7IfEn8yfW7+kKWvMl8pEDOJmdSVzJXWWfbZwkznZW7GpZGcZiFZi9mmARwvnJIx9g63sdftrrrn8dcMV4KLECFmiWW6R9RoHZ1G6+icOfQ2ehe9nz5Cm+gsPLjRgyBoUGUhYdOX6+zCAmdwNZeRKLDF6d0KZMSXUr5/Ey85JHdv/iBw5g9utAeF4ODTXpx94foqXnLFyhLvy0i4EXBy7+SCGVZCDWNFjRk3An6kHRDZjFliRfQmamRJcLdJuHFKnITP2KGLqGO12nj0SdQQJKe2wBQ4ZVnVFIgrF4PZydAcr2Wg79UdA99Bccer0DnxwNq1B/AGn9s+cAQK27ZDYeDIHx7+Yt9DD+7fh+tGA781ohc/5S/XM1VWrimOtrryc+FEotN+KUQ2oa+yXwsXJa+pYP+L3m791PypZW/806rD9JdWRiHLyEXmO8jV5AaSlv1GyCrpgKL4A2G5wFKsuPMkShoeThfZCNoTaa7Z5W9GnupIa6w1ocGVlBmozVE6pnEMZLw1ZcARCnKBjsD0wJwAFVCqh5aecIS2DBae+loyh4zyX/F50L8kl0+pQHWX2iqxSipHVk8h6QOx1avyn78Qjxy3uWFxXNhwFSWvUUI6bUidVEkau2H+De/PG8i9fOCOt42QmjOkoPTQB/+xes+e1fftIWesnnbBtbuu6RnIbxmgcTwZpeVmHE8DV961a/eKu3bvKqxmo6aSCxAyuHTpBgcss3RYZ4kLxVvFe+mHnGZ/IUFRd0ZUNRwJ+32uXuJZ4EFZpMV4QhP2paL4jI7ScSWlpdGScIp1SMaXoZjMdugEkoO3lkSbQYq2ZngEnK5mX7jZ7/dZOfMRM2H2lgMpVMJFxkeWRFZE1kaOROiIUpa78wR4juMPdyLoNBYAGIvRDMlYKAlidm9q+peebPxfABOZTyiar8cpOWTRP8i2RQsNrqIpQN9pUlWCWPfo6LFLFafV4YzUKg0PbIPXGjLvaqxP33oAt+SMPfdMnOl1ovwh4p389ECtYRpRcBMvFblwV34fOYCiaRT8Xr9FyviHE+LZYAq4ctSG0IaGRxrfdr454gvnR/JHbX8a8RfnodqvRxxz9tf+PEJknbRsarOMUJ0u2dXmG3F7eFXtVo6d5JzaeGXjrObrG3/bfGvjrc3rpW7Jemdzj0qcy6QSkViV3tpS6/VwDrPL1gRqqysjVEU957CRVkAKSnNrqyZoI61ZWLeJDFXAiiy8V/fH6jUNNJsnNmkdwenBOUEy6G2vmhBpTrg0HSOqjLBTnzInARPK6JFmko5ZNfbCYoUL56PGkrfOc/phCi+XMIIvl+sD2MadqMkJTeli+f24hDMqhE1iYRFVY8MIMeSPOqPuNpcKmn1NKmwIoUYcgQ7ljEcFbk9b67BAC+I9b3NLo1qvAmm4YMguTMKFprgsxuDDQetvapZqrf6X8l8Bd/5bMCr/bXeb1IAgd2NYbvE3nohfvECn01BijQiPLUiiNkuoacTo7OFd6Ag1ozAcj5IQAI+SWC7jxz8HzQw+aQsmIQk3Q+AYMUGxzln0tnix5u82FrUWKyBSYQnJ4LKdwSVc8VhJrPAggbwBp3keowLaeN6y349rbq+8+blRF09/9403FjMuO4YCUXFHVs9Zt/bc8wbeuOXsPSufJVMB5Kkrgl5ZaYk3NqXqWkr9nNMTueGMqx6fGZYc3uAzyH1dFWpl5vpR49LpUO0VLbMX4wzlbsTMzdTdoAy8qZf84oN2n9dHrLP2WF+1fmA9ZDVd57jZscrxmON19iOWdjPQjBGEgtfoLoaizEwY8pLFJXC8IEomxZbIwkd1IdhcUmJuhhDQNk1hpVuoLHxSl8rKGEsopr0O/Lw/5J/r34Yy0izx5cZynBQgJzpkFKT6jcKdsXIy11coKWMPOgWwcSXK67OyrNeiAqvPpoJCJcoo7HfCwQgXpFOLebG6kytTsgtJw50GEDfO75r4eoNk5z320E9dK581nnk+gI1BzsDBnXvvzBk1IbsicHbtnNvmE2k8aKzqwPM4Dc3jFHIGiCMktlmpHpkolaGX4SwGAtvSjM1mYcJcoeTM+sYVS85xDR+X48WJ7aGSEi0UjkOZk0JaM4hb3Z5mNRjkGEszz9GSRrKhEABuGetVS4IXQswuMzTj0lHpqaWjlpbCgquWwlPowl9rnMyI/0SgDsKtboU6BtvQSQUi0UnRpqiTElQg0lJh5gth6CyG4cvAhcJPRsQp5g8Wa6vGo7L4kOk3bNNw4nDwSdnNG3Yu0n9l8OFrV4x752nDDH81JOeiB0dOnk8EDWP8/rxZLxW6hQoJyOcLlWlTFREDZ/wPe98D3tR15XnffU+ybEnGOAaMMebVccEQxRhjbGHJKja2sYmxXdk4wNAU2ZKxQMiuLP6WpQzl42NYmqEMJZR62ZRl8qV8GYayLqUszWSYLMtSQhmaUkoZNqVs/tAMpZTSTELI/u59V9J7wjCNk/m3n3Pz3jn33HPPOffcc/9KWPwvun1NIkT9Pv2bSR9NopPGHPvIP1D/BJUKjtPtZDK8xQz/wgwiSf9D/lAeaZpGRvJPZOUMeYncK2+UTTL7RNZGRkh/IOb4J7KxrzmXi7Ay0/f+cXTGyLGpGe+OYUD5h7NZYzPTMkZwMJLZxb//ZXbDrgLYlUJmf/R9ycos63U976KunGP3/xe3rOw4/c9Gyz5Lv0Z/pLxFUknFrDEOsh7btRTlqJT6t5QckX43gk6glB6Twv89TSIHfiCNF99k+/AL/Nvf7N8m8H8s85n4v7Q4jr3fz8ZNHPu4rLz14aWSx3HKJRlkOVmkLFGaSAoZQcaQCWQSmUrKyefIHP5LFV8kS0kPWU2+Qk7P6uwOtbS1LV6wZr3T3RstdCzxFzTW2yw1sxT+UxS5aoHbUVDgcMsLckuLszIysnOb5q6KRDq66qo3rCsrCS/LHO1tp+YKTztS/jOL8nIWrVu2aNGydXJXflr6lKKiifldZOrV12ZOfe38a2z0T506NeP8axmvYacA7DWG6h/OJ03VYMY5jT+J+QF++CTr8Xz2x+EmCfiYgGMEjJWnJOWTYXJ5cv6zSfJj+uSfF5eWFu9irz9MnzZ9WgHD7peX4L+/mj5t2nTqZe8PcxiBfjXO++Gh4tKSEs4snWZl9xez9x8Y8y6GybvxKkbu/s+mT5/2f5CRngPSzoR9GS/phyVTZ3xYD+wbxcWlVBVM91OAvM2q/by0uLQIiPbPJ8tF+jr/bbFBkmSVfHQT3SQ/g/SB/IFpjGmMGZtAc5f5RCKlXLVcGSylzTGkv3tI+q31N7aX7SvTH08/OaJ3RG/G6ozrIzuRfvCYI6tylHXUO6PeGX0kOy370Njej5m2Dzmd+ETp5w+mHNtwGk7DaTgNp+E0nIbTcBpOw2k4DafhNJyG03AaTsPp003jxgyn4TSchtNwGk7DaTj96ydCSAV9mWi/rEdojvaHa/kf7B/NcwynJJ1uJbFf4JtFdwtc0fGYSDa9KHAzyaU3BZ5CwnEeCymWswWeSnJNhQK3p5tNNbFfW5Psj80VuESsWU8LnJKUrGcFLhM16xsCV3Q8JmLL+p7AzSQ9628FnkLK4zwWkv3Y5wWeCp4fC9yeImf9A/tFQUWGLtu4NzjO/m5pxrhbHDczOvvnycBTGD3XxnELx3M5ngpD89i33ziu+VDDNR9quOZDDVd0PJoPNVzzoYZrPtRwzYcarvlQw+3p2bkOjqfp7Gd/tTJjSg3HbTp6OsOntHE8g9k2xc/xx4BnTolwPEvHP4r7QcNH6+hjed3NHB/HdWkyx+t4JujwAs6/k+NTOP48x5/k+CGGW3T2W3S6bDq6LdaW7xCVlJBiMo2UA2sj3SQAOI/0kDCeKFlLejllNnIR4OztAz3IOYpQUkVCSCrxgrYU9aOkj+cCgAFwr8LbzzntSPXIdYAaIKtBaebSw9Ab09MI6WsheyXkqJDbA5lB0gm8E3gvyiJxPWrc+mIyHdjEeK6c/wqiF7JCqNMNvB54mMvoJMsF71zkukFlpSthY1+8TcwPQd6O0EPt6eK+UEk18h0oYVQf94SxjZqcHtFSlWtZidJO3l6W64Ls1agb4ZSV4PJzz6mgx/qjATYx7wR5vTD3rYvXD3COAFkBnczTfv5WhUUxXpXT+0Bh/uuN92CiHaw8CiuCqNkHL8wWdgaFLU2G9vi4dSwW/Fw3s345b2fXkOKIxctS6AtxScn1Kh5qTSF4g7xVPXFfTibtnKsv3sYyaJiJ2DBK0WS0kFb+a5f/uiMhjT/Do+E/ymio59+hY1YxaU/x0ijKAjxakyOQWbIScnu5Xs2CLq4hyj26kLda5eNmLW+lZlU07ukYN6P18P5m/mDxFuC96ed8vaJHHHxEhrmeXt4mrW6nkBIQeR+X3cutXgGuKC9jtTq4HTEPJ3srKmpofRd5gNIVb4Mjnk/01oPe6eV5P+p0Iu8QPcdGiKbXEdeT3IIg76XV3E+dPJYH89lq0dIgj/IQj+fY2Ev2PasT4lgh+Ccbomdw6ZoNQ/WtPjaZpKWgRXg0RnnPdcajcbAWxLQ/aJdLFwOsJVpbolxfbLaK8Hhey+OHxXOYj2HfQ1uqxZ7PEFXaWOwRb61VGs5mhV4xNzBrY70Zk8M42Qz0qBjV5tGw6JmE9NgICQovR/hsFeR/zz8q+pbtL2LzNmtDiLduddzLxqh28J7xcdwv4uDBOSZ5JBTyuZa1s4JMRQrwOZLpWM5nkgDvVR9ozENLwRErmypkfjFp3posRm9ituiLeyxmzcdZGf7ImVjNTZLRGJOhjo9H8zLQtH6KRU2Ar2IhMYMnovtRq0ssKh++wrCea4mPnD7dyq31txYFAaFrKY/lsOh3B29zRMz82tzDZgYf97/Wz7E41uKqV+wONA09kKrN9OF4pPhIYoVNns/+Bfoi7iEfbzvzW1DM9X4xVjshfYUYI4ldB9MQ5KtQH49NYePD+xZ4q3GNRW9P1vnIz1eZkGGeebCNj5DHZ98grxfjHnx2cyTNbjHfJ9dmXtPmU327Y3Yl9j+JUZNYiWJ96ODzfQ/X0hXPB3QRwuYtrYf6IC2xwmpWd3BbAmKlWhnvS/1covXhVNHjfXyUhOI2xMa1MZb+eK/qV3itlfqVxhjTCU+s5n5cMcR+jK0GbH8WFp4J6Czw8zfTmfDLMnB06taO6CPmY23m9/MWxFa8CsMs7oPEHj7jDL7j1XbmsVUm4Z/YSpbwkX5OMdbq43OF1lcdot2Dr7m+h/RoJN76Ph6lYS5dG0Xayqtf0YcaAbH1rZ7U8tJmUofc01gtvZzSAJqKWdSLknbk2K9t1YAyCRytonwS76mn+TpUD775fI3TZHjxbkJ+IZ/j6ojK8yz3FPibIIvVrSULuI5aSGvlnF4uex6ojYC1go/VmA3KfP77Ok1kDp8FNX1NqKXt3xvEmqhZ2ga6Gm+h0aoGrjFm2TzkvJBfL0qrILuBy2P2M/11HG+K21knLK3iPmKSmUz2W2GNPMeo8wFbwNfK9VfxNmvWNvE21KFca0stt4BpLhJt1fiYf9pFCesjZl8jUqJVVdwH9dyahP9mA7bAciZ/Dv+1NpXzNPJe1DireX3WRtbaRp5LtErrqdm8NcyrzAc1wOfhmRP3nZe/NVu8OmlG3z3NyxNcWvuqxHs291wzz2m9MZvn2nhfsVKH6Esvb0ey1qd5JNZyrire4tZ4hNTx6NWsj0WnpqNZZ4mmj/Wt3pZYVKuPGCOalFj5fNHTD/qFeb2K+4TZ1RrX/DDJGJvfUUuKp5Wrbd0BdV5PuCe6tjegzu6J9PZEfNFgT7hIrQqFVG9waXe0T/UG+gKRVQF/kWq31wc6IoHVanNvINzG6jT61vasjKqhnqXBTrWzp3dthNVRmfji6epEBsodqtcX6u1W633hzp7O5aDO7ekOq/Ur/X1MU1t3sE8N6eV09UTU6mBHKNjpC6lCI3h6oFTt61kZ6QwAdEVX+yIBdWXYH4ioUdaOhja1MdgZCPcFXGpfIKAGVnQE/P6AXw1pVNUf6OuMBHtZA7kOfyDqC4b6imZDZhBSmjQ9PjUa8fkDK3yR5WpP18N95A0sXRnyRWJlFXoxhfOCnZEeZuXk9kCkj2ksK5pZIljA0dI6r62+B03wq08FotFQIBKvofat7O0NBWF4V084WqQu7FmprvCtVVeiCVHmLEZWoz1qZyTgiwYcqj/Y1wsHOlRf2K/2RoIo7QRLANDXp/YGIiuC0SjEdazljoq5I4oCeDUSQ7qYBgeD3J1xc3ojPf6VnVGHysIAdR2sTkxBMKyu7g52dussWw2lwXBnaKWfxUzM+p5waK1aGJysdYuOHRIeZa3Wi8HwUjUS6ItGgp3M9wkFrHpclot7oDAILdHACtZRkSC0+ntWh0M9Pr/Rez7NVegwNKcHqvBeGe1FFPoDrJmMpzsQ6jV6FCMjvFawsw6BQPinO9gRhM1FdjuLlq6eUKhnNTNZuNqhdvj6YGtPOB6psU4o7I5GeyumTg2Ei1YHlwd7A/6gr6gnsnQqy00F5xdFTE9G9/Kw6GOGMTGDD8LBBs8FwdHIOH7C3LysB21irgmsCoQwsLi7jcOUudIwUO32FtY5fTya0W64IIBaSyM+eMbvULsiGHSIns5uX2Qp2sx8DF+hR1Fd7enAYAszp/j4RBGLsz++FcwgX19fT2fQx+LD39O5cgV6xKeN52AInilkEg2tVVvFTPGTydwifwACg1o/DMqnrg5GuxlZF24OEW7M+lhxKIg41XQzWRFtroQGPohYCx3qih5/sIvBAHdI70o0qK+bD1iI7ljJBm8fI4ooQQunouF9AUy+kMD6WnhpUFO1AQ+V2qARnuZGrO7uWfGINrJhsDIShjEBLsDfgxmV27Is0BmNBVgijhH8/iAfeBVaiPs6elYFdBM+pkA2ZLg9bJD1JiJFFPV1+9CqjoBh5Pp0DY0w9X1RBFMQXYTBqw30RzmAjbf6WrW1ua7t6SpvrdrQqrZ4m9sbampr1ElVrchPcqhPN7TVN89vU8HhrWpqW6g216lVTQvVpxqaahxq7YIWb21rq9rsVRvmtTQ21ILW0DS7cX5NQ9MctRr1mpqxrjRgJEJoW7PKFApRDbWtTNi8Wu/semSrqhsaG9oWOtS6hrYmJrMOQqvUlipvW8Ps+Y1VXrVlvrelubUW6msgtqmhqc4LLbXzapvaiqAVNLW2HRm1tb6qsZGrqpoP673cvtnNLQu9DXPq29T65saaWhCra2FZVXVjraYKjZrdWNUwz6HWVM2rmlPLazVDipezCeuerq/lJOirwv+z2xqam1gzZjc3tXmRdaCV3rZ41acbWmsdapW3oZU5pM7bDPHMnajRzIWgXlOtJoW5WjX0CFhYfn5rbcKWmtqqRshqZZX1zEV27Fp6+AmInUbC/KTRQdZKdpwnliH/Dj8LxcpbxenFr91zy3vl78o/lP8Gzw/k4/JLw/fcw/fcH8O3w/fc/3L33Nqnh8N33f8x77q13hu+7x6+7x6+7x6+706ezYfvvI133jHvDN97D997D997/7u798bYTJwxfXydiOV/yc+cAcMZNGA4ZfJzppKnTFOeUuYolXjPBLcPsx/bq2tzVrd0WPq2TPgcWgX+CP9OGJMhvnNNyP3HYROJff/Z8J9M2LeLC4j00UfiW9naf+yb09QfCi8V+Og+Dffgya+KrAg71NlrIyGHOicSWO5QG33RcFXE14Fz+wNl7DJN4+DSbVC6in/f+ut4X+S/GfIz6L5EtxOJfo1+k8h0L90L/Fv0W8D7aT/w/0L3Af+v7EcT6W/pe8D/STYRSTbLKUSWLbIFeKqcCjxNtgG3yyMJlTPlHFDGyeNAyZVzgY+Xy4CXy3UonSM/BUqj/GXg6+X/BPoG+SvAN8p3gP9evgf8QwXmKpLC/pK3zL5ZraSx7zkrdmUU8NHKGODZCrQo45Rc4OOVx4EXKBOBT1KmAi9WpgEvUUqBz1DKgJcrlcA9yizgVUoD8LnKU8AblSbgzUoz8BblaWhcoHQBX6qEgK9QvozS9cpXgG9Uvg18v2kSkUyFpieIbHKYq4hkrjbXE9ncYJ4L/ClzK/A2cxvw+eYFwBeau4EHzcsINS83LwclZA4BX2FeATxsXgV8tXk1eNaY14Cy1rwR+J+aN4H+VfOfA99hfg70PSnfJ1LKsZRjRE75Qcr/BH4q5X8DP5PyI+BnU84D//uUC8B/kvJT4BdTfgb8Uso14L9KeQv42ym/Bv5uyu+A30m5A/z3Kb8HfjcFPZvyTykfAL+X8iHw+5YzRLL8yPIOkS030r5OpLSdad8gctpuq51I1nTraCJbx1jhB2uhdQrwJ6zTgJdYpxNqLbVWA59trQG91joHeL0V/rE2WBuBz7M2A2+xtgD/vPXzwL3WVuBt1oXAF9nyiGSbYJtAZJtqewp4o20eobYmWy/wL9m+BHrEFgHeZ+sDHrX9NfDDtsPg+a7tu6AcsR0F5fs2eMn2Azti0m63ZxBqH2kfCTzTPgr4aDsixz7OXgLKdPt04KX2HwJ/2X4J+M/tl8HzC/s7oNyw3wDl1/abwH9jvwX8t+ldREpfmr6UyOnd6X8KfFP6JuBfTf9vwA+kw4b0I+lHML6U+Lhm7zTyAs0msg+jlWR1Y2ySUIiNzTUklyh1VV6cG+Y1LlRJaWtTjUpmzffWsPWAiPnBxMYvxyVixuym4ZSkkHSBsxllhMAVkkoyuH6Wl6AbHmhsq1dJtrd5nkryBN3KIRHvkcsDkTDp5u81/L2Vv/fw94vsYzJyjL9P8ffr/H2Nv2/x9332lqpXLF+xXJrL317+XsTfHfy9jP8bjhRYmwq7rKxdnzhv4j6mvOVDz6nwXwYZSTLJYySLjCKjyRiSTcaSHDIOfTQeXpsAns+QfPI4Zu7PkonYvxXi1DaFPIEV8kmsOmx2tbMeATTByn8OtpIXyTFymlySzNJoaaJUJrVIy6TN0j7pmHRBuibdppRm0nxaQttpF90lb1OuK3dMiqnOtMx0xvSepdGy2BKyrLdst/RbXrKcsLxhuZWaldqeujl1V+qB1Aup11Jvp9G0zLT8tJK06jRvWkdaJG0TRvL+tCNpJ9MupF1Lu22l1kxrPkZuNcZhhzVi3WTdad1vPWI9ab1gvWa9baO2THia+QlzPYtka4Skcsyixbi7yJifu4DnFfhhNHw2kZcQ26sCXtGgnQpYqKuN/mjcosvDU5+faMy3reLWUPR9ppDQLeCmB0p2CnjogZJXBLzyQMlNDabbkkvSVQE9D5R4Bew1eip9iy4Pz8wvSio/ZfRc+96k/F1dnsm/zvMyYj4LEclpIxwCOgWsMcpY+OpgvTFinYCbBdwh4D7OnU3KsOOow56nnTyDk08YO58NZAt5luwm+8gL5BA5Sl4mp8g57COukjeJ8NmIYwKKvh5xXsCrAt4Q8D0NZogYyMgQUHg4o0TAWQK2CLhEwIiAwvqMPQK+IOBRAU8JeElAoT/jvgZHpgmYzVudT+Zi97iIn54jZB3ZRLaRnWQv2U8OkiPkODlJzpAL5DK5Rm6Q2+R9iUppUqaUI+VLU6QSqUKqluZKIhJGCstHNgq4SMBlAq4RcKuAewUULRg5IKDw5MgLAl4T8I4GM4UHM0UkZhYIKDyYWS1gm4B+AVcJuE1A4cHMFwU8LuBZAd8Q8K4GHzMLmC2giMLH3AI2CdhhjMYFecaIzqrneTNGUg78P4WUkApRsl3A3QLuF/CwgMLCrFMPjolRYiyMqhHQy3lSEdfsdq6YOMksnBxacHbWyl8SUMTvKBE3oy4KKLw+6pYGRxMBbQLmDDbGRvcLeFBAYfHos5zbRdaTzWQ72UX6yQHyEhkgJ8ir5Cx5nVwh18m75A65JymSTcqScqUCySGVSm6pRmqU2qTFkl8KSVFpPVaK7dIuqV86IL0kDUgnpFels9Lr0hXpuvSudEe6RxVqo1k0lxZQBy2lblpDRTyOvi7gbQ2OEXE0RsTRmHwBSwWsE1DE8ZiQgBsEFDPtGBG/Y04IKOJnjJgBxggPZgt92aMFnCKgGDfZIl6zxdyeLfRk7xJQ9Fi20JMt9GQLPdlCz1ihZ2yWgIUCijgdK8brWDEuxopxMVaMi7H7BBTjcexpAcUqNlboyRHjIUeMhxwxHnJEe3LaBRR+yxHzb47QkyPGf46IlRzRrpxzAooIzBHjfpzQNy5HwKQ1eOF94zjLrUnKtyfl9SsXVtk/OWRcdf/knjG/+NaDoy5XtDG3Q8Cwsc4Xtg1SR8zMuSIec28/bD4YLyJgvPDYeDEvjBfzwvhDAh4fbCzmiX7JE/NjXrGAbqMf8g4m2XxoMGkTxLoxQUTvBCF1QqmxF55ZostjvZ+wcQh58oj8lqT89qT8s0n5HUn53Un5/qT8vqT880n5/Un5A0n5g0Z/TDhszOeTpPxVY/7xo8Z8wbNJ+RvG/MR1xvykBUn548Z84c6k/E1jfvIJY35K0v7siTXGvEM/qhA9T25Nyl835otmGesX9RvzU9/FLvNtYL0fTP//O6GdOfR39HfYVt+ld8WdEpUfY/dIilkxEyu/7bEpecoEMkL5jPI4GalMUhwky1RoKsT0y25gxpmfMjeTfLPX3Eom8buXydZ06yjypLXN2k5mWBdYFxInvyWo4PcDLn4PUMlvAKr52X92uje9lTzDT/dL+Lnex0/0HfzczdbGHHGan4o3lbeZp7H+Uj4TLy8U5cXsVCn/mfxnOKwWmzHb2P7RdpPQh3BPY9z2STgLEfsTdgeh9qn2YvS7kXu94C4B90h5hlxGCDRsgx2/kW8TxVRmKicWcxFsSjOXmctJurnC7CIZtndsN0gm159l+63tNhltH2fPJdlcXw7Xl8v15dkP279LVPuA/XskP31n+l+w+0mDBdnCgumMbm5g7bG9YjvL7zONHGzfIKUfSeLI4h7UHkJmDCrFyFM2iBwKnjzOqekq15VqEh/kcRp5IJHpYvN3Lkpy+XpEyMxBLUrmqhjUptFEFbyjOZdrUKuSudyD2CWjLManWV85iKwHuTwPyGIzicJHV7qyS9lFCL8x1O4KTfyWMI3fD9r5zWA2vxPM5beB4/k9oMpv/fL5Xd5EfitXyO/gJvPbtyk6+VZ+g0z43bGd60rnt5kj+H1lBr9JHGmdZ51Hiq3N1mYyjd/9lfD7ten8Zq1U3INr44K153NsVEDuNyD3OfocSeV12F+LsNBvMm2Q+iMiWc5bzhNq+anlp0S2XLG8QRTLryy/AjfTlsa1WYVs5u0aov1FklmCVghaMfEbaFm8t9sFDSMdVnx9SHrRD3QXf+8UstnOdhGXXCUo1ZDchPOInlYEWIFUaqBmY04o4ClP0Jnk3fz9fMI+7n/tNplq98WwGOsItyyfW/Y493mBJpditqJl1M1lVgsaIp7mU6eBZkF/pNMptEBPlW4TKr1H6w20q0SWrlNCSw1U7J6T6h4F3yWcXE4aqM8TRTqJ9IL0koG+lZikgzw9K+0ylIQhZwfORNsM1AWQs056Bk/UQJ8FegdSnbTYQC+E/LlIRXhqDCXpKCnmKUuaoi/BOY3d3SGR9/HOMJRdAnyfXJWKDNST6MXr5DS5LmUb6AdBP4t0WCIG+k5iwulwgOzB87ahZA1K9vK0gZwzlDyD/cVGnvx4BgxlLN78ZJ+BxuKtBcngPx5vFTzF/GeMNzYuniOEj0st1n81pChkNS/w92uaZhkjVa6WN3GtswWtECvqIblIDhuomUSR9yBlywv0dPo+uIk8IB83UK+Dexm9Ie+TDxjoZ4lJ9speekHeIm83lGCep8eMlrDPxOQCesBoCd0K2elyOn02yZJejJpV8hS5zkBdRBT6Bl0iZ8nFBno1MdHTSPX0npxtKEH7aRG9JisGKtpP99Bsepbe1NOl9yFnIxKhA/SioeQNjJU3aRedaKCegZwW6TxtoRkG+hHIcVKndAzPe4aSPRhF+2ge9VJDe6WNqGGWtlAzraCzDCVdGCvvIoWkd6mapH8urGL6cwzUUug4LlVIx6mh1VIuxuN+pHw87xpKKEos0lbMKdelG/oSjB0z5ombUhh1zkjnDWVnSYrklbzkAt5bpEPSgKH0EMbBgFQqdUubDfTd0JVL+qVcWB4ylKyHLgpbNuFdxm8FE2VLIK2LvCnlSG4DvR6j+RxWgnOoU2AoKcJoZjNAKZsBpLR4mSRpKyYRFG10Uuz/2KgjltcsP8Y69feWC1ibLlouErPlkuUSSbH8wvILYrH80vJLkmq5bvm/JM3yNkamjY9GO6tPv01/iFX3JD1DxtPXED8T6SV6jRTT6/Qt4uKfVn7OvM68jsxK+1Lal0iVdYJ1IvbQ7HOyuUOeAQafUV4T80pijvhL3Sz0LbHXy+H+0/xQE/dDCn0+3o48tOMtnAuY1dXc6tnc6hpudSPba1jOWrB3slyzXIPX3rK8xT8Z0uZZCbMok10rKF0o6ydhA80LuBVpkYHK+vgFA4X9fawlZJeBNhqQfTMlpgV7Dlhz7WO3YWie7+f7XDZW2RzVxG2o4zR2j8XOG+uEZXWGHbGfLBPUWI/ErP5kETR4NLCePkVO8TVX6+k5fB/8JjlC2F73DR1VIeeR+gm7gz2jo1OymbBb3iMGCQdIL2HrwT6DhGeRFhH2t+m2GiRUE3Y712uQ0IExyu7OFxsksB7NJju5X2P0j9ej8ITl8qe0v471tMz7jfXcHmFVPbeWfWdoK9+fbtLRTTiDufk3o1kkL9OVmBED+dgls8Tui1viZUMZf59mS9FLZqfZgxGAWdms7SH5mcmcb75oxunCjL29eXecTs1pZqx6qEHNp8wbdPyHTLdNWPXMWKvMXXG6Yt5t3m26bHoD1HQ8Tboa602vmBCjpjuQtd5cqqvTYe4wvWCCNSa0E7mcRC3TNrPHtAMlL6OkznRfV8th6jUXmFahDBFquh4vMZkzzZmmdnOaCXtYE/ZtpjOJWqa7pgrTTRNGtClMKHKHEvVg92VTnumCCWPf5EXpZdPOhCdMEAx6KbBbprsJC5W3Tf0KdhgmjHvTJdPVRA3lnPI66JS1wvSy6VVdq3qVAQX7L+Vt1DlgOqizr93UruxVnkfZOZRtY22P16pQNihYZ5UjDDeFTVFdvTxTntKhdKN0N0rzTF7TAp2NNcp7CmYPZQ3KiKnUVJGoqVxXCpUrCnbiymJozDblJTyinEayKa8oOHvybwfdM1FdzYPyTWU/+26Skg8dB5Wriq4XlO3Kdvm8slnGHktRUL4dck4lvCMflo9il3odUp9Xjuroe2TswOWzoG9VDiTaIG9USuUtKBlASa+yRVfSpeTIiGd5L0ralYhOVqOMHYa8Edotilvx6urclEtknOFk9n2mfMWZaJX8OlK2DC/IWDdQL09X6xj2nvAAdqbA5XcVnTfkfrkf+9Y3UZqF0n75vPxmwhKMdHbGu4uSDfIR+ZxOpp++SBGF9Apv+4BO4lx5Ln2WnZLpSZRtkPfqahXRCMXqS19guNwhb9DVy5QzaTtF9NNtKM2U6+SORE3sWd+lmAFoCPgduVD2JGpiJcql5ynmLNoCjTY5X1d2gu+YMQZwdqX0lmzWlT2PM+0etqtk3+TB3PY6vaFr+ya6ie+7ZWBH6dmELdJLdAn20XznTbtpPz2ik9ko7aA1EuYi6VXI2EgTs5KJFtNiKUoLpXUofRGlfrpOVzNTaqdp7ASLU69MM2kdXZywRnJKaDHbldK5OkvypYs45UpSO29fgjuNnVxRg0qnaK6O/xC5TTD/SZj/xA6c65Z2w+LLWHHZyVgSO3CtxnryilijqbReuqCrgxM3dkJsNsb8h9yxRC2yDbrZHID5D6fyfl0tB+nFbph9LodRIm1KeEfKlDJJO3bDrNWY/6TuRC1yF2fWm3xHg/mP3JUaE/Wg/TLJIxf43gfzH7ksFYvSoe0b/2132+x2ag/Wyk93163fb4szubj/Zp7StH4TkmJ3Y8kcT8U5mPSd7A6PS1ce4Gw0cD5Ld4jbPpnvNNmeg906rOK88ziNjRB2o9Kho20V8poELdaTH//Gbqi3fCf5++/4DtFD2Oy8RuyHmnhbQthVMSv9Oio7uTzPrY7Rhqr9a8yLltctbz7kzpTxfPPj78h4z1K0hI3a2J65mdP8/FSzz0BrIXv4WNTT3PxOaZWBVojzMes/PS2Ln6aa4rShemJn3BMs9xckcQP7Df5+jr3Z9065vZt19rYIezfo7G0R9vbq7NVoHfxU2BSnDdXeZw32/jl/73hkLyZGkDarfR7cqY+Yg36BOeiXOJVZ+exj57PPCD4DZHyCmmzUsZmXff7+IrfDy2ls9/8s5NaLE65GLeHjQQYsIRt0dDZm2X1IDk9douTTO+98nb//irDvwMrkykdsZWGfaGn53R8tM+T9H33PkN/0kTmet5GUD7KIn3/akfiUhVGn37clUS1EguRkivOBmlcGlffBHymv/Y+gVCdLv7d+MJ333kjWiR1SCWHf1ahg3xKuPEGo7mF5KemhArZU7qrcW/l85QuVL1UeEe9jlS9XviroZyrPA9foGuVi5ZXKa6C/DfrNyjuV73uIx+yxeTI92Z48T4FniqfYU+Zxe6o99Z4mT5tnkWeJp0ujaHI8IU/Es8azwbPZs82zw7Pb0y/o+z0vIh3yDHiOe17xnPKc1aQJjfo31yu0a3r5W8jR6j7w/hgtfXQbtdbp2qVv0T/TFp0WIVPzg1ZX06vZo711Fgr+C55LlXs9ZXiqPVc91z03hOQHWqTRH/qp3MdbW45hn8hij/0leOJazJ8W94D7uPsV9ynAs+4LeF9yn3UdcV91X3ffcN9y29x38T7uLgZPG+C9SlppQcklllxHwHkd6XilRUtJ0hKybnE5TEpCxlngV0F5BXwDSKzW1cp0963KLJRqUm6QxGeBH6+1A+Q4by2btUlFGC0t/vedhrQXTmrnzC2kxdXkanMtci1xdblCrkjFMtca1wbXZtc21w7Xble/a7/rRdch14DruOsVPKdcZ10XXJdcVytmoawffJvBtwPll1zX+WOQppPVz+UwKXEZ4LjhugX+uyi956ZuizvdneXOcavuiYAOLuXqENvp4CuaaKdzH7G55rpaXO14Frs64niHqzsuP5Xup/sh/y9xlpXod+h3MIr+mh7GOe7H9MfETC/Qn8CGn9KfgvMyvUzSoOvXbI8gLZYiqG8j7JciiLOEPxKelor3XTgeuGyuTFe2K89V4JriKnaVudyualf9Qz2V7PWEv5h/mcfuuu65CmL+ci0SHnO4S9xO14vs4fLYw+Sxh9UHn/55pG2D2cVsitkTs2UwOzzuGvdcd4u73b3Y3eHudofdUW7XOvdG9xb3dvdO9x73PvcB90GUHXYfdZ9wnXWfdJ/m+XPu192X3W/Enofc+X+imaxsJ39aRAzMRdLeiwERD8DCriinhcsHXOuQwjxiNC4tdXDKXJQnaHppCVlRLo9JScjY6Nri2u7aqas7V+jdg/c+1wGWyNA+YZD4t6fjrZ1xgD+2ihNlFypO4jldcS6On6s4rNMy5Pg3zikzEPczb868U+HG+6Z4d1W4K0IVNmCZFdmMVpFZtqAir8KMvBkc7zMuLYEvxGDZggRNL00nK5vLY1LiMioiFVMqiivW6OreFHpZ3Q0V9SyR2F32J5hTSucS28z+mftnvojn0MyBOD4wc3dc/tB96uefd9hwkh9ByPSrQ35sM0c7t8/MxZM/szCOF84s+hTuRYbeOsOInE740+Lc5tyBtBswgmebs9+53/miM+Q85ByYPtF53JmN9w7QX3GeAjzrvOC85BwAF0tXkQ4h7QBNS0ZpcVmQweQwKQkZEeAhUF4BH9PMaoWc18F3A6WalAGSuAf5BPNPSSZ/WpzUaUFKB8wCpM4cp1q+xDnR6XCWOJ3lZ50ep9NpKS921pRfQvlcZ0v5XZTksFS+BJwOJEv5XS0lSUvIcjI5TIpOBuOYCEoN+NhXB1itic528C5GqSal5NNp7bQC/rSUR8vXIW0E3IInWr69fGdZpHxP+b7yA+UHy66WHy4/WL6urLr8aNkN8J0oP1l+GiXbWSqLgHMf0jrQtGSUlpB1kMlhUnQytgDfA8pR8DHNrNae8nPgfR2lmpQDQ27tG1IWb62H/TvH4rKP9bSUvVp2Bul82aszbgN/texi2ZWya2Vvl90su1P2fjkpN5e9X3am9FS5rTyz7Ex5dnnetCkoucjTNaSbSGemTdFSkrSErPeZHCYlIQMcZ8rehlwb+Jhm1EK+ALxMA5dSdmeI93OfYL0qU/ljK8styx8kFepu0YZym2NcGwf4Y5txcsZpXTon4MlPVVc9f2wzOmZ061JYwI5PqOs9SVuZ2tl3TZ48/Kk8LaWnp/c/ub/0dOlp7V167v9R9zXwUV1l3ud+kmY+EkKahmSYzMzNTKY0TdPMnZnAVhrZiDRSpJRiShFTTCnFFDFGjMhSRETEiBERERERESkbaeSlETEiprwxsmxEGhFjlhdZNiIvIrIRkSWTfZ7/vROS8PHW6r7u/ub3/5/nPOfjnnvOc86958y955LbZXYXdZlnIHeQ22teNNnfRb4r5rXBX5fZVUQ/Ck9EVWB4bjfz6kQ+nMtgHtHUaHo0K+qJBuzc+Ojd5J6h8I5oOFpEP/MvWlX7C2ZNhTOobrz/vX/22tqfeZ7O8661PJOR9gqaF0UmE8huI9PJnTUIEZlzG1QRFhBqCLUEapXICsJqwjpCI2GTrdtKoPuGyG7CXgL1w8hBwmFCO4Hu9yMnCKfsuxh2zxEuEC5TGa6Se4PuwGQhmSnkugk0Cps55NL4YYYIhQSaiZnUB81J5Jbjjk2YMwizCXMJ8wkLCYspTh0gzGWElYQ1hAbSbSBsptF6PCDZ7m1lc9sdw4b6B2HutNPtGaFvvhnfbLk1nQW5M5IT8UVCkcJISaQUmBQpJ1REZkRmR+ZG5kcWRhZH6gjLIiuBNZGGyIbI5si2yE7CnkhzpAVojbRFOgidFKfLjttNOBPpjVyMXIlco7wZCQumGmkBUs10QpbpifSagcgVMxxZaRYRUilOarI8pknlWUnlmW1OpLAywhRzGjCT5ErCPJIZ1SQvGlpOcwlh6RD/coa5KtJgro1sNteTvJGwxdwO7CI0EfZR2fbZZTxAOGQesXEUOE4y4yTJJ6HrYUTqzKOMpN88SzLj/N1BaS7ZOGruI/SZl4DrJKuch90OVL9RQed4luq8jmC3i3k2qkc6os5k/UczotlRLyE/Oj5aTLpQNMaIPmIejU6m/CZGp5pqdHp0llV/0TlDEa1Knn/kTHQB2u9MtAYu7CJaS20yDaizyhWtp3SEwfa12jU92Y7D6lO9mW90hTktuvpmu93Sjtz2aP/oOjpuozkluokRnRXdGt1B/hHxb00f3U3YS+n3U/qD0cORhmg7tXsftfl5wgHy77jpH27f0WM3/dEThFNmH9lNnxU/enpo/Og5woXoZXM7cDV6w0JMBi5biKWY2xlJfcxN/kxCDtncIsuN+QihSAsDtnfArru7wY6X7I+xQvMIUBIrJUy6ab8sEwbtl2TGIep/hEhdrJSRtN9YuXmUkbTTWAVs8lJsBvmvs90Ob3+ydbIJAtsl2+KI8Fg5+XlM6bbHhzrLjgfteaEtnyFbZowcV1otO4/NprzmEuZH9dhC8i8muY6PH1sW6YjRsWNrIl2xBk4b20Dp7fEoNp/8CwmbSd5G2BDbGdsT2xlZFq2KdEeryL+M/M1WfPIn47dQ3FZCWzQ71kHojI6PUXli3SSfIfSS/yL5r5B8jZCIjo+r3A/jqVEvIT+eHi2OZ1n9Lu6JzooHojviYeprU8190elmU3RqvIjciXHzZnhkvqWPe26OV5Gd8YnRCxgDCfEy6uM3+2024xbbWGVDHYFVwxEvspDsm/Ep0QXxaRiTZ9OYPD8Zj8b08sjF+MzImXglufPi1bGdwCLCtNjOIbZVOtS2qG1KAXtsi5XHl5gH4kt5XEI9MzKt/hBfTmVZjvKspDqoSrqRSfFVwAy6Ns01l1JfN4Hq+Frq77Ot8SK+Pnn9omuEaU6Jr6dxbjbXZ3yjacY3Jv0Yx4bF5/HILCIkr0NDrhPxLSPHh8ie6OU49ff4rujVeBNh32Cdj7w+XLf7jd2f4gfMSwBdSxjJcFu+pV/d4rf7xc1+YNef3Q8irdQH0A/iRyJd8aPx49EYQGWJ91D+w64HkcVmU/ws2dnZZL3Ez5PdXSK7ozE03ke4Hp1aKm76b7m+2ONO0oZGnv+dr8cYZy+U6uYRwGkeLc2gOnLTGEYozbbH6/P2eJ28ntgo9UZ6S/MjV0rHR2aXFkdrk36qo9k0VtRatnrzulUaozwZj9iYHNtZOpVguyPLOXgex3HNP1o6ncpo4SgwK6qXzqFxisaW0irc71h9Y0Y8wPZUuiDSVlpDbZUMt9qlOdJZWhvpKq0vXUHlXU3lTdpja6QXfW4m9blKaocpFL6O/NXkX8T2Ong/xOezYIh9LiH7XHrLfcWI+zfzbGljpI5g+0e2Y+mmaAzYSue2g7Dbuu5bY0C01jxk+bm8XD5zX+leC5bdR+tL9zPMKZHy0oPU96gfUb+bbfePppHXmZHjO+XFK3PHSk9Q25zga8LgfZFJYaduju+lp6n+zpVeoONcNs3Sq1T2G2QD8EcqyD+f/PMnyOa0CSkEd2TlhExCTqQF8EV6J4QiVyYURmZPKKF6vbW/Wdcj+34rOU4n75fEf4d3mV8Tf+866jolHsO7zJV4l/lpvMs8h8o3Tv6dfFkIZZxSTCWLKDGRpXxM6RM56gz1CbFenaW+SzRqhdrXxUZtl/ay5NT2akekdK1da5cKtA5dksJ0Ipo0X0/RXVK1nq5nSYv0bD1H+oDu0T1Sne7V49KH9In6o9Jn9af1aukL+gJ9ofQ1x30Or7TT8YyjQ2pyvu5yyjm8C5s8y7XR9X25xj3L/S55k/tp9wJ5i3uZ+2Pybvdq99dkmq9Ix+QFmDm281NCwRQCzcqCNCsL5gxCBH23Ac3WgjRbC9JsLVhKoNlakGZrQZqtBWm2FqTZWnCuraMZW5BmbMHFBJqtBWm2FqTZWpBma8EGwgYCzdaCNBML7rRdml0FmwktVIZWctsIHSR3kttF6Cb5DLm9hIuEK4RrhISQQrxnQSohnZBF8BAChDChiGBSnImACJURphCmEWaSrpIwTwj/ZUCy3ZFy0i/dLk6o+o7pR+YBhBbZ6ZaM0C+9GT+0/NZ0yXzH9+bz20Fj/+a9g9/0534xD/3iPegXVbymkfoBKtFxdcnNVYrAVsIOIQK7yd07CBHYfxscJBwmtBOOEU4QTmFfCxE4R7hAuGzrrhJuCGHIhBQC2bORSSA7NshuDbJbg+zWILs1Sm2XbNcgOzUqhGSQ7Rpku8ZcksluDbJbg/qGQXZrkN0aZLcG2a1BdmtsID3ZrUH2apDdGmSzRjP21xAG2axBNmuQzRqdgDDIbo1uAtmt0Uu6iwSy27zVgGS7t5WNa3cMG+ofhJGw9PnqcH1+6s34+em3prPB+/DOEgvEErFMrBbrxWaxQzSJFnFYHBVd4rQ4L66IG5IuZUpeKSzFpDKpQpolzZOWSHuly7JbzhZqeHZ4bnh+eGF4cbguvCy8kjRww2vCDeEN4c3hbUK23PBOkraH14d3hZtI2h1eHd4bbiRpG8XfE95M0kYOC+8jaV14AYXuJ2kl5b85vJCkpeGZ4S1hsq7w1vBUSj2LpM3hSXSkuUhrhpeEy0hqDI8P14anktQQ9lHqQpLWhrPC88ImScWUcmo4m6QQ5V0R9gklvDy8imKsD28MZJHeXXAhHCq4SpJacCYcLkhQjPpwVXhFuCZc6+8TcsHFgo7w0oIuks4WHArXFvSQdKpgf3hxwWGSOgv2hBcVdAjVe+nmj86nRqR5e97cj46+QKR7t735X7iIzn6Ud+7tfwXX6CzlgszQ5YLC0A2SUkO9BUUF6v+Aq3Gqkq6QhSsvKS8l97/V368vFamOEkeJyMAOqGOwx+m92Ms0C7uY5mCfUq+QyIqxeiwtEDQejKP+51VvA7rOeOkoXrrOeOk646XrjJeuM166znhNAl1jvGW2jq4zXrrOeGcSKgl0nfHStcK7iEBjv3cpgcZ57yrCWttdT9hI2ELYRWgiHCAcIhwlHCecJPQQzhIuEfoI16kfC4JOcBIyCNnYU0nkjScUE2JC5HT9v5E39Q3EmU6YNUI3x3ar7pjuyWBDcENwc3BbcGdwT7A52BJsDbYFO4Kdwa5gd/BMsDd4MXgleC2YCKmh1FB6KCvkCQVC4VBRyCQUhSaGykJTQtMIM0OVoXmh6tCi0JLQ0tDy0KrQ2tD60MbQltD20K5QU2hf6EDoUOhI6GjoeOhkqCd0NnSefkdDl+xfX+h6ARlhgbMgoyC7wFuQTz5BnF8wvoCfzfPAwoWSRRYuwcJ1WPgoWHgqLNwJC0+Dhd8LC88iC58uxsHC/fps/V3CIAvPEEFHJtn5eNh5Iez8Idj5w2ThY0UJ2fYPRMz1Q1ebKHUdcbWLiWTn/0SW/8+un4hHXT91nSD7/xlZfjksfyrZ/G7qBXvI8vlZ99y/WVm5lBNRykdQykdRyreilG9DKaeglPwewxa8ce2kO0+yyxy6nubQfWDOtpvIpX6TS30ll/pILvWH3EM2yNZzydbvq3vDuDe/M78rvzv/TH5v/sX8K/nX8hNBNZgaTA9mBT3BALlh4kCwKMj/T2UMG9nGKPfSyPFOGqk0GqOeErpeSSPVKMcYxxiRgnHpHlcOjUsOjEtO12HXYeFyvUajk9v1I9ePRZrrmOuYyHAddx0XY1yvu7pEJkaqLPfL7pfFfXS80X+14/GR0nCkdBxpNI40Bkeiu3opX1qOOj8oHqDrP41J+UU2TBs0XuVTvedPsd2JQ+Ik/ROH+MuGhBfZYTTG5c8cktfQ9El95ZD0jHk2qK3zF9nxw7Y8T5jGBvzaCB22PPTXYXTeRjv01wXuNs4ManqNi8YVcq8NahJ0R/dftacPP/+WL94i+D36d+P5/BL7n2b8O5m2T6RlLjZ8RsgoNEqMwuzzRqkxKXMx6cqNiqzLmZvx3+Bm/NP8TfmbZC3f4ufv5VfkV4Qs75P3CUV+VX5VqHK73C40/E+o43/CURSrg3fooGNN4V2U06YIeQjYL40A65Ws+kGwbkZazeiiQHOgJdAaaAt0BDqTbtojga5Ad+DMYHhv4GLgSuBa0j+oTxiqkWqkZ04zsjjc8BiBtHojbBQZ5uhKY6JRZkwxphkzjUpjnlFtLDKWGEuN5caqtPa0Y2knjLXGemOjsWX00qR+8PiUf9pVY7uxy2gy9hkH0t3pmek5xqFkuHEk7RyFHE0vMY4bJ42eNK9xNq3WOJ88TrJcI13jktGH8l233WT5bHfw+HZ+d3TfZL294fqy62Nk/YyslzdcH3Y5BuMnj2fnM5ifXb6R7TzyvJLp8wVr8vVk+dLn5zvzM9L2Dh73DvWSDCfbV4c9Ic975KfiOXnXX/ZsgNMUM1w33LI7xe12Z7pz3D5XtjvkLnSXuEvdk9zl7gr3DPds91z3fPdC92JCnXuZe6V7jbvBeYnCKiheCcWbROFr3BsYw3MbklcF8uFcBvOgGJvd2yj+Tgrd4252t7hb3W3uDnenu4vcbuTS8OaeqFa7tUwaAZxiEV1pJHwpgEZn2x0J3XZV21UI8pDwoem0EWmfyLue1uwTjnqf7m31OfOO+jJ82WkteX0+r7fTl+8b7ytOS/hivkd8k31TKeZ0ijnLN8dX5VtAvhpHvaMq75Cv1ldPMVdQzPG+1b51riYKa6SYm3xbfTt8u8m311E/2unb7zuYtzw97KtJa3NU+Q772n3HfONHn0pLOA77TjiE71R6ke90WofvnO9CXpnvss/pu5rW6buRd8Qv+1PSmv1uf6Y/x+/zh/yF/hJ/aVqXf5K/3LvTX+Gf4Z+d1u2f65/vbfUvTObpX+yvc56hdMsc9d4O/8r0Iv+awXQN/g15qn+z77Qzx7/Nv9O/xxX2dowuTjvjbyZfi781vWj0urSO9Ep/W95Efwel60zr8s3yd/m7/Wcop14Km+ab47/ov0JHuEY18Yg/kRcIqIFUX2NaayA9kBXw5C1Paw4ECOFAUcB0dqU1j6Z6C0zMO+6rHX2DpDLClMC0wMxAZdLH5zDcN6JehvkC85L14p4TqB7uG35+KMuiwJKMCi6LO59LFlgaCLvP+RfeNey/3EL+SjYxzAru1u53bem/Stum9QaW+64GVvnGB9b61jkTgfVU6ot5fa6JgY2BLYHtgV1pV3w3Ak2Bfa4lgQMZcvpEOnrINzlwiOvap/t0x5zAkeFW4DjFYeQ7GjieVxk4SVIP4awvP68ncJ6OXs81H7hEx+4j/XVHvSECRwzdcPqcRkZap5HtDxleg9rWGE8oNmKjb7hW+UuMR9K6jMn+BmOqMd033lmX1mrM8m7w1RtOijWHcqnidIFLlMuCtE7HDp/XlWXUpC/PaEgv88XyThq1rsr0VKPeWOHfZqz2VSV9jiry2WHpqYGJ7MNzzPwWo8CzZFLKsZSfCDnlpymvCz3lZMovxT14iiwNT5GNTvl1ynm69+anyO7FHdQbGEHxLZVpGEcf5z3ypDa8LYI7KF19U5iR2uBd4K3JOe6tyc3w1uYWe+v1Rxxmru6t967w1jvOe1frj3jX6Vu9jd5Nnrm5p7xbc696Gjw53h2eUme7o8nTMnYnyTneGs8ySrPbU+Ewnaconxq6Fgb0bOd0p3AsH6d6GsZleVePCyThuUb5ETg/gNJzvKG4fdlSu1G225SLyzRYHrsstysH8qB8OR3H8VTQcahMqQ3jdlG6vdaxxvV45o7r8+73Or07vF7vQUePp8H7yNCycF5o9Vufs+wafM5Sw3OWqSm9Kb3CgactnXja8s+/PyjDPpX2e5oOmqGMSyWkW2B/brYFKpUFD1zZ00dz5ju9Z5x8u38/9h92isn8zZnUs0KyoQyRJc9RuDLk41a45yTiuz27PE2e9Z59tnvAdg9Z7tjqIeFHPOuzfZY/6XqODnEp3HPcc9LT4zmrrCT3vOes59Kga8e7wxOud6p5rnPnXe/X+L3l9ehRXt6T+Z7TgGQjK/ecJ/ONwJPjkT0+T8hT6Ckhe5xEKCf/JE8F6Us9Myh8NjDXM4nj2y3zGSrT5/iddnmjvBHvnacOLSnOMRXn6MBTvE6cowvnmAG7GoNzzMTZ3Csk7HQlJ58ovyf9jpBuo3Pm1uWW5Fbk5thYlrsyd1LumtwGwgYKySH/ZtK7GTlXcwv/P+7AsFy03HxGOecawUdIkO2rlpybarkppSSn27osO94QOZf6R24A8TJyTudk55zLqSGuIj6dcyFnes5W/LLxo7C/ydv3EvbHH3z+W3gAiXdior7LX22z/82SK/ltbsWFd7o/B84H/wn8D+B0xNkA+TrYB804yNshPwr5NfBscBM4yCxVMIsPQPMj8DugPw35HHghNP+B3PzQfANcCs0DkF8BT0bMLyLPVuaBf4X+ZfBbEdoF+ZOQURLxOjS/A38QrEP/L2AZ+dyPY2EXMwVHUVA2ZRri10J2Qm4EG9B8BHKCWV0GzVlwCvgP4F+Bfw6+BP49+P8iVQFknJ2C9+tV7JSvjoEG9aAVQ1MGTR9k7DihnkTJ3ThTa6/HX0O29t74NzDKI30XbO1nsQfyfsjIQVwFPwhGSQRaSjoAtkJhIRLqSoINSCiVQC1J1veyLoJhJwJnLULgL4F/AB4LPgH+KPidYNSzqMIZWe37HjCs1NqpT4qCJ4A/DZ4ErkOcFshjxCHiVsHf4zgP+WWWpRKW5Qeh74X+G5D/FfIOxHkccaZC/jTkHMTpQpwvQP4PyO9DnKmIUw79z6HfDPmPkL8D+SGWqZ5ZboZ+CdKqkNdCnoZ83g55HeQ8xN+AODOhL4P8GmQf5IfBr0Pzbsi/guyHrIM7kM9vIb+C0K9Acxaar0P+PuQVkDsgl6MMGdA8CI0G+UnID0D+KOQnWR74Fs7xA9C/Dv0vIS+HXAJ5BuTJkFHP0qOQn2V54AHw76CpQm5PI847oJkHOQb5S5BxLPl5tPgA+mAheA14FjgAxt748hYwxiI6OyvVdsTZDj1zzM5nO3JmboAGPYivrMT/BP4E+Enks9w+opUD80poVoPRv+RPgWH/8iYweor8VfDPwFGk7YHcgZ7+FTB6t4w+KFeDsdsOP6UjeIdtlg9Bxmgp/xGprLHul+A50DyGEQMlV1APCs5XseJjF0oF56LMAKtg9HRlHhijtNwLGbWtYPdLFTkr34H8fyCjJyo7oHkvZJRZOQ/GuK0sAaOGFfRuBeO2sgCM/SfVZ8GvQgNWMepquIIoj4MxGigYc5SXwGgXGSOSMgpsjdXITXkf6urDiNMPzUMYPb6P/L1gjEXKQchofSGQCmdNsyhm1ImM8U3GGcnW2D4TjNZXMLIpL4L/DoyxXbHq5Gnww2BrtMeeQfJWHFeCZhx6Yi/bBqXdjnyYX7NDt+Mo25GWOIGxXX7PwMPgAuI472co1w5MIH5WS2ObV2k2KH+IrECS65Ui8NuJaygnSV5B13NJXqU0Ei9TeDe4T/Ku1aQvA08h/jhdIVmuAL+N+DH1SeIyajGyUvUJ4rm826DcQnXJ+vcSvwj5Gd6DjOKwHFefgXyOeOkA5zATMZ8BLxyYh1Qc53nltxw68DKzFkDMBGJ+Czm08D2Mxv8TvDTwFeIi9Q+s196CHH6KON3gDqT6A/gHXCfKeMH73M8grlTruCS8G6L8vHqRWePzrRzI4fpBHT7PuzsRv4N54OOQx0LuJG5T9rAlDHyZOIUsmniAcyvW+VyKLZn14nqC90faxKw4WSPtZVnqg1wBuU3dypbGqaQ25FauhXlkRj4hxST9yf6NSLWZuBZyG2R3YgmP5wne6TCkVbO+n2pAauSzkwqRZyHOtFw9QvIZizl/qRFlaOS0UqPMezhd55zlYu0yzqWN8+T4pJnDzDnLG+38jyCHJXxeyK2PmUpCZySvQ6p1Gn9ZuBi7Tl7nkihOnGkfM+mPIG0D0jbgXFrAXCe11rmrVYhfhVpinqfyXKgVZ1SJOJU4yjrUWAi1F9LQc+3693Fa1MM8q55RttZEF/JEnatXUW+oVZxXG3Irt46OtI041mqVLSEDte1jWVmiZZLcjdB1qKUQ6rAVJalEDc9LOJm53uh8ueeuQ2iGVZM430YcvRC1V46zK0atHrMsATVTwUw1jLSJ86g3AeviM23AGfUht2zkE6JRjWvvLGp1Jtcq8ikEN+KsC9l+KHQScutA70CtIodKtHilVo9a7UCcenAP9D3QN6BWrRpGGyWsmkcNoy3akKoNMc9Akw0uZIsVHbDbRg4VPeDriSacaRPXZH8r6qcVlswtuFPbjpjbWcMlFB2sF6s4vrQcofuZ5WUan3un9iO+7uiFXPPga9rXeXzTXmU9rH0duFnrJ76fmeI3In4jWmoj6rwJdduEntINjdWDLKsLoz6dqFu20nXcp0huRk9x4rx4F9JejAl7UOeFiFPIodRbdViajrbrRMtOwlE4/na0SDFqoI3zlz6WGM13jOAxGAd+jtZs0xaDuW4v44gNyCeFS0J9pxmt3Mz1Bguch557HeUfY7UmtxdpwKjb61Z8pA2pK3BGVzButMNic3CmOeiDm8GwNN6XVm7lLxOQbdTBcqqRfzVsAKMQj71kCTwCL+VWph6EFue9eukoMng1tzvqPEUbw3mCK5npKLC0/m1cP4kIbB6jB+IfR187Dnk3jlsIu9qYmIq2m4paXYFUK5BzKo/S3GtoDG/BqNsC/QzWoz/u5r2MqeSZKFsLSjIDmjCuWdRT1OforkpSSxP8ffPHsT+vj1tHns7XROqn3Ede4fMS7Syri7g/qoswTpp8dGWqNQbyseSJLIsOxO9BnLdxSynmAK/+taPFD7BM+hnQlECTzxouj2jXY9B38KhlpYKVevrbIXOpDrAs/0qvBPOdwK+4jytZSOXj75gTV3IOHFPZDO7i0qo6SluD0m5Daa9zaSmUr+znlA/h6Jk41lbIYchsV6+pvIIzMMA7Sp6APbgH8iDzWuRrA29BHN7Z8fLAR9jeeNdtOWPURDDbcGIU311kpCwAz8Q1tITrTT1OPEe5yqx+DpbPfb+Kv+dOdw4L0F7c99+j3oD+ErP2Gch87/Ec751NGoTq/N9mtb4M/GFwI/LZA/ljnL++HJp6aN4JuQNltmL2QM9xnmdrlF/U+fr1kv4N4sf0H3MvAL+K3Mr07yI+3ykt1TjVM/o7wHxvNkb/JZdfv5fP2rra4iiV+k7ODWPgY5ZGDDDzd3aIOZ9KuQYyj4c1cgo0S6GpBSOVdJKPK/2OS4vQ52W+b3TJ3ZAvgS15G3gdszQLvJBL3s/tUp14H/GWfr7u7+73MN9Yjv7ObfFi/48R05I/z8dNPMTc/yUuW2I9W1T/bpYxNtagH9XwVUx+Hv33+f7pzANfBOPuYmAt5GlgS96F+Cb4F4izFfoqPhb4+YFTkNfydcpKZR+Fx08F/FmEFrKsfB6aBxCzFfrvQ4OdXyVrBvd1yM4BHrGb2aqlf7fnFNQj+H8hwfNfvo7/BvrR0OwEx6G3Zo6fgQZzEAlzNxkzMglzSekZsLXK9y7IF8BY35NywZjTSd8ClzEP/CNkzOYkrH0Jq7Q3wJ8FY34tDiNna00G61eStW6DuZX899BgFiy9AMaMbADrhxLKL2FeKbD6J6xyIo6EObtkrUph3p3AvElGCSXUj4wSytYKGOabEuahAjNNySoz5rkS1qBkrGRKWKWkcYc1Vn1a8y9rTfInYKxDSljZU3BGEtYYpRKEYiWKZj4s48sOMsopo/zCmiNbawUbkQrreFI3QrFiqVh1glVByZrJYmVMxrdKZHz/T7FWZTFPlPF9QdmDHKyZstVqWJeQfgy25rZYVZCsfLDWIay1x29Dg7VHyfq+gzX3Pw79D6HHmuQAZNU6orW+ipm1wOqKhPm1aIYeK3gK5s7yXoQuAWP1QEadK+2Q0S4SVgwka0317WBr/RPrmXIecrbaCPNoyVrPsVaPrfbFzFdCyWVr9RUrtxLm0RJWeqV3I0+r9bEOKd8LGW2qfB7yL8BYB1awGilh1UX8FvGtNWd87ULCiqhktRpSydZqJNZnZOtbS+g7CljG6qu0Aow6Fx12rVorZsQa1hkkWKls2SpqUo7ZK2+W7W0ntlZNn7RtkjQK1oIklFDCGq/8JOsHrP5rrcZjJJGw/mN9HVLFGqnyHDQzEIpVbgHbU2sQinqTsIourLUXazXGGjeewlnguCr+KVBQqwNYa1JRQsVaW8P6m7DWN/DdR9VaFcFooOB/AYH1E+kyQh9BmRfifK22/h74CcSfCBkll9FPZawPy1Y7or2UxdBY+XwcGoxgirUSiPZVMV5JsEZpO8pg1RJWeBJoU5rDM58Co54HUG8JrLMJa+3OslWUagD2Q1dE1mD1JoEV6X709H7sFd2PdSEZ/wgk8EXGBGojgXGjH7kl0Fv7sdadwNoRXdWYYUsJ/O/Qj9X7ftRwAv9rJDAO9F+DfBiMPkIzW2YTPB4lx3gy0Ay2VukzwbDwgSNgrHcNYPWpH1cTupqyXIyYQqSKXqVBKM/WPjtfZC58bn6t2FXzbN1i0SI8Qp3y1pk+UfL4tKd9ouLJ6eU+Mf+pmcTLBN28iRT+pq0YLbJESDwgcvn/RdLew891igxxn/CJAlFIubhsfYqQxRiRLfxU7gfFOH5eAfp7hELlHisC4n5RJLy8Qx30qUIV94ocYYjx4iGRJ9L5/1iEKcIhNFHM/6hNmzXVJ7JmvvNxH6XkMCuGJPJtNygefu97X1wihcEmuAw8DVwJrq6ueeF5qRG8CbwVvAO8G7x3wQuLn5X2gw+CD4PbwcdeWPxCnXQCfAp8GnwOfOGFD76/RroMvgq+wSzL4BTK/lnZDc4GB8CF4FjN+99bI5eBp4CngWeCK8HzXnyu+gW5GrwIvAS8FLy8ljKSV4HXgteDN4K3gLnv8Nsz/MUE/U3ImfS7l2zhPmrhsdRqudTy46hN8sgO/NS2BrVIkCwFVwb7G2Z3YowH1P53Y+dd+Z67sEKWly5G/xmSJHDvItDbrbsZ2KK9ggxX4ucx7sJpd+VMERELRb1YKzaL3eKA6BFXJf7OZEiKSVOk2dICaam0Rtok7ZJuyE7ZI1cotcoqZYOyQ9mntCknlLPKFVVWM9SAWqJO1kq1qVqltlCr19Zqm7Xd2gGtQzulndeu6SmDZ4JSa7tH+Heh9w5+kVrbP8RP4XrTCP9l8t8jbn7jnSxBT1juqBTbzUQamdotw9ZMtN0pw3MbtQq53fSvHuFfM8K/ebjfXTvcP0Yd7r/v5BA/nV32+BH+KcPPfuzq4eFjWxCeYn8bvkjExCQxBd+goLMZ22m73Zabs9122yw395jtXrPccdm2O374UcddH+73yvAP/SY9pfLqtptuu3bte8OIPU6Uial0R1ApqsiulpBlrSTbaiTr2k721YxdFTvEcXFKnKG76sviGm8xKqVL2ZLPzmeN7W603Z22u9922233hO2esd1LtmtbQZ7bdu1884ptd7Lt2rWXN9d2a2x3ue2us90ttttku4ds167VvB7bvWi7NyzXZx/fZx/fZ9rulOGW7y8fXuv+ySP800f4a0f4tw7xU/7GtOHhxpYR/j3D/SVNw/2RWcP9ZvsI/8Xhfcfsgz970CZn073YArFYLBUr6A5/Pd3lbBO7xF66rh8S7aJTnBSnaUZjt5Z5xHaP2+5p27XDo8J27dqMem3Xbs1oue3OsN15trvYdlfa7nrb3Wq7dmtGW23X7kNR25qifZYbs2s1lmm7AdstGl7r8eLhtRQf0WrxecNHhPjQVpHJf3B4/NJJI/wVI/zNw/0TzOGtMmHECDehfIR/hJVNKBvh5y88kOycDm0dvwUk1FHOUa5R7lFpeHfnT/xkhpRH/Za/2nWFrjYeGpnKRIWYS61fb78fzXtf68KpZAhZ/qNyn5CVUbbm7dDkQEPH5He8lDF22GMIyxoSuwKasYOxMxFbw/sK2TQ65eMIv0euV5C+D2n+4Pw2xdSRJjuZmnXyH4elpjD5GpeP8shBHlnIYyznYZeBSij/Ox9Zvoqn5n4v072yolOeKcoYKg1/myAk0tUc1VDH0hUxT/WqfjVbDfM7amqhOl4tUB9Q78eTl7+XaQ4g93He8h8pHxX56PytMcotk451j/J25R14Ss1JB1mpvyQP8FEVfJZFSVVS8U+fE3dC1veLyu07g7D99Uj+fnTJEJ1C7VOEb2p6B7Vkffpj+Ma8LP9JkZGzE2cy9JvzYTFpSP7329/R4a9xFg/quEaG5KC/pK/EU42Se+Zdwp7E9Vl2nXf9msuiqA6nrfmli0dWWb4o/9aqA+U3eibNtikvPUunmY+ew1825H1AuPTSIdGjeBWfkq+ElUKlSClRYnSnslpZo6xV1inrlUZlo7JJ2aJso3uXXcoepUnZqzTTXUyLclA5RPcy7cpRpZPuaE4q3cppuq/pVS4oF5VLymW6w3lCfUp7UHtIe1iLaFEtrk3Q3qK9VXub9pj2hPa49pT2tPZu7VntOe0F7UXt/doHtA9qH9I+rH1E+6j2D9pL2se0j2uf0D6pfUr7tPYZ7bPa57Uval/Wvqp9Xfum9or2v7TvaN/TfqD9UHtN+990v/TP2k+1n2m/0P5F+5X2b9pvtN9qv9f+oP1J69clXdPv0V36aP1ePU/364Ye1Av0+/UH9Af1h/SH9age1/9Of4v+qD5Hn6fP1xc6sh05Do9jrqPKUe1Y6KhxLHHUOeodyx0rHasdaxzrHOsdGxybHFsc2xw7HLscexx7HfscLY6DjkOONscRR7uzy3nK2eM84zzr7HWed15wXnJecV51XnNed95wJlyyS3elujwunyvfFXYVuopdX3B9yfUV19dc33C97PqW69uuV13fdX3P9X33U+457rnuKne1e4H7o+6X3J9wf8r9Gffn3J93f9H9ZfdXqf16lHH8FKCSp+TxExaKQbZQoBRQqz+gPEC940HlQaEpDysP/yd15wEWRbLv7equqaahp8cAxkUlKCqiDoiIYRUxsa4iCuaIiKwKgojZVcCcEBUUxYCuOSsGVFxzXNeIijmLWVcxrelW/8CRPt+ee875vnOe717noaypd7qnp7v+b1VXJx4jNWlNYkXjaByPlDF0DI+UcXQcsaET6ASi0El0Eo/VaXQaUel0Op2Y6CxeawrRZJpMCtO5dC4pQhfQBaQoXUwXE1u6jC4jdnQVXUWK0TV8P784XUfXkRJ0A91AStJNdBMpRbfSraQ03UF3kO/obrqb2NN9dB8pQw/RQ6QsPUaPkXL0d/o7caBn6BniSM/T88SJXqKXiDO9Rq9xv9yit0gFeo/eIy70IX1IKtLH9DGpRJ/Sp6QyfU6fE1f6B/2DVDEEGAKImyHIEESqMjfmRqox/iLVmZmZiZl5MA/izjyZJ/FgXsyL1OB9bm/iyeqxeqQm82E+xIs1Zo1JLd4T9yPerAVrQWqzABZA6rAgFkTq8v55B1KPdWFdyPesB+tB6rNerBdpwHvtPxEfFs7CSUPWn/UnviyKRZFGLJpFk8YshsWQJmwwG0ya8t79UNKMDWfDiR8byUaSH9goNoo0Z7EslvzI4lk8acHGsrGkJRvPxhN/vi8wkbRik9lkEsCmsqmkNUtgCaQNm8lmkkA2m80mQWwem0fasoVsIWnHlrAlpD1bzvcJOrD1bD3pyDazzaQT28a2kc5sJ9tJurBf2a+kK9vL9pJubD/bT7qzg+wg6cHj5ygJZifYCdKTnWanSQjLYlmkF98LySah7Cq7Snqzm+wmCWN32V3yE983eUD6sCfsCenLXrAXpB/LZbkknL1j70gE+8g+kv6S1sBHSgbJQKIkme/JDJCMkpFES4WlwmSgZCfZEe0+RGXJIMlBciCDJSfJiQyRykvlyVDJRXIhw6RKUiUyXHKVXMkIyU1yIyOlalI18rNklsxklOQpeZLRkpfkRWKlOlIdEifVk+qReKm+VJ+MkTpKHclYqavUlYyTgqVgMl4Kk8LIBKWEUoJMVEoppcgkpYxShkxWOiudyRSlu9KdTFVClBAyTQlTwkiC0k/pR6YrkUokSVQGKgPJDGWIMoTMVEYoI8gsZbQymiQpY5QxJFkZp4wjs5VJyiQyR5mmTCMpygxlBpmrJCvJZJ4yV5lLUpUFygIyX1msLCYLlGXKMrJQWaWsIouUdco6kqZsUjaRxcpWZStZouxQdpBflN3KbrJU2afsI8uUA8oBslw5pBwiK4znjOfISuNF40WyynjFeIWsNt4w3iBrjLeMt8ha4z3jPbLOmGPMIeuND40PyQbjU+NTstH4h/EPssn42viabDa+Nb4l6cb3xvdki/GD8QPZavxk/ES2qYIqkO0qUxnJUK1Va7JD/U79juxUy6nlyC7VWXUmmWpFtSLZrVZRq5Bf1epqdbJHTVKTyF41RU0h+9T56nyyX01T08gBdam6lBxUV6orySF1rbqWHFY3qhvJEXWLuoUcVTPUDHJM3anuJMfVTDWT/GYKMgWRE6aOpo7kd1NnU2dy0tTd1J2cMoWYQshpU6gplJwxDTcNJ2dNo0yjyDnTWNNYkmWaaJpIzpummqaSC6ZEUyK5aJppmkmyTbNNs8kl0zzTPHLZtNC0kFzhLZ0bmUWdqAt1pWbqSXPpVL4/nkLn0zS6lK6kW2gGzaR76UF6lJ6gp2kWzaZX6U16lz7g7dkTmmsINLRndVkD1og1Yz+yQNaKtWedWXcWwsJYPzaDJbO5bAFbzFaxTWwr28F283m4sCPsN3aKnWMX2RV2g91hOewxe85esbfsA/tCH0gKdZJspVKSh9RF6iH1Usoq3ZSeSm+lr9JfiVYGK8OVUcpEZaqSqCQpKcp8JU1ZqqxU1ioblS1KhpKp7FWOGi8YLxuvG+8anxhfGHO1VCWqQZVVo1pWdVJdVFe1muqhzlFT1UXqL+oKdY26QU1Xt5vam7qZepp+NsWZJpimmKabkk1zTQtMi3m7MgstCkGLIqBFEdGWULQlBrQlDG2GhNbCCu2EjHbCGu2EDdoJBe2EEe2BivbAhPagENqDwmgPiqA9KIr2wBbtgR3ag2JoD4qjPSiB9qAk2oNSaA9Koz34Du2BPdqAMmgDyqINKAe/O8DvjvC7E/zuDL+Xh98rwO8u8HtF+L0S/F4ZfneF36vA724wb1WYtxrMWx3mNcO87nCuB5xbA871hHNrwrlesG0t2NYbtq0N29aBbevCtvVg2+9h2/qwbQPY1ge2bQjb+sK2jWDbxrBtE9i2KWzbDLb1g2d/gGebw7M/os/XAsZsCSf6w4mt4MQAGLA1DNgGBgyEAYNgwLYwYDsYsD0M2AEG7AgDdoL1OsN6XWC9rrBeN1ivO6zXA9YLhvV6wnohsF4vWC8U1usN64XBej/Ben1gur4wXT+YLhymi4Dj+sNrkfBaFLw2AC6LhssGwmUxcNkguGwwXDYELhsKlw2Dy4bDZSPgspFw2c9w2Si4bDRcFguXxcFl8XDZGLhsLFw2Di4bD3NNgLMmwlmT4KnJ8NQUeGoqPDUNnkqAoabDUIkw1AwYaiY3VD2SSh1pBVqZVqc16Cs6hc6gc2gqXUR/oStoOt1Od9E99AA9Qn+jp+g5epFeoTfoHZqjRYGhDX1laGNoR6ewOqw+82VNWXPWhvmzdqwT68Z6st6sL0tkSSyFzWdpvLewkm1kW1gGy+TTnKMV2GF2nJ1kZ9kFdpldZ7fZffaIPWMv2Rv2J/tMc1gdyYY6SkWlkpIH8+W5zlJ3KYSdVb5TuirBSqjSR4lQBiiDlGHKz8oEZYoyXZmlzFFSlUXKL8oKZY2yQUlXtiu7lD3KEeN54yXjNeMd42Pjc+MrpF9UqlqpilpGdVQrqJXVqqq7Oludpy5Ul6jL1dXqenWzus3UztTVFGwaievdJ5sSTEmmFNN8k/aM3NT/ZcbS+q5l4K2y8FY5eMsBvVNH2MsJ9nKGvcrDXhVgLxfYqyLsVQn2qgx7ucJeVWAvN9irKuxVDfaqDnuZYS932MsD9qqBfqMnHFYTDvOCw2rBYd5wWG30G+vAZHVhsnow2fcwWX2YrAFM5gOTNYTJfGGyRjBZY5isCUzWFCZrBpP5wWQ/wGTNYbIfYbIW6De2hM/84bNW8FkAfNYaPmuDvl8g+n5BcFtbuK0d3NYe/b0OMFxHGK4TDNcZhusCw3WF4brBcN1huB4wXDAM1xOGC4HhesFwoTBcbxguDIb7CYbrA8P1heH6wXDhMFwEDNcfhouE4aJguAEwXDQMNxCGi4HhBsFwg2G4ITDcUBhuGAw3HIYbAcONhOF+huFGwXCjYbhYGC4OhouH4cbAcGNhuHEw3HgYbgIMNxGGmwTDTYbhpsBwU2G4aTBcAgw3HYZLhOFmwHAzYbhZMFwSDJcMw82G4ebAcCkw3FwYbh6P0rLEqI1Q5I3LqNek4vSReke9od5S7xLtqbLaqAWGXHj0amM1FGM1BkQRo4/oIyKhBlhJvaXeRMa6tsa6tsFya+epuWA8Tht7KkpH86mmcUfe5NNa8pI2liPwPV3tuenadaNRZD85QS6Qm+QRySWfBVkoKtgTG1Kc2BMnUolUI56kDvEhTUkL+povWTx9y9Ox9D1PJ9IPPE2Q4nhaVupDRFZV6sfT6lIET91VlYjG+2ohnj74O3N8gzm+wxz/xBw/Yo7xmGNfzDEcc+yPOZowx8KYo0AMUqT2aeSiLLkBlly0JTfQkoux5AZZcoO/5owtLLmWyPE1qa01Qnhr8JwvwUv2ihh4q/CWSLxl+MC3wh5lL65KroMxqPJY94X5+jZY1rwhf71rxKR48O3Ky/P+x9YQtS1DtOeGa3PQjrQYlBp8qlc0gVsUUxk35n0673+KZ33SdXwqiiObrsRMvPKfR07yy76u7byxNldsdTw5nS5Fehfp6v/x9yDUfk0h0o50IT1JX15b+5LBPD+SxPPcZJLI89oz5+bn/+5CeFKdN2qXD2nB821IB57rQXrzfHj+2qiC374L6U2sSy/6AqPWFGWjkf6GNBf8UX7cPEWajvT2/4p1Z4e1ph1ZGcv/JvN8Il9jo8hCspSszs9t5KXa+fuZ+WvRDrXJlzQnAfyvHc9ra795/pzyciN5aXz++nT7f1yfcUhv/K9bt1b568mL+BF/EsSXvFP+GrTKjz77fNvlraeq+G2LkF4vsH4+Fvj9j/7H//K857vjqI+YQ0RROy6mXYmtnRnwrZyKDy0k76nw2nGhIKyHavkl9fhvnUgSdGWVeFkMWa8r0+440EM7Nwtl2jw3k7znsFvuNoCr8m1wVb6Cq/KNuCpfxVX5JlyVb4ur8u1wVX4x3HMAdRD3g/q/uapfkO8jzdKObYiZ2tUAlP96asJyVteacnE5f2lXcb3kf+8KlCdQk6id+6+dn3zTUm4QB/PXG1G70kA7G/qohWjXqQva9RjiI0uZKPqJp3F+p3aV57dP7uR/o3iNIaJHgc/ai0txhpsoPhLtC3xaOzM7gC/RWTFbvP7t88ITUbsSzZuTneJe7UoKyxTalURleXka/22dCkyxU9TO+5Y4mSgmaHnLFLG8t6GthWoFysJ5WTZfmk7C1AKl7bSrJfgcGovNhc8FyrXrUVbzcjfRQ/Qu8J1NRd7jEbTzl7MKlJrFwkS7LlYUPgvmAuUlBb4NhF6ECveFJ0LaN8L7Pfy3C805OSGc5cv1bZrjAl/H2lwEr2/bT9girBT4eha0a0scCpQnCvMF7Son7coQ+Vs5WSiMFbSzA7St9+Lb9ibjyXghXDurnWjnJmQXIOFCG6Gp0IFoT5UUcD1yHmG8RWsjeAtugnZ8TbuXwtICU3kJhQV7QTviHM//JhaYyp6/3ggiluon/tc/n+XFEa/7uBOQivs2mnDnh0JWGVYZpDCPiYekCOq+GXXfHbHjoT5SH5EauOeDJ+II0S6f+5fvEiOKKfybv0aijbjYMm0ZPu0F4sJr5m1iFu/y+dSVhkhDSAPMzQdza4i5+WJuzS0m0u7fkHevR54qOCKdd98JcUfeUWoZfSH+mwRYANbi8zRwa63SIopod3QQeL+J4j4WDuiVVdLuPYNcZUvOFTm+vXmdT4StzJimJO8L5k2jmfDrVN/yrvn5AlNqNYoviRffNjFkOInltWMqmUlS8tvqjbyNzuS99aPkJMkil3mP/T55Ql6Sd7z2GgQbvuWLa9teqCRUEzyFOoIPrz8teC3qIHQTegl9hShhsDBSiBcmCglCkjBPSBOWC2vFaXhqPO/p8qWYztPpfFlEMVF7gh7u7iKKM8VZPJ3F14ooJnHjimKytqXE2dy7IrdvCrbgXG098O0oiqm8BomGJF6DRGkor0GiVQa3qsjr0Qk8cfl3nv4un+TpSdxv6hRse1o+g3tPneXpWa0Wyee4WfPujqO5+AJPL8gXeXpR5t6Qs+VLPL2kPWtYvixf4ekV+SpPr8q8zyxfk6/z9Lp8g6c3uMFF+aZ8i6faPUtE+Tbf+iJ3Ot/vwv1LRPme9vxJ+b72jG3c50qUH/BaL8oPeQ0Red1vxdNWvNaLSmte60Ve9/neAOq+qKKnw2sizT8rUEAfnhBzfgv/74qw0uTrvp1RCeBr9bOWig9RVzcSwbSeu6Qo90JToYcwnG/h9cJR4bbwUSwumsXmYi9xFN9Km8UT4n0upNLUk/rTn/i+13y6jZ6mjwwG3p/wNrQxhBvGG9IMOw1ZhmdMZto4TDsWxSazpexXls1eSkbJRfKROkkxUoK0UtovXZXeWBW2crVqbNXNaqjVTKu1Voetblr9KdvJ1WQ/uac8Up4tb5SP8/X82bqktYd1C+ve1rHW86y3WJ+0fmAj2tjbeNkE2PS1GWuz0CbD5qzNE0VSHJQ6vJ/SX5moLFEylQvKC6ONsbyxvrGDMdo41bjcuNd42ZirmtRKqq/aRR2sJqqr1YPqdfWdqajJzdTU1IPvo2t3JJKJidhpNdzqM+r5Q6QPLCQBJAEkQUemg0wHma4jiSCJIIk6MgNkBsgMHZkJMhNkpo7MApkFMktHkkCSQJJ0JBkkGSRZR2aDzAaZrSNzQOaAzNGRFJAUkBQdmQsyF2SujqSCpIKk6kgaSBpImo4sBlkMslhHloAsAVmiI7+A/ALyi44sBVkKslRHloEsA1mmI8tBloMs15EVICtAVujISpCVICt1ZBXIKpBVOrIaZDXIah1ZA7IGZI2OrAVZC7JWR9aBrANZpyPrQdaDrNeRDSAbQDboyEaQjSAbdWQTyCaQTTqyGWQzyGYdSQdJB0nXkS0gW0C26MhWkK0gW3VkG8g2kG06sh1kO8h2HckAyQDJ0JEdIDtAdujITpCdIDt1ZBfILpBdOpIJkgmSqSO7QXaD7NaR/SD7QfbryAGQAyAHdOQgyEGQgzpyCOQQyCEdOQxyGOSwjhwBOQJyREeOghwFOaojx0COgRzTkeMgx0GO68jvIL+D/K4jJ0FOgpzUkVMgp0BO6chpkNMgp3XkDMgZkDM6chbkLMhZHTkHcg7knI5kgWSBZOnIeZDzIOd15ALIBZALOnIR5CLIRR3JBskGydaRSyCXQC7pyGWQyyCXdeQKyBWQKzpyFeQqyFUduQZyDeSajlwHuQ5yXUdugNwAuaEjN0FugtzUkVsgt0Bu6chtkNsgt3XkDsgdkDs6chfkLshdHbkHcg/kno7cB7kPcl9HckByQHIKEgNaWgNaWoOupdV6sFaftVR8iPQbGQ4yHGR4QYL+7mcrGMlKZyStD2z1WUvFh0i/kRMgJ0BO6AgiS0ZkybrIkhFZMiJL1kWWjMiSEVmyLrJkRJaMyJJ1kSUjsmRElqyLLBmRJSOyZF1kyYgsGZEl6yJLRmTJiCxZF1kyIktGZMm6yJIRWTIiS9ZFlozIkhFZsi6yZESWjMiSdZElI7JkRJasiywZkSUjsmRdZMmILBmRJesiS0ZkyYgsWRdZMiJLRmTJusiSEVkyIkvWRZaMyJIRWbIusmRElozIknWRJSOyZESWrIssGZElI7JkXWTJiCwZkSXrIktGZMmILFkXWTIiS0ZkybrIkhFZMiJL1kWWjMiSEVmyLrK0/ShOHoA80JGHIA9BHhYkfD+KEy0VHyK1EKUc9nnKaQTpN+IA4gDioCOOII4gjjriBOIE4qQjziDOIM46Uh6kPEh5HakAUgGkgo64gLiAuOhIS5CWIC11pBVIK5BWOtIapDVI64JE2yu1+qyl4kOk38hjkMcgj3XkCcgTkCc68hTkKchTHXkG8gzkmY48B3kO8lxHXoC8AHkBIpLCBfeJMV5kwpiPG8aLamIvOQB7ya0x2tMG+8qB2FcOwsjPQIz8xGC/eST2m3/GfvMovt/8gmjHHJYQlTgQV773XJ/4kTaki+5pbNo4NUY/kMMICHIYBUEOIyHIYTQEOYyIIIdREeQwMoIcRkeQwwgJchglwZiPPxExFmXIG0nIv4/uHEIUf16uYOm1u+10IsWJB6lH/EkPEq17dtxRcpZcJffJC/KnYBSKCw6Cq+CHb9Fah5S80QH0tFLQZqbml2jtQAq2/teS0yh5UqDkDEqeokSb41nMUcuds+SyLLnzltyFAt98Ed98zzKPbMunLllyly25K5bc1QLzuIZ53LfM47rlUzcsuZvI5dWv4uhrpPDeKhUX8P+P8/8XWuZ2G7/q2dffqY1a81q3ku9lWYnr+X6TUdzI93dUMZ3vpxQSt/E9giLk67FY+/x5aH3nBegnL8wvOYaS4yjRRjB38GUoeFzkTv7W18YhMd6Y945vZW2USBS9RR9e1hTjRO75ZeVFN55G54/afy01icX57+nCX/YFy4U3wmf+PY3xMujIVUHb8t3EXrrSw8JJPh870U/015WvF7YRg/BR+CiaRS8dSRLmEybc1l5i8b/59qFCLNHuzVuwrJcQztPNwkddqb/QjlBhPn/d15V7CfX5947F66SO2AvcrcJCjIZ+K5UEE08nCqsLlmpXA/K51xeihQRduXatIBVchE54VtO3cu1KQoNg4i9foZuOaNebGUguyRUqCc11ZCpJIoxc1l58Olcd065WZORXvF4KdjoWRLTrBD/ryrQrHbWlfqQrdSUeluMIX8u06ydFclgw5pdqtWytmP1vGie3HPGCZwV4VoRhKTfsA24ozapOsKozRiDL54+ta1f95DlLsxWOg3H3CLhPh4A7HXw9CvBvOq7A+xQU60OLxm9nNHjg26Yh3ZY/AqvlZ+hHSrHnPQ172cngWv3xyr9C1QVHEw24mzw+jZYqg7de2sitIW9kl///HJzmP9Mqw2oHXyqt36ItlwNRjXuN+4z7jQeMB42HjIeNR4xHjceMx42/GU/8H9dICWQUKcTX5dczNnzzjxx3whkK4dz2fDuYAsX3SP9E+gHpR6SfkH5G+kVLtbOFeCogFZHaIFWQGrVUGo009u9eU2U5AqIWJQa6lN7V7iGZf75IFJhm2krET7UlhehN+oJQOpr//cbzufQRzz2l6Tx/O597/StcKv6Nk6/nESRYvtWDdFHtiN3f+dY4ekM3/7xP/tX3/xOfzF8S/sm/XCZ7y1oqRqzodf6JRfQj5pp3VD/P84fJ1+PT2lGmW5ZokL/WUKId8y+L9sUObcVBS0/hUH7ua6R/a0++9j+0eRCSdx1/3pX8pMwCnLGBf2WSzfFlZkjWruP9xr9VBSsxLb5MPC8aJQqCu2K2llgVExVLM2IOlmyqSIJBiK8lCoa0QHNrs1uBEvslZWPtefXUXq1ITzKQRPLKGUpi+F997WV2LDAzg12lLycNfXbkOpbqffX+k6by9w7zuoenxZcMNMcb9pvj6eo0KgqiaFuDL+KOzEL+7e/0DvXGAu8wq5alFRhfriFYTNrWINmKbQPdbc1FtDeyrU374IE/9ekfFhPZ372w2aQVWtlatQntFRHZv5d7WbO9VmJjW6xln5DoyIGRvWMcGkVGR0VGB8f04VM4mstpnNqW/MaD+kSEVg2MCY6Icgho1NBctoTq7mWuba7lXqumt6dXJ/7Wu8Bbc9zm/8iSGc02GldsacNWjdwrmivkvSvbv1GfqJ9Cox0aBzZxaBLoX8fLt6lXVY/GNT2q1vZo5O5eweyc94Ps//IHBYZGD+4TEmqOF5wKrmCBERovFCK83EaMFwSyoEuNOrUKibOWLH3pf7zr+oWjrxXb/YetuNJq3qWGoelVrizytK98Z1jz5PnHI3rkvPN78bvpux+eWtWqV7lOyYWTPn1wm78h7EtMsfnWE5mTemRNVu01hR2KVh+9e17JT3uPNJp6pGUt+1plF5aqmHPf+mqcsfy+abnKg0PzWv766s2gJbeCnG5t2/WyXkKpiF73J3dRG56tW6l/ku8++/aFgt+Nvu6z7nDA8B4JPoWdxHuHLg0u1eLZscIjDgzPdNz/ZuZwp+4ukxY+/9hrUpzQ4suIC57jjkzo6jZlf8TLQtttnT+1dIrd7umSUf70lpT4tzcnTp8333/ztirzq6s5K+KuFV/d1rtyg4az6J/ZMwbsE7k4hV/iBWu+Rpi5DF+lZUyG4ga7wjU/rsoNSO3WoVnV5icv3txeZF+Z96hCZZwNJc3FY+2cPd9datM0yuapz4fBH9KrbDxQM72QOUj7QDlDS/OP5h/SmqU1Gd/op5iYqDrVq4dEh1eL+LqdqoVERlSP6tdHK60eFR3Za1BIzMDqls2obUVsRF4pq/GPmDtIMo9LxqwEwdDC3Nzs9/W9WRxfL/8LhgwZ8ldfEBr938w5xmyrLW8Fg1YF82dJ5b+JR6rVktaTT+xNPSzsjS09IrtDmlPJ4bWHPcu9tvN11O37w/zrhZ+ft8CYbDVjVO7F/iUdUprdfPnpZOIpH2L/6EblpBap58/3rnfmTIUiMzM9uzHpz7alo/ekZsz9fvPExHbrfmji2Pa3us41ve06Fms2dsrzBqezS0Ya1s3OObPH97sJd9f3OfVu3faOl2s8eFVzeu0pdRdUL/26TqcAv7anb8baFO88uV7fSVNDS/RICW/+/QGftsW6Pkq9dGr34QW1pts2Xj9k5MmAV0rakFGm9M6RI/z3pvjKvm7Zd6o3chlB1xT9NClw081m9yYsqtOg7vu5PZskbhg3c7Rv+94j1TPOM92y49PvzN2yPDSrxpWKU9dVfmiOl3jI0AcFLHbAlLoie/PVt26w2IGCa03hFhv1H3FFJbNLXtCXK8h7hToE9gnrz+eqeczBw+zuDpnVMnu7u3uY+cszT2bf3ppj/iPLl8/p3+H/0Ea72l/0PrNJGv1D1VUR6SGLhu/cVsex85aU9dOylsalHRp0yO15vI/r9rjAIa9CBJvMk7XGUp9G7eN/PPm03LZPsRHH9s/oyo5cbdeR3DI+bn/90x8ZiRX3DGr+cdDm6A7bDvml1ujJziQnLdtT22ndtKItm/a87FHq5GqnLu38NkU2ORY2uGdX88Rfqlc6VC7A9dL4K6WLVIjbn/s6rFrOsDKvb9sPyvU/ceRjzh4ltlnlL6d+77PJqPR4HHZ/7HepLT9FNKtz5NK+4OCXyUUXq1brQxyzc+fafxnaNu7ZsmEPHOK721zeGlgqSGivTpgxbf/IP4LGx97qeSV+YH2Xbi98ip6tfd6FquMmune3UaZ8tdFovkZG5OmmgqYbS8PcQhYskUoL6GqFbddyjpPaPqDPFpbwevQyaGLNUhvMrTVcxMCFsbSpufHfNDSeZg/tHbOt4lHDbHb3qBLibfbsWTM0uKpn7Z6eVT09anhX9a7h5VG1l3dN997BHh41PXuH6Azo17/XvQB2Ln51iVq1nLZGrDw+SEz++wb8S0FFRg2EBHlt4dWYV2Jef7Xq211LqpprVTV7w4DBBQzY1sz7KgUM2OQffsFXCf43XxFjNmoLbisIXwyimfxNNNN4USAt57TyHPVH1Kz5d86X/nF+kVH9XA4uK597o3FW+Z3pfeVJc+f95p4TlfrFrsxGq9qj75rr2jpdNx1NDtvVf9S7kclLE+NrzVo+5twP4r616zo+n7F9RW9iWtKiQtbVnK5W4vFKnqF1a49Zl+yacDztgVzH/nP9ET4/JLVMCKpgc2/TEZtnA2odTu3m9XqFb+MPmRM2qntrXnKZ0P1L2PNKMW8nmw1FJoed+LFmj76OOQemWY3plrpmwYBylV2si2S9jj931suq8voHMyMSR5NjKzs/O20I/bDY1D7wxMuUSa8WFZt1VDoY0iZYbNXez/71h0FFj299n7u/T/ddixeofcZUfDymfpl+7geemf44OLbRhGfu8yXiMXK7w+QdsvOjdhtLZm3eXexJrae9zvUrJjofnlxjQp0zqdv2zu7oliYEjhW6vxyxb/jGJ1nZbd50HxTXuGNx74qBuwJedRtw4+3F1lfdz5cOqek6Z9Si3rW6n2pb4/nm45luzqsbl332IcxvywPfA4Umt+6wpKkY7NKp1J4uSQ9X+kTldDa3GBmbFRC2ZNkz0+Pvt/5xb1jZW687lIrcNSli6G2HDhW+3PVLv7/hj80+hhJNA7KM4TPsfn52/PYbl+vf1TWEta5WaGmJt75fGsyY5P5uRWb6vTptrrrWGN2814zQ7NAi26703b4lvM3HPVMGFD/odnLgvLSHXeV9TZosqzz+ieAe0S3mcDuuy3jJircBz/PaAJvg4j95Qv32f9uB7Q6b2ljPdJk066VbL6FUccpro3spcwldobWlsvJqWCVPm+W/abNNZCR3J6+6fXr3CQmOCXVoOCjmp8joPjHDNLeba5k9zTXcPWrWMNfmbvdwx9saZu3t/78e9D/S+6LF4ZtuXPGb6TqyX7VSt3bfvnNobmvngHUnr5X0L1/o2ZkVZ1qsizE7FHlsdT4oudgPSd/5zlyf0sXscpn0ezBi95NJVoXemgwpLyadKPdbjfITFrzMDbN3+zgiZ2KZRzn+vyze5xx4fNqfTU5Zn+624fRGX8OS98vDZ4VdrHS1aeDG8afvVWpareLa8a3atjHepW4f+iYmmvtPeNXRvODPURfmpD9wnDPq3VnbV/L2wIg2W5okLvIjzZv1LlKxcu+Vc+6ek+KaL3k/dkWRZnbW8YvGPm079LMwr0yAPI4UNjd9uv26c9NdB6sGLdpQdmhD9yEnUm/UHTNrcbC4tYy66ePb1M3CSacfg768Zwf2Oyhf9b6Gr5EV5kIW4zAz5f8V0Plfdi4VDRcyGHj9G28uLFnnNwnFBK2EmONS8twcl2iOmxZrZ1ob38OnXcU59yrYfnS9ZROY3PHu0sUhS4P/49UzvvCwdcUXN09btq7FwA65VrbVQs0BeY3CD+Zm5iZpjdIajm/wz3eLLTiaf6OmcjQIQQUaBD8zb90KNAje/0qXWPsdjfLm+k92h/m6Ljxn8oEutLHXtYdb1g25cnJY65bCpmoxAzpHGG3XnPx1xPSMallFl0yN6JnRXvzN38E2YO614T632+/a0GGe/a0ywvi1u4a+nHL6SV3h2e1fp9uwo9P8br8ILHat1ZqZd3Om9T0fu+9+0kup+jj6cIZreaeoD28+3h06t5r61up2VGZJ/wUJ/WyikzMW154fVvVQa9Ojnl0aFE+Z4tDgtlVpj/cn3JsPdv++SrRy9FHU91/G2dje2G8TnPDiYkaJx/5TRh+qWaXbL3seZ/6s+I7ICox2fGY+vmtoaJfOQgkbO9PZy3Ypr+vt6N0hvWr1nPfjxp9o3e7Bgqik8LW1W2S9GbZndcnhPSs/X5Ja2VMaUrrnse/LRpSLf6Eccdt1qlH6vfdPft56Z+nKmJoZ/ocGOBd1GazUazN1QKemjewy09M3tgw7usj3S+wwx9iFxcy9H/gW7Vb66EInx9ONHlZ5uCvX74RbVrZHbAsXV7/y3Ts9avd8+fW5C47XidwdVzFGKvJssOOe1Ph9FYO2ber7/aTFg4O39F9su3zP6mYvikZ+muwRvvnzjdZHpzr/V3FnHg9Vv8fxMdaQSCT7bohxZiLk2peaR5aQfYixDLKEiZnyZIYsbZasETM0lofsImVLKpQsYXq69sSIyPAkVHfoPrjVvfe5f9xXf5zX6/x+5/U76/fze5/P9/s6r9Pu2XBTJGavO1hLqcw+vu61xGRNeQeqOsya+YUe1KIkuZwcVlxFTMUIvkyK4cVIKsML2fyJjldkmojzUR0SA29FzdtvvEOMfmDwCIjjCH/i/eSN/0xBWhdM/gtXm6MTxVSIRFlVztaBnuT3befN+wQQWHEAgdntTxRwJfRuooDxWxeAj/2/TMVwAPgqSPm/IshtQwCjY0MdDqhqfIXG4c0mDNho/nTDQgB/zw7wBjvAdHbQNVe8sBrELQy9TfH/jcBtqlK/eMdOIkdfSMGX6mDxWx2LuiATov5CK6fokJrvo70UjgX1Bxks5U80+hn2wfT74nZj3WN+TT4lfbosG5FFRTv3jmRaVbIrtpa9LDpYittVNphq33FKkJnqeXYabim7V3mqmM3ieZVhLZLyEMqIKUbTOv1oR5xI/EvG9aPq7iX+7qph+UTUHqU+3esrE8Osu/udsGSE/NTuRiJvaGOy1vzaxEEHbjFTG0guLmh075FahDNlbs4gMfLlucpz0UIvtSuuIKfjzKMEF0nK9q8TNJVKD9m11Wp/hvdVMWpVVJYlqf/aezNCcdnMJlFCVaZVw9/9glV91p7bB6SiOpfqGaOvfnBZ6LZsupIcc79ZIkTGRQBy56kcRF0mXeOXw8/PVySVCksVFHnOuor5jEEQN11ix2WQfRIm2pYPa2x1pBkXenCOyv1SE4HIPSeMQ6tWQGP3S8AEl1fNfFUNQi9OmkxpkPZQpRD3BeoMzxu9bmkNwo0GTUmPNBlntM0/ELZ9FXl11hQBFBRfG5l1zClbHyr3HG9Jw5+bG5gzmULIF/BC8gvCvSLeXHILc6lUjhq0zXJqCoVA3s/5tULiFeN11cxbxi4axj3cdbztBdlAOSTlg/9KmLidIi/yVMoNbfNDUb+Xx+4fzjZbSi2/b0w8nd47OhB7ZYudc3R2Un+Av214/tCXHNgasA/MxCnKDrICYUBuIAOQ3r9y9Tso73Q8QUpHwLAEg7v7mM3GZgoew3qk4lQAh69w20igmhNNiSbRiP8p50PXLV21dLFumRIX4JALHL6JOecdmLMELACzHZjT/2uY+w/7DwHwORsnL86ETwPwyQA+cesmQRkBfCSg8+fhwAz8h/6bzXIPQAXTr8zbzzUIiwoMhqJD/ADdrR2AARVRuLgI6DjIA+QFcgWdBrmAAjdzyt4gFAhLbwWDQuj9G/llP/qy8QEEVFzkR0bMazGanD5qjRWE9lFCvCQzOVJ5xlBJGfqp4b1YzoQWDxeoovZKa1CPX+TnRp1p9g7NpqNFeTTvV6gmSVVyGtIjKiH8srHFSQpn0vleQRNh2t/0L1t2l3/yndBmhcpnvtESIr+oEQlN1hinurcbaoXhpGi84fkJIZFXlzplwcYKDy5x37tVxMyZOYdeRUNTiAo6Cr52CJTYLm9/h/TU15FLzfE044PD65rdDarz/jKlk2Vyc91DNK6yDEhauimXFsciW9yAWCtcYHyhTanLMbsaocH+iP3Bo9ulk5UvX/HFnjCyU4efkRO8ULEktzKseETcO73SPg7tH1BQG9Kqy8ySz6AA0Sbo8Jp6cjRXmS6PxV8QDuALNyo4O6mr4JHXirR0i24VQR1Oix75nbayyE+6ITf2jJzW/Q6J0ptwZM2K0WYJZelhqcCI7Wt0da1Z+PsjIabGEb3HXJB3wx7Ks2l/kJxSKaABknGDPS2NvMvkGHdGhFg3SL6tIpOsYxQqqvqoNzc3B4eTXD2WIla8dlQqYjl7pcm31iRt/C0mTHB2Ri0DK2DyZaBKCo15U7a6fvktR8SMt2bZOjDHdPzayAjGD5Wo1XPTxsy8KcJWkhTGA5fAzeuxV+isFT69hWwhxWbanrExO2bUrN+eedaRPeKY7ydsTkuDn59Pu2Uw726cxTMYgakcIDCVgBkYAHzKzwbXj7OB26URIv7hxuTzzyDexQjj3Fl3oZ/FdosDxgXs3MoHSG0PZILRp7Y8XHPB1aRh5nkXO1w9Y3uUnM2nQcB9xxBOmA1gTVSIgIBMN4UVRJfYRunGky4ncZA1XWgbovOi97vS19AgLEk2QvrfKtsaGxjgFeQaiMaKf8NmJgIDyM38me+ntK4+sr5PIzWX1PFGFCoyyGdQmOh1EQWNjz5zlIm5UbnT0LnQ6mS/QxcG7W4tWS98jR/yWd300NEetydFqzO25IPvDSap2kY6zxFeLkj8WvS4eQUcRGW7XH3xFA4wO2ZvLXJpVBIvX6vWdU9EzsrANcV18VZvCHZwvTZMC3kZ618UVCPbNvSgkRYY6r9+AiPBNTKQRZaTwKhWC3fdiHB8S7t4K3zojHH+Whi3wSvjZAk29BT+2aT0fKAxMTv0nlHb/v0HcX1WKx4WXNTcZcqZ5lkuwImI19QxbAhlGrt+ndu2JCaboe7jiU4Wks/0sobcuSvHQ1Onr6kL/LFEIoAh9NcT6e1nxAIjgPnoXTyboXntpxnxH9fZdsQkEhDYGZIc2/VCBvrBt7Yww/ZspJFhMJgKoKKiAlNx+C4iTUEXB1FLCg8Xf7lrMGc5tTrqDpb7xjJtxIoqtQfDE95fJyMOVnxc7QVP9u4i4OKExJTKeGQXC4XYSt7XITrvu+OXbRdhn3PG4JgefhmvvJqKE/RZslh/cTKY4dem0+5jydgZq/ckVG62eWiS2j5bZ+HA/gvTlC+jNd65p0rdUuwcSlmprAc614PvDIRnsTVnXpVtzzvyVsHLhAwO063sbjGJRlcWaQ9wB+jlBa8GfWRYquUyf+rckG/I71Iy0WD/Aumz1sR6QO22cviTxpQbdZTseR6Shr5ebUI6YbemM8bA1yf3LlTOLLyz+mnBSPq7qI66s4dPp+93TP0oEB7qmkWFMtOc1BqMEyFydhNSvVMd/oUDEapDuhUbvwH5ByA1g2MNCmVuZHN0cmVhbQ0KZW5kb2JqDQoyNSAwIG9iag0KWyAwWyA2MDBdICAzWyA2MDBdICAxN1sgNjAwIDYwMCA2MDBdICAyMVsgNjAwXSAgMjNbIDYwMF0gIDI1WyA2MDBdICAyN1sgNjAwXSAgMjlbIDYwMCA2MDBdICAzN1sgNjAwXSAgNTVbIDYwMF0gIDY4WyA2MDAgNjAwIDYwMCA2MDAgNjAwIDYwMF0gIDc1WyA2MDAgNjAwIDYwMF0gIDc5WyA2MDAgNjAwIDYwMCA2MDAgNjAwXSAgODVbIDYwMCA2MDAgNjAwIDYwMF0gIDExMlsgNjAwXSAgMTcyWyA2MDBdICAxODJbIDYwMF0gXSANCmVuZG9iag0KMjYgMCBvYmoNClsgNjAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgNjAwIDYwMCA2MDAgMCA2MDAgMCA2MDAgMCA2MDAgMCA2MDAgMCA2MDAgNjAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDYwMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCA2MDAgMCA2MDAgNjAwIDYwMCAwIDAgNjAwIDYwMCAwIDAgNjAwIDYwMCA2MDAgNjAwIDYwMCAwIDYwMCA2MDAgNjAwIDYwMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgNjAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgNjAwXSANCmVuZG9iag0KMjcgMCBvYmoNCjw8L1R5cGUvWFJlZi9TaXplIDI3L1dbIDEgNCAyXSAvUm9vdCAxIDAgUi9JbmZvIDE0IDAgUi9JRFs8RjM4MTE3MEM4MDk3NkE0RTlERjgzMjc1RDk4MTJERTQ+PEYzODExNzBDODA5NzZBNEU5REY4MzI3NUQ5ODEyREU0Pl0gL0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTA0Pj4NCnN0cmVhbQ0KeJw1zD0OQFAQBOB5PD+hItGq9ELlCC6FC7iOU6g5hwNInmeGLfbLJLsD+HHO+F0AL5PYiNlJuBJbiU4cJKpJXIpRzCRpSdoAge+sEAorIhGI7yR+H64/GZ+yhS35TY6enAPwAMFkDJkNCmVuZHN0cmVhbQ0KZW5kb2JqDQp4cmVmDQowIDI4DQowMDAwMDAwMDE1IDY1NTM1IGYNCjAwMDAwMDAwMTcgMDAwMDAgbg0KMDAwMDAwMDEyNSAwMDAwMCBuDQowMDAwMDAwMTgxIDAwMDAwIG4NCjAwMDAwMDA0NTkgMDAwMDAgbg0KMDAwMDAwMDkwOCAwMDAwMCBuDQowMDAwMDAxMDQ1IDAwMDAwIG4NCjAwMDAwMDEwNzMgMDAwMDAgbg0KMDAwMDAwMTIzNyAwMDAwMCBuDQowMDAwMDAxMzEwIDAwMDAwIG4NCjAwMDAwMDE1NTQgMDAwMDAgbg0KMDAwMDAwMTYwOCAwMDAwMCBuDQowMDAwMDAxNjYyIDAwMDAwIG4NCjAwMDAwMDE4MzkgMDAwMDAgbg0KMDAwMDAwMjA4NCAwMDAwMCBuDQowMDAwMDAwMDE2IDY1NTM1IGYNCjAwMDAwMDAwMTcgNjU1MzUgZg0KMDAwMDAwMDAxOCA2NTUzNSBmDQowMDAwMDAwMDE5IDY1NTM1IGYNCjAwMDAwMDAwMjAgNjU1MzUgZg0KMDAwMDAwMDAyMSA2NTUzNSBmDQowMDAwMDAwMDIyIDY1NTM1IGYNCjAwMDAwMDAwMDAgNjU1MzUgZg0KMDAwMDAwMjY4NyAwMDAwMCBuDQowMDAwMDAzMDY4IDAwMDAwIG4NCjAwMDAwNTQ1NzggMDAwMDAgbg0KMDAwMDA1NDg0MCAwMDAwMCBuDQowMDAwMDU1MzIzIDAwMDAwIG4NCnRyYWlsZXINCjw8L1NpemUgMjgvUm9vdCAxIDAgUi9JbmZvIDE0IDAgUi9JRFs8RjM4MTE3MEM4MDk3NkE0RTlERjgzMjc1RDk4MTJERTQ+PEYzODExNzBDODA5NzZBNEU5REY4MzI3NUQ5ODEyREU0Pl0gPj4NCnN0YXJ0eHJlZg0KNTU2MjgNCiUlRU9GDQp4cmVmDQowIDANCnRyYWlsZXINCjw8L1NpemUgMjgvUm9vdCAxIDAgUi9JbmZvIDE0IDAgUi9JRFs8RjM4MTE3MEM4MDk3NkE0RTlERjgzMjc1RDk4MTJERTQ+PEYzODExNzBDODA5NzZBNEU5REY4MzI3NUQ5ODEyREU0Pl0gL1ByZXYgNTU2MjgvWFJlZlN0bSA1NTMyMz4+DQpzdGFydHhyZWYNCjU2MzQ1DQolJUVPRg==",
              "title" : "bilanobj1.pdf"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIDocumentReference"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/DocumentReference/tddui-pp-pa-documentreference-entrant-example",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "tddui-pp-pa-documentreference-entrant-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_tddui-pp-pa-documentreference-entrant-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : RéférenceDocument tddui-pp-pa-documentreference-entrant-example</b></p><a name=\"tddui-pp-pa-documentreference-entrant-example\"> </a><a name=\"hctddui-pp-pa-documentreference-entrant-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-document-reference.html\">TDDUI DocumentReference</a></p></div><p><b>masterIdentifier</b>: 3480787529/123456789-PPER-entrant-1234</p><p><b>status</b>: Current</p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>author</b>: <a href=\"Organization-tddui-organization-example.html\">Organization Les Chênes Verts</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Language</b></td><td><b>Data</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>application/pdf</td><td>French</td><td>(données base64 - 81,144 caractères base64)</td><td>contexte-actuel-Jeanne-L.pdf</td></tr></table></blockquote></div>"
        },
        "masterIdentifier" : {
          "value" : "3480787529/123456789-PPER-entrant-1234"
        },
        "status" : "current",
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "author" : [
          {
            "reference" : "Organization/tddui-organization-example"
          }
        ],
        "content" : [
          {
            "attachment" : {
              "contentType" : "application/pdf",
              "language" : "fr",
              "data" : "JVBERi0xLjUNCiW1tbW1DQoxIDAgb2JqDQo8PC9UeXBlL0NhdGFsb2cvUGFnZXMgMiAwIFIvTGFuZyhlbi1VUykgL1N0cnVjdFRyZWVSb290IDE1IDAgUi9NYXJrSW5mbzw8L01hcmtlZCB0cnVlPj4+Pg0KZW5kb2JqDQoyIDAgb2JqDQo8PC9UeXBlL1BhZ2VzL0NvdW50IDEvS2lkc1sgMyAwIFJdID4+DQplbmRvYmoNCjMgMCBvYmoNCjw8L1R5cGUvUGFnZS9QYXJlbnQgMiAwIFIvUmVzb3VyY2VzPDwvRm9udDw8L0YxIDUgMCBSL0YyIDkgMCBSPj4vRXh0R1N0YXRlPDwvR1M3IDcgMCBSL0dTOCA4IDAgUj4+L1Byb2NTZXRbL1BERi9UZXh0L0ltYWdlQi9JbWFnZUMvSW1hZ2VJXSA+Pi9NZWRpYUJveFsgMCAwIDYxMiA3OTJdIC9Db250ZW50cyA0IDAgUi9Hcm91cDw8L1R5cGUvR3JvdXAvUy9UcmFuc3BhcmVuY3kvQ1MvRGV2aWNlUkdCPj4vVGFicy9TL1N0cnVjdFBhcmVudHMgMD4+DQplbmRvYmoNCjQgMCBvYmoNCjw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggODMzPj4NCnN0cmVhbQ0KeJy9V01v2kAQvSP5P+wRKrJ4beO1oygSAZqkUiqiovTQ9EDAEKtgUwxR+o/Dv+i8gaUoYEVVN+UwrNkdz9d7M4to9MTZWeOmfd0R7vm5uOi0xU+n4koXn1h5whUhSR17YpE4la8fROZULvpOpfFRCeXKZij6Y6ei6JwrlNBN6XqB0LQTR6I/o3OXX7SYFPROMeGnaPt06VS+Vdt57SSoZrW4ukxquvq8JJEIEoMhieUKj1MS4hSi9l30PzmVLpm/dSr/4qeKIhl4+36ye1uvXhkS3Zu2EHuZUn+ZKa88U2EcS/XagTPXjfS5tWAjJf2oxJTVpCpFMZXY6V6h0j2qdKuDWqK0iwdUOiWR1fHbGjUfkJgADGIOjQVp5IDFegIBbGQ5BFZjnFvMsCGh0YbGI2kM8NvDwqApzUiMYOgJYrTD1TSBhiQN0cK50UbDWkpMlSMtPe8gJ/OBiXCZ7nlEgSAJq2es4NbdLVb3VaSHCZOSCh9cMmE4eY/IJRKa8mv+pPEBGgPSKO5rdlnkNz3px2XRvcUiz16/CenbDw48aGUm9BkA8FIYPJxC3CE7q6ddArkB2UuO5yqpdJlrJzYNadn0ywzNKfpFbrhScAqYe4yNkcmIQdMWjwnOSWx0kbklmLROTJaYe0RoXe21oNEBf4DgKTZ+cf+G8N6BSaEvg/AgytmOFgVbnyPCFwSMxyG4sdrNlgQr8pc0CnQX8CVBw0g4VmmXJJ52ZaDKHH+LJL5FkjTVMQ+ucpOIeWr67xSrAituTDnyIjCR85XFcREHMlJlbi0YiwmQ9dliMbxQ+rrMpk1S+p7UfpkhRWExu3o8wHbIHDHFfIgfCH9C5xohHgHPnKvC8OxBA6QseBZmmxeQxgjkZczzxhjzAHXMhnu9zzop/Vg2D69RBY83QR6NuTkwz9h93ABSns5Dg7GnZMPWbcPOkJMUu+nc9B7m8mJtRvkEK2pUZoBbnGsUj47LwnqLsoHF26Gnpf5Pt8Njpt7jdnjUzg3f3K6pjHUU+apPolU3NyEmyCPwku9G+CQx/xxyjLP6sT7Pbcti9/B9LeO4JASLzcMPAuk3S+ygdwixQb09iyFBvcziMcD/Bl3G3ukNCmVuZHN0cmVhbQ0KZW5kb2JqDQo1IDAgb2JqDQo8PC9UeXBlL0ZvbnQvU3VidHlwZS9UcnVlVHlwZS9OYW1lL0YxL0Jhc2VGb250L0FCQ0RFRStDb3VyaWVyTmV3UFNNVC9FbmNvZGluZy9XaW5BbnNpRW5jb2RpbmcvRm9udERlc2NyaXB0b3IgNiAwIFIvRmlyc3RDaGFyIDMyL0xhc3RDaGFyIDIzMy9XaWR0aHMgMjkgMCBSPj4NCmVuZG9iag0KNiAwIG9iag0KPDwvVHlwZS9Gb250RGVzY3JpcHRvci9Gb250TmFtZS9BQkNERUUrQ291cmllck5ld1BTTVQvRmxhZ3MgMzIvSXRhbGljQW5nbGUgMC9Bc2NlbnQgODMzL0Rlc2NlbnQgLTE4OC9DYXBIZWlnaHQgNjEzL0F2Z1dpZHRoIDYwMC9NYXhXaWR0aCA3NDQvRm9udFdlaWdodCA0MDAvWEhlaWdodCAyNTAvU3RlbVYgNjAvRm9udEJCb3hbIC0xMjIgLTE4OCA2MjMgNjEzXSAvRm9udEZpbGUyIDI3IDAgUj4+DQplbmRvYmoNCjcgMCBvYmoNCjw8L1R5cGUvRXh0R1N0YXRlL0JNL05vcm1hbC9jYSAxPj4NCmVuZG9iag0KOCAwIG9iag0KPDwvVHlwZS9FeHRHU3RhdGUvQk0vTm9ybWFsL0NBIDE+Pg0KZW5kb2JqDQo5IDAgb2JqDQo8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMC9CYXNlRm9udC9BQkNERUUrQ291cmllck5ld1BTTVQvRW5jb2RpbmcvSWRlbnRpdHktSC9EZXNjZW5kYW50Rm9udHMgMTAgMCBSL1RvVW5pY29kZSAyNiAwIFI+Pg0KZW5kb2JqDQoxMCAwIG9iag0KWyAxMSAwIFJdIA0KZW5kb2JqDQoxMSAwIG9iag0KPDwvQmFzZUZvbnQvQUJDREVFK0NvdXJpZXJOZXdQU01UL1N1YnR5cGUvQ0lERm9udFR5cGUyL1R5cGUvRm9udC9DSURUb0dJRE1hcC9JZGVudGl0eS9EVyAxMDAwL0NJRFN5c3RlbUluZm8gMTIgMCBSL0ZvbnREZXNjcmlwdG9yIDEzIDAgUi9XIDI4IDAgUj4+DQplbmRvYmoNCjEyIDAgb2JqDQo8PC9PcmRlcmluZyhJZGVudGl0eSkgL1JlZ2lzdHJ5KEFkb2JlKSAvU3VwcGxlbWVudCAwPj4NCmVuZG9iag0KMTMgMCBvYmoNCjw8L1R5cGUvRm9udERlc2NyaXB0b3IvRm9udE5hbWUvQUJDREVFK0NvdXJpZXJOZXdQU01UL0ZsYWdzIDMyL0l0YWxpY0FuZ2xlIDAvQXNjZW50IDgzMy9EZXNjZW50IC0xODgvQ2FwSGVpZ2h0IDYxMy9BdmdXaWR0aCA2MDAvTWF4V2lkdGggNzQ0L0ZvbnRXZWlnaHQgNDAwL1hIZWlnaHQgMjUwL1N0ZW1WIDYwL0ZvbnRCQm94WyAtMTIyIC0xODggNjIzIDYxM10gL0ZvbnRGaWxlMiAyNyAwIFI+Pg0KZW5kb2JqDQoxNCAwIG9iag0KPDwvQ3JlYXRvcij+/wBNAGkAYwByAG8AcwBvAGYAdACuACAAVwBvAHIAZAAgADIAMAAxADYpIC9DcmVhdGlvbkRhdGUoRDoyMDI1MTEyNzExMDE0MyswMScwMCcpIC9Nb2REYXRlKEQ6MjAyNTExMjcxMTAxNDMrMDEnMDAnKSAvUHJvZHVjZXIo/v8ATQBpAGMAcgBvAHMAbwBmAHQArgAgAFcAbwByAGQAIAAyADAAMQA2KSA+Pg0KZW5kb2JqDQoyMSAwIG9iag0KPDwvVHlwZS9PYmpTdG0vTiAxMC9GaXJzdCA2Ny9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDMyOD4+DQpzdHJlYW0NCniclVLBbsIwDL0j8Q/+g7RJ2zEJIaEB2oRAqEXaAXEIrVcq2gSFVIK/X9yWrQcOcIntZ7/nxI7/Dh5wDqEPXIDvceAB+KEAHgL3nDtyXugQEMLlIwgo/wZR5GgeRCMB4zHbUJ0HMUvYhm1vZ2SJNXVq5yVWbLkDbw9sk4OgmslkOHiC4r9O4a9TxOuU4CElvFOksQ+fQ3OOadKNEa0JWtOQ99Cp9dhbgxhrbVmsS1zJMy2A+rguqJos7YIQajFqZXrZNV7tEm/gd9ILp6W0RbamY66y/2DrSg/6yhJMLftEmaFpfeLc/S9VFgqTo6QbEjBVTkHaQqsuNrb4kc5pom9tTgetT2ym07pyd2qQyxHRtoNaydToXvxxdGcvnhWy1HkPSMoiw15t28eV5UZWbFHktcHureu6uuyg+aV/031uD8PBL55g4SMNCmVuZHN0cmVhbQ0KZW5kb2JqDQoyNiAwIG9iag0KPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAyMjY+Pg0Kc3RyZWFtDQp4nF2QwWrDMAyG734KHdtDcZrLdgiB0TLIYd1YtgdwbCUzLLJRnEPefrIXOpjABvn/P/Fb+tJdO/IJ9BsH22OC0ZNjXMLKFmHAyZM6V+C8TXtXbjubqLTA/bYknDsag2oa0O8iLok3ODy5MOBR6Vd2yJ4mOHxeeun7NcZvnJESVKptweEog15MvJkZQRfs1DnRfdpOwvw5PraIUJf+/BvGBodLNBbZ0ISqqaRaaJ6lWoXk/uk7NYz2y3B2Pz6Iu67qurj398zl791D2ZVZ8pQdlCA5gie8rymGmKl8fgAH/G8nDQplbmRzdHJlYW0NCmVuZG9iag0KMjcgMCBvYmoNCjw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggNTUxNTkvTGVuZ3RoMSAxMTg3NzY+Pg0Kc3RyZWFtDQp4nOx8eXxNV9f/WvucJFfIKAgRuXElQhLzmFxyI4kpRUhwL1oZhJge0aBokWp1iCg6oOVBq+3TFnUTaSVoRelAqQ7o09KHtlRbVZ10Ujm/79733oiotr/P+/7xft63Z1nffc6ez9prrb32kYSYiEIAOtlSMwcNOGDdMom4PJUovGJAalr/iXvG/5voXCCRtnBAxrDMpJ+XbyT6cgXR3c8MyBzZ793SnDnEM3oRpfgOy+zYpXFc8a1E/AZ6zR6VOsTepXxIW6KIh4mCHs6bnlPYccyUb4g6xxCJg3lzZpmf888PIUq7m8indGLhpOnjnsjxJ+r6A5H3wUk5RYUUSw2IPsOYFDhp2ryJUZ0+KiUagvkMLSnIz5lwZp7f8xjvJpT3KECG7/O8H8/oj9oUTJ819+2Hd8zHWBgvfNq0GXk5DyRufI1o7To8F0zPmVvYuGXDZ1AfTObp+bNytI1eORjPKef/j5zp+Ql3j5hJVKUTxc8vnFE0qyaaRqK8WNYvvDW/cFt1s3FECdVEvvtIytL7/JL9ofkHxwdYL5kamEhem6KG58j0eMf7AwyfX1fol02xeGyg6ssLqfezVx7FIhw2fIwx+uXaEs+lyRz/7VRMgdQVTwJpR3Kg4EuMK1Cq6Yd5BXmRyesxr67oMtyVajk0UQR7eQkfrYEQXkLXT1MHo5rmpqgZ4MoakmImG5mjDunnahbKmYhJNmLDMNA6V39Qvik10Q/TJFkbqZzwefalXXQGXMMfi5s5nj6hFRxLO/kwfUZnUbKZ9tFx2s/B9B6d48Z8mHtRLuXTw9yY3qcgGk2LaD3ZaQPeaSpabMbbFFModaAC2g62UxUtp0y8ZxRlUB4dE33oU7aiZ+LdtILi0WIhWrxPC7AiL1EF7cFsmtA0WomyYpQeoQdpLCVSL4z6CF3gR4SVH0adINAi9C9HykRPV2kz2rlop5tkbx4a66bfeDhmcQct5xlq1kosvIuTME4w5jodPeXSw+Ax5IT+9qB/0cccw9HUB29TSJ/xebzn/VSGuWTizRahnZxTATiYVhrf4v1P8BWOQj9rMfM8SN6Hpoos8qfGdBmSjKXT6CsI7yDZDum5qEBRpqKdbMWYVk6AcpTxTk7ko5DeKIxZBckcowvCalyhO9H7IxgvHqvnz3N4JOe5NU6uywL0KWsvwntKXmicFfsx5grF6/F8BaMXKy5Gzx7uALlJLoDU7GgnWfazHCsiORNSlIxZKF6ENxwDeb3AYbSG3qbbjbMcjHt/ErzAwxLpWcjqUVohwqWBiHARLtHFnosXoFTWVteN7m98iUmeG1CAm5/HekfD7mB5nEyVeEuB99vAAZh3A6wKsrFeu1AmeDJPpuehG1JGHsl5pOSS1IJangrdnUp9IedddfgltKiAZu2BrDzyLHbL0yNTlzzn18rSw1HQd7mm76vxg6FxGVQIq5T5HkY59MtK92H2jVCvIYUJE/RjF5vIZvyG90k2fqT2xlH6TllqPkY8pqzUAWlIG30I85gAvdmPOeRhhHCyojSPcrFqS3kXjWad+vMoWkrbRQA0JZmyaDCnYe4HMe/RWMM0ms0xuFsJnq00eRGoSunxZrJA/kF0G8VhFDkD6S0Gk924TLdSDOg21AjFjFyzWIRZxKl5OKgddjJdrd1oaHdTzHcFZHc79GoM0hA8JYDmwotGoP1KsPQkT2P+t+E9h1B/igSlo/enaTG1obvQ6gG0lv7kJXiECupqfI0Vm4sWUzHyGlh4ZyoQ9uuoqeJ4aPX9wqotpuf4EHR7PTehTbSRb+NBWN0CLsJaVVA1vMYS2F9LGob77+hX+g89Qa/SFjpEG7HKS1C6h36isXwb6j9iXDAuoN4hyEvy24o8PU/ihDr9LlF9yh5r+0Mf61H2K20RKVzK2dyGX+fX6bKAUfFJXg0+yZvAB/kEf8AT4Nl+4EWcxT3ZxD7cllbxt/SZGMzv8Pfsx205CCt71f4OCk2w0PgJfpI383Qegbx1nMvZ0L0oVaUheauagZiHvFZA8tK25OULktdz8JTf0GrwN6i1HrYAwkykn3blr+a7+Bhm/gwfRP1wrENsbeq5/2+4MPd17MtyViGwcl96ExJaDc2v5t38s5qncha4d78fv4H4w/Ounjz3u16XrufhkpUMJHu7ZFOb1r8aueXjTrkF1rdO6pEttPe4Sitg77LcRDNVWs7lKr8GWi2fv1exEsn3Ue/yHM1Rz5Ngo4vpcVoHTwIWzbHa0AvKoZsgjxPQDT9owCZI4mbEB15Yh4OgY1iNu1AqR1lH6/hLvsSXYN9T+QX+gT/laJEHqTlhN8kUzaeR8yl/zXvR4+uQwnqM9T7ihrfoME/hWZjhYdqNOVqhy/dDA4Poa2j7btDr9Bj8xz18M+hl0G5+jE9dlXatFKSmSDmHK30gHgCy0/f0If+M9XoLWdKfwm9iDo/yGt7Pb3I1/OCr0NwqjoVlhPItnKotoDdU+w38Ej/F+3gHKFZRjCKjlvZDAnWfr1I/1AbX7p9/levuHb/HZ+GV5J7h2R3+KtffOepynoo7XCznIMe4QRvuyCF0CQxfCP8cAj86V/FUUC7aS86AZreDb5X7XT/MGX1BH0p5LA/kPaCBim5TViQ10aON9azor6Y3tLY/scLf5dXgtXUs9EZc33L/xIKvs9g/S6VFe9gLJC+P13Rb+XWpx5v+SVrrHW6QerzFn6W18oRXQdT5vbpHCn6jdl1vxAGwUrc3da+/yxPJdIyL5I6D04Qdu0o1b4QNF0HffPlrEQJPU81FfIhngbZSZ+UVvubq+qvgkTo8ebmSnoadfh3t8Pi5uoz+YhHLLRHBIgxzeIB+YT8Vi6xWsUoTxEHB0LfhiD50sIyim6I0XrGssRnxscwpphdgqTgX4y4R7c7Spyq62wUv2AS5MrKzwrqaot12FdntR+z0IDyrjJetsLI+qCUj5ccVnUA0sh869yDF40xzjvJxojCBfDEfE+zVB+SLsWC53LE2DvTEnHJkjw94nEqhK662sswXM5DRZn3f4/IxO6+JQCV7/IAnut8McsW099A5NWNPL9LiY67xP9K3FOAM115FYFNwJ89zQ9UOX0D3ghaANtOTqDsS+9EkegmxpIyQd+FUGQTJNXFLLwE1hmKXWUlFijZDQieBD4CO4Jwl6R3MTp4HK7Ee8kyYjKcLOJmV0lZoWAV4M0a9HaPKN6iifyCyK1Ylvm7Krb17FqfJYNB0juf2oHj6HLshIzbCqY2vCH/hj/OWTZ0C59N80QM7ym6gFfvUbrkXqBprFFmhx/7clYewg7uzDc9WnP6AOAPJs1sSbCeRrWh9DGkCSI4RpTVXfbl6OHe1N/musg3i+Z18VI0ZKXtTLXEelLupK8W7f4Z2Vn6OW/E+QRhvN+YZg95Nsh206hh6dO1vU3iH24Da4qkTZ3A0N+PerGEl3oEUErEDdHe9JTR4AKJZAq+kLtir5VqXYh02gGw4EZRiV5Yr59KV2ZB1FU4i+9SZ/U5ozW51V4F2m+kX6E4MnhNg56sQl/dW/jNInrjgAdthX5HpPFhkOE4UcqQWWF3JrRDf22g82oXgTWXrReizAlK2Cj/hRwyKQb+jaaKy3CjqBgtdoXauZoj75YncF3Y0GvYtT3DL4XcbgeQu5gVfJfls7X5nwXliqptkjVCKQBTusSJpfdIGsPOpFnKcfZCDHF+yxyLuRMQVB6vwsOxJoK9ZsIxAvJG06uHwg77KXkOUnDAvxNnP8EnRFFHXKj7OHYxvtYO4W6UlIC5/Ffq1A7pwEjlp/B5wI+qf5J1agvEtv4JWHUFyjT/i293ewuPDXH5sszzpX8e/F4lsgN+8eqq9lmWEIj2I9D4ervvNQHIotMLDnm8Idb8l1OXtylfG13qiut8Z6rPnu0P97w91ORA6I9lzRpYRi2TppTzfKSSPRPteyFuBd82tR3UuI8wI4zpUtww2cC3Vayf8+CxWaZVi33qfAqXerqxDss060H5jv9qb6hIZs0BhsLFriYyvjFGghaAww0fOXc0Rc+Fi3qz6Ha3O5bP/7B3/7F3+yth1SFqdPLsHwUZ7QA7Qyzp9CzdNVbt7DDxwiJKu/DgqvxugzFVSK4GDIJnmgWRLRDTwbjF15uPp0ypi4BUeha56LvlNMRr+LYE+k98EcJ59gs+AyuAnE0ExfJi/cJP0sIP4DPxpAk4Islao8Hf3I7U0EeePKGii/IogaQXtYIYdHYGXkrvXYvBmaJuF2yjpP013gZ6mUZhRKHYhuWNdQCsnytbgaSrKwuFzPqbjOH0HcVN442bqdD4RkfhlbkZH6VtESsGczjdxD7ZwQ/pIWblG71IN/HYn+OvOIA2+PAY+PBEe3QqORmki+roJ+n0JLR10BZG5GbtcBvx8M+TJnM4yp45SrkBcdQ8/yPPQ9macC18WLRDbe861niuB/OC3WmHHD0es0wrRSbwkyGY7JdXWCgEvkh4Uke8AUJDyQcWw3COQwVxtKdYhjDeilkVFWZLW8JOiqWiCE4SdTuIs+Ik6VRyGLnyIef53nSLqntXdcWX98/cNo3pPpF4v9ZzH65/Lr4usPZF4/dMGYd97GSh39LXY7xzQ9gs0lJsj5iTEmWegfaOoB3AhVjSg9it5vNLFMuhSPuqPwZosxBr0Qt8+6vtjGVqXQjt6cwBOwZ15AkhDpJAhOvFsUC6iYyudQhz6Dh1Dfgh0J4SzeKjSnoHcGKf1SzxTUTdOkZrFX0HDDqv4IRra1139b4Ydq7ezvpdBTy5q5KL6no29QHXzZcT+EqyjPXx5gNqLZASRhTQAd9KHb1a0S32x8/h2uQ9j5+bRLqK9tBfrC9vFu0tbnYX6hYhN7CrWlruY3LXkLuA63d7Or/FpjlPWb8VYHaiYF7m+ovNcLoAvnQsq5ijsWMVqV5lNn+A+EdFDC0ginj8GLQCdV2SlEH6dX+RKtJrIW7Fr78TIZxDfzKMG1IkCcM75GWecS/A47yI6ewf0IX/GJ7DrfwB8QQQjuvy1vt7W6gr0prYshBGw0sXaE1f91HMq6wjdAF/Xlyf1nDQHwKL7UjPOoCGIXdpTGqRwN//E+/mn2pNcfRu4wdi8Bto3Hva+kUbAZzhYRns7aAJsqQE8hz9Sf6zEeqytDyKhhiiZqlZHfj16gTorKX+C2FOHFwmCHwnGmWAlPNh0uoR44JjLbBCtbuSTSFfzJPVli3iT/P4pv2CCT4B/4ZWKSvlz/gEyL+RCeoZ+Azkgk+YUdg2vVt+YXFjPg6jIsRFd93Xuuq9ydc+88roTI8kvjRroNaz4m7yJX+EtojX0ZKsL4XszwId4Hf+H/yPYRfwoIt19/KQ6x8qvu9ddyDXh3b+B11TfjWkjYsE1sJ85OHc2x460DTyC2lIqzjsPQmcHwZ7eQIzXHNFSE6xHM/SdiZkG4YTWE3fNkTeTHqKv1P+JFNCjvBf9P859eTd0eDr8+sOUgnPVMGWvMxGdO2gah+OMfB9GHEkfISJehbY/GR/TryjphxX8Drv+WFhbCDzWAlh4CHXHDrgEs5dfBuW5tSd8iKSm4O1q7+hpHKz15NuVv/ZcHp9bKNorW3gbJ/Sd8v851YqlqCje300BmGUw3vyVWo/u+ZK6CSU32jmkZ/asXf0vsR5PPoH/CZl+x1N5BlZvq2op/wd3K7XhvnSQw10zZXl5aZqy01CvrxpW088mA2/sbdRAvg0gN1+FDakhEPoF9AP+htn7AQMUBpI/MIgCcPIIVtiYAtUpJAjYBPgrZBcMbEaNgaEUYvyCtWwKbKEwjJoBWwJ/hvWFAltRc2CEQjOFGT8hPpLYmloCLRRu/IgTlMQohdHUCtiWIoxLOO9IbEeRwPbAH2AvrYFxZAHGK+xAbYzvYWFRwE4KO1M0sAu1Nb7DGrUHdqNYYHfgt9jd4oA9KR7YS2Fv6mB8A98hMZE6Aq3UGdgHeBF+qgswiboCber/c5KpG7AfdQemKEylHsYF7K09gf2pF3AA9QYOBH4FW0gADqZEYDrwPN1EVuAQhUOpL3AYJRlfYp+ROJxswBGUDMwEfgFb6gccqXAUpRmfQ6sGAO0KHTQQOIYGGeeg/xLH0WDgzQpvoXTjM3jIm4DZNASYQ0ONs9g5hxnyf+EkTqAMYD4NN87ghCtxEo0AFiicTFnGpzSFRgKnKpxGo4xPYKWjgf9QOIPswELgx7BWB/BWGgssAp7G3jgOOJtuBs5ReBvdYpyCrWYD51EOcD7lAm+nPOM/dAdNAC6gfOBC4EfYiScCi2kS8E6Fi6nAOIm4V+LdNAW4hKYC7wGeoHtpGvA+mg68H/ghldA/gEsVltIM4DIqND6Anc0ELqdbgSuoCLgS+G94sVnAhxQ+TLON9xEXzAGuUria5gLX0DzjOKJuiY/RHcC1CtfRAuMY/ZMWAtcr3ECLjKPwm3cCH1f4BC0GbqK7jPfgEyU+RXcDn1b4L1pivIv94x7gs3Qv8Dm6z3gHccb9wC0Kt1IJ8Hng2/C/S4FOKgWWKSynB4wj8HLLgRUKX6AVxlv0osIdtBJYSQ8Cq4CHEVc9BNxFjxjSW642DsGDrgG+TI8C9yispseMNxH5SHyF1gL30Trgfvon/OirtB74Gm0Avg48gB1gI/CAwoP0OPBNesJ4gw4pPExPAt+ip4BHgK/T2/Q08B2F79K/jNfoPXoGeFThMXoWeBx++FXs3RL/TVuAHyj8kLbiVHuCngeeVPgRbTP20X+oHHiKtgNPUwXwY3rBeAV7vsRP6UXgGYVnaYexF+e3SuA5hZ9TlVFNX9Au4JcKz9Nu4FfAPYjsXgJ+TS8DLyr8hvYYL+MsVQ38jvYCv6dXjJfoB4WXaB/wR9oP/Am4m36mV4G/0BvAXxVepgPGLsQMEq/QQWANvWnsJENhXZ/uq3y67/9Jnx7zt0//26f/7dP/Cz59zd8+/W+f/j/Kp/9vitNT/z99evrfPv0PffrMv33633H6H/r0nf+jfDqpb0eSW7p/Ov8b10/l84+kQ0oED2jGXSC8azv4xK7wdgnwV2nwQUPhV7LgPSbDSufA5jZCfyroC3PrqEPq65MZ3jYOvtPVIgW+awj8kWyRDau/FbbqavG5q4Xx6Z9SHugDotP5Z5667ncJbnyZ3OlM+R2WvenqLygIIb9R1fuACHHorh9DatiIKCAwKJhCmjQlbEq1P3rZhqLbxhDFxkn5dKau3Qjuv3dtFympaf0HDBw0OP0mGjosY/iITBo5arTdQWPH/d70Cmf+7qzvVbjsj19N++PiG13/K1fWlmIfmWVL6tvHmpjQu1fP7t26duncqWOH+LjY9u1i2kZHtbG0jjRHtApvGdaieWizpk1CGgcHBQb4+zVq6NvA5OPtpWuCKS7N0j/b7IzOdurRloED4+WzJQcZOXUysp1mZPW/to7TnK2qma+taUPNifVq2lw1bbU1OdBsJWt8nDnNYnYeTrWYK3nMcDvul6VaHGbnBXU/RN2vUPd+uI+MRANzWmhBqtnJ2eY0Z/85BSVp2anorqyhb4olJd83Po7KfBvitiHunM0shWXcrC+rG9EsLaFMkMkPk3K2sKSmOZtbUuUMnFpUWs4EZ8Zwe1pqWGSkIz7OySl5llwnWfo5A2JVFUpRwzi9U5w+ahjzZPk2tNRcFlddUloZSLnZsY0mWCbkjLM7tRyHHCMoFuOmOpvNPxN69RGdB6fY761bGqaVpIVONsvHkpJ7zc6Nw+11SyMlOhzoA21FVP/skv4YuhRCTM80YzSxxGF38hIMaZZvIt/K9X75ljSZkz3F7Gxg6WcpKJmSjaVpUeKkEfMiy1u0sFUhiGiRZi7JslsinUlhFkdOasuyECoZMW97c5u5+bUl8XFlgUEuwZb5B7hvGvnVvcmvLVN3qrq8Sx9RK1mWM7IMgkI4zXlmzMRuwTv1kpDfi0ryeqEaLgejlXMCVmSys0FKdklggsyX7Z1eUYEWc8klggZYLnx1bU6OO8c7KvASyVupJ7WqhnLPvTM21tm+vVQRnxSsKebYVz13j4+bUykmWwoDzUggPsqAbHMcCR0h/shIucBLK22Uiwdn8XC769lMuWHlZOsY63CKbFlS7SlpMlKWFHtKaptnW6DJFcrsmzhN0bX/AgKbNk4rSHBy0z8ozneVp2da0oePsZvTSrLdsk3PuubJVd6rtsx952ycYtfChPtOhGmqFEo5rrayfLA3cupR+OetlHpCpY8JWqly2NzfGZg90IUO38jIv9io0vhGtlLJ1WbuaToTYq99Trzm+ZrpNSrRMGE9WqRnjSkp8b2mrD88UElJf4u5f0l2SU6lUZxrMQdaSqq0aC26pDAt27OilcbOpWHO/qUOvEQBJ0BbBfUrs/B9w8tsfF/mGHtVIJz+fVn2csEiJbufo6wNyuxVZnhdlStkrsyUD2b5QOkMRS8XJlU/rMpGVKxKdZWhnvMqmVSeyZPHlFcpXHmBroGi1UA2bNN5lbqrxOaprSPP5MordtWOcdc2oSRQluwk+esfqtB1Sa+RkmWvqw/KyJTDQImTLc7bLXMjy9DIeatlnropcZrhW1DLmdfSUVJiBlnQf94ouwshfiePlaj+qQ7LepClJfp2SCfvLM5FByXjSsZYIuFDwtGLKytSPvq3dKgesA5rWsIYCKFzllGtVZeP7GqrRJKgku3+bboUy7Shn0rLG3RNSu6oVVMheBv4CFin8cBF7hyNIoBJYJm7XJVv1HaRE1wNfhssc3YiZydydiJnJ3KStEpibYf2YnmbCAxdsb15my4Xk1to28kAC22lthSH7gjtFnc63p0uR9oe6Qp3ukxbWp4YEZDcAM9MF4EGWODd1pUPGNalSt30tKqbtZ6ctduRE5HcXFuHWa3DrNZhVuswq4tARq9rkb8W+WuRv1blryVWXUW2c3flvllXHtDUnYObZF/NoY3COT5Cs7vT0dqo8i4Re5KztZHoepvCjVoWcLnC8QqHKVykShep+xnqfoa6T1L3Se57iR3rYITCAInaCC0TsVaENlwbrNIMLY2ikA7Ds0yHaoNUOkQboNKbkB+KNB31gpEO1tTPYGqD8JyKdCCeZTpA61+eGtEpuRDP41EmMJ7MT8UcUjGnVAhJ5iwHbwSfUjnjgYvAR8CaqslaKigFlKwlo4UNfdhQYiNNs4GSQH21vijpg7p9gDbNqt7RilpWjGSFrKzo2YrlsWJ5rOSjWYFmrTt1AtvAGeBssBf6iUO7OMwrDiPEafGIrCO0SFFKIUjN7jRCLJU/96q1EkvLW0XYkhuICsoAZ4MLwcWiotwrOCA5BPVk3Y7gYeDx4EXgDeBtYBMluUpsDUWSSNKGiWGaDu1ut91q7aLSrj1cactwV9qoRZeA5Fu1dhBTO9oA1jBlBMvgpNqnCLCA6rSlPeAj4FNgKfC2EEZbCKMtXrAt2rdVtbxVvYtgA6xBidqi/2vreKnWEeCOdXqRuTHIicFTDNrEoG4Mck8BWbWQ5Rng5eA97rLWSplbK+Vsjb5aY7YdgUnqLgAYobUuFw0CKiFfTghIToLch4FRKJZBmssgt2XSlQhpxAEKO7rvS3FXSp4Wy8HbwN5aFagdqC0oBtQaFAkyg7CiWius5grQctADoGWgUtBSrE7Ittg9sWJ89xndF3Vf3n1D923d93T32SVyQNki2+ZLTXEao+AgU4vkQKHTOPLjXxVuVXirQpvCZrYW4/zOjPN7Y5zfo+P8HhnnZx/nN3ScX/9xfh3H+VVyrq1ZrN+JWL8VsX6jYv16xPp1j/XrGuvXLtYvOYgdPJr86GWF/RR2UdhaYTiPLvejBrt5LEWaYAHctiLyzoizkZU6l0fcFVlpQrLY9TTWlSTKzBcjOkVOiohz5US7kjaRL+nogUbyFvLhWFuczwGf8T42n94+HXzifWJ82vpYfCJ8QkzBpkCTv6mRyddkMnmbdJMwkSmk0jhti5Wn1hDvQJl46xJ1dR8ofzJUHXDlHsgmQYPJ2VhLF+mZ/TjdWZ1H6blm54+Zlkr2RVThZenHzuB0Ss/qF+rsGZte6WOMcPaKTXc2yBhrL2N+wIEnp7gPu3aWvZINmbUkTAbwVcQct2RZmDt1OGQbe5nOy5Y5qOmcpNCk4L5Bvfun/g5kuzH26hUaW/cBMwl3rkrPtDufC3c4u8gbI9yRDsnJeL9K9BI90lKrRE+ZOOxVvsWiV9oIme9bnOq4Wo/MyE+tokiZqHpklvXIXK9eK9FT1ouSiateK1Wv1TX1yvpEpqWWRUZ66vRRdfpcW2fStXUmqTqT3HU0V53IOnV8TlOkqhPpc/q6Oq3+Qp2o361TR5r5/WL/4OIqGszHy1Lmy8NStiUtH5ztXDqnIFQGK+YqSuHj7nNUdHZuXoFMc/Ir+bglP9WZYkk1lw2ef325c74sHmxJLaP5aVn2svm2/NTywbbBaZacVMf2ATntt14z3P2e4cra5/xOZzmys/ZyrAFbf6d4qyweIMfaKsfaKscaYBugxlJaD7U0UT8HonOVbhcNfaHA2YjT+jUNLOyrtDkxMnRh2E5d/v2MhjisNMLB1w8si+KT45NlEaxMFvnLM7G7KHRhYmTYTn7GXRSI7CBLPwpNm5yKf0VF7pu/+K9IXrNuKbpFpepf0azZYLlQ8teBZhHeIbmR8soR8M9CeWbpkaXX1oqKHLNIrWrRbJL9zZJwtfvau9nomYvqqgEV1b+kbsSSi9Fd0WxGLVlxtltx5K+UxaIbkpN096KfI9IfpDCkrbRc7OBknHLzJ/IvcsjymiuGId6Hg8pys+vKAj2iMIuHuFKaQEfV796sRl5XfoueJRsFIP8oaUxsJys9RLfRMRppfIvcSNpEFymOelOBUaN+1rqGF9Amdv31g170nvx5Y2HVYvXzcI7tuZO2mRdTPHrJolXUjI6gx/aGL563i3BhRasselMbb4ozOhnfcbV+wMilJ9gqjuvP0yG6wK11qrnLWGqsNdaRP/2ghV/ZZ3Q2pqPVSMqm2XQHZlBM6+kwO0Qfsce4X/2Ni3zk7qA3ORYKlY0IbwRq301rqIpepiP0bzrLzAEcw8X8Hh/1oiv7a/Ybg4xcYwal0VDKoGKUhnMUJ4sx2hhtq/b+lU9rThut0HcWzaG5dDstV3//4336gE6wJnxFlhipbaUw6qP+MsVKyGw9JHmATrGJu3EC2/ge3iLm6NqV/djxdWoCCQ5U0l9JayHTp2gb7ae36R30+a36ifvmWPqRPI4X8BJ+gB/mp3gLP8/nhZf4t6Zpd+qv6edrjhu+xmPGsxg3jFqSGbFvHNbgJqznYfoS79ee4ziJ3xWxIk5jvdGVmpquxgBjkfGq8T5ZqC3q9kGcm0ZDaDRmPY/uol30GtoeprfoM/oJUtLYl4MhCzNbeARn8mzMYitf5CuiKdavl5gmysVRLVY7rI/Wn79SUdOkprzmYo1hbDacxj7jkFrfHhgnBStwMxXCwOSKvYBxXqUz9AVdwhjeHIG5DuR0vO8a9H+Kf4M6mcRCsUUYiIZXaAf05vqamqE102vW1Gw3uhlD5F+wQRDWnLqBEqBN8meti9TvRWxSv5u3HdpznL7mUG7FnXgQj2I7Z3MBz+BCnsm38x2Q6rNcwbv4OJ/gr3F69hZNIKdYkScWi4dEhdgvjoszGmmZONPM1G7XHtIqtLe1z/VAPU7vpA/Rs/V5+nwv8tK8m5oO/dbst+lXcq88dmVfTYea1JqpNUtr9tYcr/nEaGjsMc4iNO2EOTpoEua4AO9/Dz1AG6Afz2GOH9M5Oo81/w6y0LgBt8CMI9S6pWDeQzDz0QiZJoIKeArkX8ybuZx3czXv5QP8Jr/LJ/miYMy+AygRVjBSTMQ7PCY2C6f4AHRJ/KJF4xTQReuKU0Y23uZe7T68z2rtpHZWF3oTvbOeqS/SX/fSvCZ4rfJa67Xf6w2vL70Dvce6fcRVD4JLOyT26n21abQRpwVN+1K8K6y8QFzmf4lw3ovRwnH+yhApIhGx0S5o+XQK8VnrHekdKUIo0Cdb9iEeFfHaaD1aa0Sz5G/liTHiHpFNT/NuuiwGQtPmaIfFRjFeW6s/qPfl93He2KuT8OMfKZmSuS/W7j2aiRWK17bp8vfyycuk/eY1XfgZ9+rnvIT2LvxgHxbaQR7DFzhDNIW0EsUDZMFzIF9AOggW+AE0vwphZy/9tFYqBosTyJtGD/FevOMumiZ28RNYl16wx1s5g9dpnWkhz4Q0etMU8TC1FoWiNfR5JH3Pi7kJLPcy1qaNmEi65ify6KhwYNXf5mDRgRdCT6fTUi6hOL7C1XRIrKQenK+9/FvzKzGCf7vAZdpAKuPL+gH9AILvy5BkODTXhID7Y+j0WozyGkVq0dCaXuQlcK6DPWXD1oPEJb5DTKPJvEb7gp8SyTSM8rUi0Z9X1VzSk7WukNhOeJMU794m8rJ6hevdsOLnqK/6HVnyLtBPeS2W99p72g+Gw4isGe/lX3OS5kM6A+HdlsKWBtKH3JRv4eG6IdJ1wxhFm8U2/aTRjBtxJL1jwMJqXmArtzHMPNNoyMOh4bfIv1GlL9WX6LP1O7A3XYbXvIcepMfoFewmT2Lfags53gRpjoPvmYw9ohN1oe54u77UD15pEMoyaBT8aTa85ET6B82E5/0nbaEy7FDpkMctaDeRpiC/CDvU7bQQ9n8vlcIHrKKn6R3xnNiAM+994lUxR0ymD+lD7XXNxqPoqH6/vogycSYezo0xck+sUgTalRrvYbR2FAbv3w1WCr03zhvHjWeuHEF/T8vfCPbuR+e9UyiGhvGPegv2gn+DDPVJXvK/jHyof5m3TyU3qhBMXrq80cjX2ws3L2qaaNHAR+a9+P84+xI4p6rr/3dvXpaXZfK2LC/7+jLJyySZSTI75Ck/RUAWFRCEgIorYmFcqmhboC6I1ULFpWgt9KeolarIsAygYv3hilbaYqWW/kD/I1rLKPpDqsJkfue+ZGYAaz/9/TPJfe/evGRu7jnne77nnJsZREmmiTe7lQnskc7x/Z0T2KOd49l+CPI7+zvJozGX58JcPMyFL6ep4yHdi8dVPXWMCtEvgj39feAD/IFer31PYaJq/5PlQws2Gc0Ui4TrPPD2W1TBRnkszqfZkcg80v80hFFGZHwOjwHvUEETKLfCHi339fayvb1UqdTH9iGOb4N7Yw5gUWcwRCNyQicXC835JqdD1GmtIQqjMIS3yNjF8S4cx9loNHNpQhkxMkUa+p7+C0IeTwg/5rZEMpmo+bhphJLuHJFq6CTxkRk/rvst/Qftu+YXPlun78G3q2ZkZshfNDO/y2zDj1IW/IJqDXE7uLe5/dxnnJ7bhpwUxi90m8D2e/Cjm3Km+RCXPYdXgTf/HE2qfo4jfWw/fJojfbB2nWwnrCd8jHDtUwyfwO860xCSpJABXa6duj0hPf2HikcOBmV0sHqkEC5XjgOafAS+dJKaSFpTLNa76gQz7zQY9KzLKThGCvrxDCOsqYtRFAuil3xvbAMdcCPpNiLN8vj+I51sHwsrC4KERW0ji0uWtowKPN9SXVMjOBqRd2nrGknIWMblzicT1jpeMn5v1qzvGSW+zhp/QkVfXIswOjdqcXNm6xuVnkfXVnpet5o5yRJBYysQDzZUjuNFtdkmGcx4JCx5aDJjhje4nKzeALM1m2HSMF87qAumPP5HtwHvq833KJlvL0xYm+5JsxUxNho0obc088UCTlQ1wuXknXjRP53t59dWBipPRawSzPZ1dNaja9FZb8BsQR8qm8lslcoe/HuUoRgqr7pfov5AHaAOAw3aTKP/wb+l/mCHQBwbn0M/p8zU1chfFW9vfy+V7dMmFEa16YDb4yrvemUpqkOZ/r1NUclsJWH4NmykBbwIrNCjWqkX4bPqsUTPWUfMrJc9SGXHkzdyhIu0cPxxvOjGG2FObw18ABT3c8pG+UAfN5gs9F6LVHf1VhSgNOscDysDr4qfbARTYq2TzmkhzecTW9snkAf8/oMD5+s+0V8NanG12s4wTiQxulaqjTkTjWFmMFcx30c3MstMy5j70SpmLfo1s5najF5FrzN/QgfR35ij6CvGZWGQpQe9tklnGUnNYHrQBpjUDNPzWR3Svcv1oO3PPgercqTcD/peW5euchkNLUxzzWQP9M/kvJxkxo9YxDpO0se+mRaX7FaH/glXnWS3wFx7Aaw+pr8CzXl2A2/y9gx8pdo5A2VivKp3Ej/JSzP2bfjXlBU9pDKs1WpnX2BMmIzoYYRHej1GL5hqpV4j7xW3QaTB4cu3UHrGZJWwuB0vAUt34d+pZupyjkOXAzqxz+MFQFF/BQGGG6Vv01Cok+3vYzXjLfURHHK1UWz/CL4t60bsl0d2ntRpzFHlVrghLlyVRliTRj7M6QcVtQWvQKGAxxPon0daFKp8KjJ2yWyS6K+OzXQJvNvNCy46N9UgcXabiaDPOliJdwFNFdTyLJ6mTFPZpI2L0xGz1yuOiOgtemAHM0Als/1v5kt9+SyZY67Ru5VyDvy3mvbGCmfZb6q7PXF7/e3Jx+ofS263bkwxNt7sLFpbU3QymgooYiJQH7WKlp6BQ6r0Cd/n/Ibvd9L1pvoU7z59iqK1g4u7b0ttbfXPo16wFAuygZbO2MgwZqunB329kcyJ2g4zsgCqzthoep8bET/NhueD73TBaACut+CrgWH8DBkGlxkw8ihoDLHyvr4SLHkvYH5tZSmyshBywuKOWqj6gjHe7YyHZEfYrVJClFORKyiqiI9BQwJVuC1ZUhUD3Kgu1KVMbwnXfAWYVqxlJC4W5GjEYDTU4KOmlAaDkTL249vcIITjexD1Rdfk4NM3f+9JycBYWc515daLHv5AnvH9yt5tk8NEdtf/4OCn86+YWD/vsR+V3Uazi809Ouu9O9svuva6yr5fgdz+a+ADGtaKAnXonteKqJ6BL9R8U1ORa4+NiY2Nj2q9hjIsCt/eeh+9snh/69riY61bhW2uXcIu8S3XX4S/ug4J37gGshx53SYxAnLkekCgPjhJmuwWpZ7TZWEebkof9VFSIFQvp6UeNKM7FOLTPejubnlEvg6Om/gRhuiI5h5kU82OETqfr03nac9uAyn48JItFqktrzfYDm1Di6uyAH+LCKr09k5gD8Lyj2eJ5yIC6e+Fbh+gL7jiNs0Q4M4BFBOpFIqxuCDS+nghqiJB71BRrCirSKR5laI0sSyBGxxay12tVGsXclZdizwE2vmmZhCLXBVI3qX1NCENWk5VRjrhupu+7Jn3ccbuYlnxoafuefmizeWAR5LO6lr54A/OvyfNchbOff7CB1e/eTFeV9h08QMfzcyxPOu2X7tlwbgV5xELQ3fOmLWisyAyLrZ+xJQdt06+HzSVB2l5QFpRKoeeVK2ZiBgrRAJKIByQtw0cJWkLta5Id5hG0eNMU+gLTIY4SKMbhBGqHSPaMVqI9QzsUc1ESvDqmMnWA69cRNO0SaRFk0zLppTQLowTZghzhYXCHcJtse3Cpth7lvf4v9sEC9KbjCGDLNljoXj40tCc8MLwwvprswty3ZHtqT9ZPzAftPIXmKL2MMvxIUEMOgJOv0ti3bYIFbNZ4xbZjHJZnEmD8SaNSkrvMtTZYo1ATtZuahih0zHeHvTfqjM4QtQnRjA29/uGEVSKTYVSuRSdeh6/Bdw2hmKUFT+2JTIiV4fqpMbtqBUtqeqGxh6ImfaXwemV+sBWiUr0VtmZS3tU1SGeDoVpgbVzdt6uM1htFhs2pOmUikJCpAf9RnVQsjmmUvFYvQkGFX2DisL2IHnGguK2hEoljQlNcYjqsJ1wSKWI/nRpdq0lmKoWrgx6lEFdAusm2lTjLdEI5RBdzppyRSNGA5o3Ye2lt+9+4fGrn28eVcqteecHk1vdTs7GJ0f8V2WHJD8yf8HqNZdedEEnFq793v5H7//69p889Ydf3nHl6ksjdol3mcXKsx+Ff7/5F8/cdctvzmsBvdH8s+5i8M9eqlFl7BucFtMGysBvB24oUTRybrJYJMk37LCBR1eBjrhtdJLbFr7LiQ83uosntXRMII/+5UOeHYMno+gd9D1UisqgzarSzIGVekemWxpG82M8Z6fPbACX6ZztmZ2e1PBVyq5QqVQ6gzBuMLPAW1WnbblttQ3vtyFbkrPZWM5v5vhokjxVJ8v5lCwnU/5oKs3otCGDIY8NBh32M7hBErQhp3Mq73QKvF/iuYiPDJ0VpIKLgyuCut1BFEx6g0Gf1x/xejzpVCrg9Yher4fnuABuABbXEItGzYyJQgHFnglmcCbDSA1p2SPIQBc929A0cBYjVTEle1U7U6I4ZPcGvQe8h700qHN6cw7LXIPMb0MjKW7gxW7OXAKgfFFl4Vo7hyhuInD1AY4GdpLuzp4xz91Tc+1dAEfE51RP+zUfD7pNOHG2rIU5QNeX6jPKD9mdSzNuZekPd7op05C//7zclQX/f8LA/6mrvdrIdnaSR5U+DgYyNdaQRzUwDKNTntDpojrdzf17u35F/FDlFdKehq79SmMUj6MHT9OGXw16PME1Kz8Ovo+WVt4apBa6T1yC4Dr20mAfLcVz+h8m7HTRwH76bPopiG33qzc2iChLlSBK1+mdDudU16XiJc4rMwvEa50L3Btd5hZfc26sc2zzDNeM4lzXFcXbfKuy5nyjPeSNIEpnqnO6WppC0YDdRul4S3SjwsdbLD+hA3GlRUdjhamTTReGZdnT7pXtjcHGbGOpkW6U2pYurAqnCjRA/sf394NUSiViMeSnijJttagFPFCb5oGocest541bHzvngmlbKd/AoQ2cSG0bOET5Bw5tcjpdPrezRgemo3IXBdIepAM12Eho0EB+YIgCsBiKggiKZHTFYoGHEd1esnQugXNh/dTr7r1oqiqfnvAhduO8dZM4B+9Uzn3ryhmzzpq1rOm2j5bupoMdRAx/C3rc3smnTVeCDRNmnzlt5XOVv8+a7XByruzMctR71rqfnb/uB4hsiyDfqqe/DzbsB3W3quGfmpdZ7uCXCcvEuxzLg8tDd4bvTtyZXJ6yWupRIpT0hUnxj1mV2BTGo0wuP7E5iydJeTx+yu8yYdIv6pMaWfObuIw9GHA6/QGXSQkwDA6YcEy225HdHrJjuyeTDgAVBWlDuNiwHbUh0zDi18L/cpcWaUAkpjUE8/8VEQYvUAilzI46u81utVvstEGOJ+L18WScNgi8yGNDOJ4yxzIo5IhmUNyuZFCED2ZqZAHgPlVjcYD5cW7QEJqcLvghcjMOW0O4qbkZJETEKEfDyD9aM4Odc5/JTEz6r7ltzo8rnWTkIdQ4d2tZip0eu+ucytuTq3YwrXX23PFXXrfkiwtOJ8Zw529n/XzCiOmT0mPAHqaBPLIgjyLiVc/s4HzDIoOOs9QpPO+3RHzBYjTq9+kYA2BNtz1QIkc1bZdKhqkYkFH0uBRB8HsKGaLguFEpFv2ZRAPxtjilyLK/AdzdPLXTg5FsicZkT5GS4wGKsniwxRSR7T70mW/Ah32n6WSKQZOYNcxu5gBzmNEzRVnOUA1sA27oAVR0xuMxAE7mXCHLf8Yf5nW81Dx2vrsmub7+TgCxIwTN2HJX3xF4gDmBmPpJJqJfuwPRBoL3ZXlP59AJGfuSHKCrKINPDI2TMAdCnJoRcYNyGJISp5lVsRgevqY2gqbg28myH7+ISKSri7S6a8lI/2OowV2FJDcuVoIallU2DiNWZT8Zeasybrb2zKeknQ1SugqkNB+kNAq9pFr5XzmfznY7d2TpqmOz2JSaP/OEND/F+pFfCfv9obDfk27Shqgsyibz2WxT3p/uPJ0MsfZSsIRLyqhS6fRR/s6q17MYlJrTq7o8izNZ83hKXHsfez2qV2L19fGYX+kokqFRQP1blUJra7Hg74hGAhAnMVKTnE4rIdkTlxWl6uE6OzrM4P7ygVghEBsFEU5h9ahnRuHlo/aPwqN68HbVewYfCIe5QA6reAXWTcS7Mbbj2Xg+1uHn8HbqP0jhltLibhAwSe6AoJVOjWUQOXcSv9apIWgnwdC2LNGHIXMtn2S85VNM+bs6/+pVp76H5t5Gkfp6FoyEsYslpwpNFkxmS50AHWgIqZuOwtwprm5QqQaZERf+1sipzvGW/j9qilXZp+lIgbjBrzV9ww0LIFQIfk1GCrMHr5GCC3BzJXCyg9RU7my0cfD8uHPwedC5DyEi/xvoXJB6V23I0hl91BqyhcSQI+vLBkbq89acmHOUfKXABP0oqyqqjnG+if6JAQfZZQOaY23WEhagSUGt72umfL4g5ZeqqG3RN9dQ282TfsLRzDkcPOd3B2WJlyU3xrLJLjOMiVAmbiKLWCl01373EFoTqYOwidT7/h1R/jNpfSuDER6CYDKMf3ZKFuMAOeJ7SUuPHF6s4cUkDMMNtvoirFsrblVLH/gPBvCZ1NjWF6nd1B/RXt/v/Uepo+io3xynEv5EQG4d7Tvf90Rga2APtQft8X+CPvbbpgUQsnL86VMgKj6wiZxYtTUSVhNfFgRflhTsdl7wW4OaVbJUZFIER5JyJBKX/cGsZpeWpnwzxOHN/qxFr/VNedpk0tN+i9dRfTM3sruDbuxOim63Q/R7M/VVqFAmKVhJJhSlPuHP9Az8RPX5ERXy+f0BhEVE2kArRQX8ARGGIOryq5ZAXA4GAwGfX0akP9bn87a2YJ1D9uJMNtEsZ7MWi5UWZKtJTrS2+gMBf0tzAIKft1EwMTsxP/FMYkdCn1ATyUJC5Yv2xPLE7sSBxGEY68Hvqw5/EM1GeDl6m/xJFdrnozGmgQssVJ1CSEeLdGCi8LawX/hMoAWp7aWaYxgPINHpkdg+N9eWrd7LXdAtK0qXmz3oISRYG2VBlzRXoXmKzhJxJ1qnTxsD/SL8GIjxUhMQZD0QZcX93ajQ9f8HLfAykv1B13SVqS4URd+y+CFEQOi7QIGL4l9eWHmefUgz+jdIO7pI2t+hkajtdxognEnayi6IToIP8Wg23n+qGven8Z6TsUD3CWg1kBZ6CWh1Gs1XnSaMGJ/kw69iZEEGrxc5vbSF07SsLsnX1XFAHuJKVZvAYSTT9fVK2h8309olxrzOaKR14K5ErQ8cwuUSgUbEAqQfCef94XDA7495MeJRwOcVQZ2QlxIUOR4PyLEYAMhNm72i7PVgiMJuUs3IYjYjk98XQMCsVS9FpdV40Z6emJ6dnp9ent6fNqQ9GawL8F5yucDPFuYLy4XDAm0XkCA1tF81xMi7CJ9gq1xQgSD2YBVoOmtA08kO0sK2pRkFwF61I5NYX0Ii54OG9ZYIr5uuBVH/Z1D6tkPReHw4ir5bF04gjZpK0Hhe/30PVWVM2jM1J7EPz3uIuADUrOkE7To+4pRI6SPdy8MYhqlukPYMkHaUaqAOq27aQ3uNASooePlg3Fv0nuHdqphTfKJn4FOVvd5zqwcnTCnTSs99QTyI/koN/f852jc6lBrapzWsj1KBOG+PlWI4FnMD5CfjwA19nmwDQD8rZY4Oh0yDRJ3w9E4Sw1KaFGKqhS/FwOtCY7ETPzu9VsP7990BSaQSKn6qW8ifvMhaRjWu8fECoeLrq06i4h1me+jjp/4yumncpPapla+RtfzIuCd/XHkHHahcd/Kqv7nsnB/HWz3C5PNuHDnnl2Tdr4AQ/gqITjNUO3pdnb1UuT13Z+EBZVXhifrHUo9mTPzcxivz2JzQKd6EqIgNMjU2N6owqnlM27j2cuyC+NREOXdefkrh/JYZbTPbL1Euaby8cGHL07lHCmtans9tzm8orG/Z2v6K8koukrO29Ax8tbndnDPFyOmRDY2mPBzU6Yo1YUo2JNuK9aVUe0N725jYaOXu2E8Styi3Zm7NLWt+KPZQYqWyInNfblXzWuox5Y/K39q+yR0tHG3+pt3X3NLWThfyOV1ahiCZCkQjYjQa8V8mxo1gnFM3WC4z9qBlqqCLu1qB9DfFk66kLsrUXZamelB5A+oLERN2F7NxKs2mQ+lcek1an76hGJeljlE3DakBkP5yH3u0v5eU+EpZEq+x/b3PGsgXH7ZSxoEXNzBsQZneK33ohnENv+t+uFMLp11tVWEP3lAX1UV06Mxop2QvZS4J8CWlHpqM2ceVmgPQFEjTLHrZUoE0zQG4rll01UEXmmbRaYMzaBTRxmkAcMJGM6B7Zb2xlvwdiri1nHw1HK8mfltkXGQhKKc4lhIKOBrBWozO42sWnNc8bUpnuH20z8q7zI6xrc2pe89oPOvSESLDuV3bH/8MFXftQsXK7r98+vyzx5Bx7fOfhidzIVeWdwl2izskNVs5Tu8WRXZpEo39GNnRtMoTlc8rX1Yex5e8hc6svL7vk8q76AyyhRqsvlOz+p+qKTtjLbJgwBAENpMgEJv0RQQGLEjOZggOpSgPPgSDrUo9aP5mluUgrgMJz1dDrC/ru9D3to+2+0q+ib7ZvgW+5b5nfPt9Jt/f4sQ7kzj7iOZsq/XZ/lNjr1MjsW8D4GD4NXyCV7yncbV/kPa9yhPE1HRPETM7mapV/kpwEd1QWaYdo2QTMXzuF+BzK+hmNWGkjO4cdbZ7rHKh/x52t/9r99eK+QnqCT9W3AwLnExrcc/AxxsZ7vQpCE42kROrWI292LyDZUWH3+pwRlJkyEfJC2RMyax8obxbpmU5CZFxSvFHFMqiBV3u+UZEqq7zjeAXk9hohPjLglFYIk+O8fvzbr9fcvvDbpcD6E8AFsLpdLgVMC6XW3S53C5nSo5IcliUrTrZEgmHrVYLJn+hUEGKnHNPcq93H3bTbhJIW1xYzjpmO3Y4dA7odw+4kGsbuoVy4t3daS1reMltEGEdLB8pk/iqr6zJZ5AGkZ9sdpAM/ZNk4anJQI0M/csBwno03tNVBj8HgqxWqgBptVpVNIry/2wUr72+Mv00l2iziS7U5hZsdYLrV+h2A1qyxi1Cx41aq0eVHsk4rFYHU22PO3WfnNgHlUXP6fp1vL4RtCCsWikja7zQuMC42Kg3Poe+oOwUjf5BWbN9VLavDNN0DWbdayUdbDvk1Em83XVIglbvf1PSW3hJfBNiZgnwfMXAfnqqbjFVTzWji9VznjQ+Gnwyo5ON8WAHfZ1wg+f73sXibZ57xPs864xrxEc9T2c3GZ+re1bc6Nka2FV3pNFhRhJKId2D3L0efHPmzsxDmSfr1mVebnyn8cNGU32kBz+teuLZcDweCUfqeb/gSjaHqeYk0uWtTLq5Bx1QL0B31FPmfFhnYcIEUhekdelkh9VaL/6CDfuN5AkbFQqFVZuzZA+jbLgUnhieHV4dfia8I7w/bAp7Wl3Lc2EDeX6+YbVhh2G/gTZILantw2lMpIzvPzihmmKuxmaDZZNsGc5KnUe0kpqruq+BlNZOrSiPWy/Vcps7AL2/ogoDh6kiPKSBI928KWOqZTaBDtXSoCJcup0KwCXCwIvkma4yKoeLtVonwIWrVgsZLElXUzQ1HNHJ2nNgSSQPqpu2ZfcDTx54t/2OiYsXX/xsiGFd5ro5v5i0esMCghEvd9w6ZsvlE2645urtcxY+uGr+TZvt7B1nXNZmdvOc2e5JPTynf49WcftPjp3Yce7ZV5w/m/jyBpD9+fRHlA8ocOxZm0BkZWGzIssKYsTmc5K+IGUdkuR0RHwBow5ZQrK1bOlBczbJYSYUBjSdo6Z0PojDjYzFH7bDymODJxWdTFlDDpGUCezifHG/qBOl5KyfnigOIoTeQZpUKnVKbK8bjFfqdfcSCcDjX5X3x6231oShTp7LoJwlFxtdP7X+kvpfR9bGtqCtlucCmxM79btMe+h9pl79JybOSTeiJv0Iyyg00TImMBVN0ZeNZcsl6DL9PMv1+GbzzYGFwWWBbcHnI5viToDMwxssbH3PwCfPBpzVAnYZdU1HHMiIAr8H5uWInsK9kFYorQoMpX7+bg8yVP6xad/Kl0/Isf3yvXvueY886I/6//hK5cuXdlYOv7JW22owUqt3v7b6r39dDQ+y3wCkMw4sM0Ud3hQ2A2V09AwcVdNw8qpjX/zPiQPBA+G/xz9JGGOOhPM/QuPj4xNTQuX4BYm59rnSlfFlktVJSt3XCuJ0YarjqvhliaMevQHCTYcnySb5uOdO9iH2fvd9nrWOtXBtVOY5uyR6tbqB5HORmgFnoe7gwkmjpZs2+P7TFY5a6jpM09cE0Yrgi0Ec9KTFsEyEvEZGdjkor5B1sqTsPEHOYG1aAaHcNf5IdVMB/PTWygfDpQNtTxlFqoqAsmT7wGBhoLopSx5e2CF+Eo1QxQLwD93LJFWJtGqA4Zl7t7/0pycv3nWug+Vclz7y2q7KMWTZ9VudzUes5IWgx+UdvfiTBx7Zc9Yk0cUpp1+FdK/uQlZiCz+C1V5HdsnDer+/eUzqihQmgcHTEB/qkT6rxQYRU8BNhlhv1uX1ul2RgNkZqWfKZjCD7vowrDeYQygSFgOU1SIayVd+XEEmtJjsH0fIk46HF7OI7UF3dSupxYP1r67a+vSTiF4rsoAn64X7EWIH3x2INebGrXfWjKC7zsSbCMQM28VWKjVwaENITGwDrJIHPuqOmmLSEEYN0ZWohke1zReuQVUWTlBlGlch5p73r/n9woW/v3bf/Vp/wd777t+79/779tIfHbuaYMvjry08cMON+296Db1X1eQ1+/atIZqMqcWwtlnQZIkKUbvVK83OVQ7chE/H5+I5+BX8ivCG9B7/nrTP+//cHwa/cdokX8pXwK2Bsd6zgzO9FwTne+cFf+S9y7vKtyqwRW+/3rnNt1O3k3/d93rAYHqZ84RC4CM5f9hlpMOcxTrZ07GGQgvAgnrQh6orEupAHWtENF/cIb4NUESLUjj1mxNUdHyfVnrsq5bSa1nZvpNAZoNTNAAkbPSKwQDwqkNDUI/gHnY6TylVVTWTMmp6a6Qbjj/h/PDXs353mlDHutncl0v2VvYj+2u/Q+bzpXdWrtzjQQ8/8urIvF3iOLbpfOR9fQsgx/8s+cnTv7mbZOveBe53AWhmgdqlxlXrJP1i/S3WJY1rrBusG5WXlD2K2WUCKvway0aYQoZqRI09mN5MUZEMEOIepKoeBJobq49Q8XIy7KcoPiRlGtwGxmSOgC6q5mYqjUKetzXVvE+1ZR2qY4Fjt4N2SMXrt6I3qVqySitfdLIHNcLVSWLXfm3LAXjKKguuHsuDJ4QWj1qo1qUULwg0HaQUbzKICOVbsuTbmc3hjEFtI8rw3gGDwzGY7swiDUf755N212bSbv7NT29Ymne4RZPwwBXfuwEt04DW1j96kFDjrUQfF839hdPk5HmXzjXvjEVkhFj9Dys/on8Empmg8iigNp4hLhDxvvAf44fCvfFj4SMxw1XJqxvmZOfkb7L9INmVvyu5OP9w8mf5dck1+W2BOmwiaHCxBhCMXm9iIpgKKI3uEOsKgSzrAisbwyGzEqZWykZTBzYgA6r3h1DIbGaZNcx6RmdnJjKzmWeYtxk94ylmwoujK6Jrouuj9I7o29ED0cNROioVUhedpKwaWpDNCyAMsiu31EsgtZpqPhkxyqe4yu2Ud+AI5YE4OmVqgsh6Q8BEkag6bcqRQ9KaJ4MNziy4vdYTblXmgopDST3RWIejwzuEWpqLBEVwscDnm06EDt2Squ+LuRfMHK9Vij4fe0PCufSdp44de+qdpbvuvvuNN+6+exd+7UENMbZOPj09qx7iITc6e0zqtONbEdq0CVGVcfe++dbKe996C2xhCtjC1WALregatWGV51gI08iBLjFcb1iB7sVr0KN4PerG5rWGx4wb9ZuMrxj3Gvd7jB4T59Jw2y4GRSzOhFDT5Y5wyaxGeNIzc+l0NhdJsuYq3tuQbSZjs5mZCFvlr5b4zBp/bW0i/Wgx21gsNjVGWhEpANPJ+noQdytFG1mziQlJ+90I/MQjqqWdCocad+TezuFcD/p7d9voi4Z2PRCQ0SyqBvlaAMN9J+D/u7UheGowxYAGXiT7oYDLHNjAeQqUokzXDJL1ePVGQ9yrl4LIY/RVTZJs1hu3nh9yHoaBI5tC1qBYZT/TUZnoAKdt8hnmqEOmW+Wxxu9KAqJzJ62ccfGymbOCkhSsfEbcx6xbrp95WnbeiUVEzbKBFx07f/QZyyf2/2PIfnUzbmoI3dB/aGhXpkaVwHqfB21w6jlKBwx2kZqKSE2SKp0rzZGuk26VjIKNnSYCjzVYmWl6fcTq9En3OYDH6l7GPejezT6DzWomf6l/tvafdw+odTStDzkmikiU/OcsGi7jsP2alDpLR/tOAroTcQ7MwxEtCt+q1tQWAK/4wSI0lnzufreWfRv7JUlv67k//7lyzvEvTkAq4DIE83fAJ1sJel7EPVupJAjSaSslSYVbtGpHdSJvKV0uPCbgnQWUElPxTDJVqC+2xUrxEclSYa44N2q5TEBRoVnAijgx+ef4nwuH4ocKx+LHCqb2eHthbmxucZ24LmqIFaNRqgpkliEU8xG130gFUTBIfqmVLQW1rTzAPYMzo8FgJBrxRamGvGYvudyZhVwuX4g0FIqcRXujuqy5rs5ijnCkkAMxRLWK416llXEiXlFIy2R8dDI5M55MyvFIOh6Lx2KhYkEsFgtRUeCFEBUVyX9hEYoxUR9FkQ6fz9HhNcgd6XxHQ0M6jS0dPEeZOhA2iySIZOZDcP5gPDaluA2toeIwYltQWFzAoUKucGFBVyD26G8RwPsB/i5gFjOYZUJMDk4IEhsYqXk7epj8l3CSX9CgtrNKycgp2Wx3pKxtTKrWcKuFvVqm3dW2lNZS7Vsh0tvTHegsCT1w9LVUj1JT9ehq0I4bxPpS9Tuh09FS/Q93Lq2rlWz+dZ7iVJP/7mvBmL91ubGO7ewcBAZh4EC3J1Yg31rvtnMFgQAEHMmkACHQiRwyChxSNMW3kT+2OXC0CgVdZUJ84Aq4alLtqq+641IhNLSzh2QYhxL/w56dQ6fUAtCpO6oQeu6EcOlldKmimYuNmM5FlR60+iKtcHCYjHZUHvhf9r4EvK3qSvje97TvelosybL0JDveonhP7ETGkS3bsRPHNl6SOBBAtuRYiW05skwIMKwdSillCAXKVn5K6UbTAAHakEJhKKWUsg1QWmgLNH9gWsqS0pS2U+LMufddyZKylPJ/M9/M/9nXuufc/dxzzzl3efdJ+Nz5q7I2T/+BA0SBCD7//vxI5mrVLGjU90GjrKBRDrQl1DBqm7VdboPpV7eJrJpgnbSJrJEEh+0Gs9nvQLA0Qlg0m0x9pkdNvMnpzLYH9Ar6ye3ASW3A7lwL8CGxAOnFc5ZZA1pt5BYhrEo6ucpQs7HR2GRYaVxlbDaeZgwZw8YOtVCqW6F7oHBfQFaGV2Bu2D2qHHWnlCm3fIWyzt2h7HAPK+U1qsbTqH6+sQqv6mxZteq0Fn+jzUiiPKKA+4UXhDeFw4IMCSYhJPBCp0EQjAa/bYmXTpXIb/Jz/k6P3+/1+JesqJEi6031XH1ndX19TbV/RWeIRMbeCONw5+pwOLTav6xa4SmtWlZe5FZgZWVjKIg6FZU+3uVTq3ll44oVS5bYNHqDWGAPeZfX2C+xc/aPS4s8YlkpCZdeUsqVftyCqsXVLeQoB7U82vJ8C9/iXFP5HUfWqQEgS5szIHO1gj1qN7MzHGEl+hR3JLbkPRzNmk4VxArT6TR/WmXzqlhe4XBqdDK5dkmFrMyL5QqnpsCLy+WVXuzQucg8y27RkjvYaMsWmHALmaa1kq/xfR/J4KM89hq09RpM3y+lV194BzUuSkKBq4XedAJIKNkHkFKAt1hs9EyJ7uMWpuhis3R9OzecNVfnK+lvt0+2jvqaZledsWINvcF1a2991XhrJ0X7apcFTgvT6IP0OR1F+dHh2Y7Ozo5gz+ajDxJp5r4UGuqIHX2J4rvDG4sqolJgYTkOUj4JUr4RpLwJfzbU+DPFz1TcE4onVNxXVfsU+1T8DuUlSm5MGVVFC/lbC7+m4C7w3o8f4Hi3d5uXQ1jGcR7QV2lVZ/PaOFun02ZzOP1C/qpOmpIMyIANnWxWklZ1JrTEtITLW9rpl3dKS7u6YJMCH8BvIhH29JYin0wJqzxBMGvUGtH1hhM7yYRiogu8a2vugAWek6zuFhYNbG0nCefRIzBZ/OP3d/7RlZ210C1XKVUKFadwy0HgClVF0uqukq7u0sK2z2uFoq/fV2iVxGsHOdvasWULrGFWsK3XcdKRK0XHLfA2brpm5Jy+pjOoPPyGPta9bGrw/B3Z6zsmKxePtFd4Pt999IOF9d3IBeF/PvqHPAGB9d3uY2/ImkFCtKgAd4WaBLvMbi2w8z/BP9H+jPul/NfKn2kV25VxMxfjYrK4Kq7Zpp80xyzjBSqbjzf61LxWrdT5EL0Z6FxNoaGAwpDetvxe8hNKNegcWP7t5z4bcgg+RYjcGwxBnoTiUcXzijcVhxVyxX588H4HmKD0yh0mt/eObtlBFs3k6JLYnZyrr99HdthmWY8decBkNVgLDhw7CDPuwfv1HrNnYUe1hUyj9KGe1k4eyluJZyYHfBajZ7XWCp5KA56SeGbyQlARrPiUVq0AieDZreaCFivxLFajleR4IiQAotHAYk1FPI43epvJl0Xk/o1gcnqZPqHIPudpnn/v8Sfm38fCE49jy/Bv7rjjN+SD73ls/jA2P0pepTv8r7e//saXb3vzDXJ2DDtnor1LUC1eFlpdqzGuLIPP8mWn42Fuiz6KYUwU2/UpfEFlskr7Q8VjmleVr6pfK3u19m3FWxqVkw/wFyiv5m/m9/AKu5uqrLO6yOl0F/nt0iylFZ7KmZJa/dVsNsL6impj0OYOgqQaqn1aTYUPf1GmRN7gEkWpz6jCKld9ABlEj7Gor+jsokSRrMhZl338TJd26cPn95rpFvpEO+hTP4/PPiAq19UcIN9dDqO+VKcXMRn12mO/vq+sODPmdMTJ4aaNbaPoMfJJVSrnNHndnrkLX5ydP/rIb65+hqpUIutQ+csv3XTzyy/f/KWX+dGbzzgz9Xzywflj35tXEH2iDxeDdEEU3/38C9fufuF56U022WZ+J1gGW8h6oQEH1H2abcIu4XPCjYovW5RuadPrfYqt9AttB7i9sDAOhdRsAU+uWu4N9ZX30nuW/qVag5V+gatcqccWZDWYNCVLgmipQrPaBIYT1u1k+V6oMSoPKzmlaxmyiiXG4v5i6bjjcLGi2Bk4eo0j65rz2+Sx3nppkf0eefzKbptLs/vKU1x5zgmc0mDC8JnZ8D1osRrsgjs927IRSl9Ll0zfSY6rOO6ur3asu9Rp0RgsxQ3OxlsfxSm6zJsi11l+Si+18KMvXz8cc1lgT1rs2vTt+QY6NIK5gHuYzYXPH3uDnwdtasd/CF1pXe1u5YQeNILi7XvEPY1faXrG8pO21y2v2F9p+WXb7y2HGn7b9rHlSMNf2gStRWGXt6jbvBab3dZS2PZ5/w0N3zdqN1o2N8WbtgXPb7oo+LmmzwW/Zt1n1VwTfNDLna5aWlFcWhs6rbnB5TAalDbdStRQV1Msq1phNOh4DeLNzuBpp/nMvrBmP17+AC9W4ar9+MaQu3SFz4eCyuGVvj7P2Z6Eh/e4OmuHioMVNl+IWFQ72M7QSKICVzg7wkpeUarxac9ip9zkjIO+z7Zl/RG8lNyDkN4oPvoeImO8hdyPNLO32gpWZpZw9CnBSkF6mampsU0Q3UssSwpabF4ULFzpxY0ieEIbBO2rHV5U4Gg5bVVRM8x7rmBzk3eFF1lbzXTZRSZhyWN3H+h8mB79B4LWBo374WP/jgqOvYvaYcvTYm0Ek3u/397sXjgFIzubHVvoSqwJ7LEalqhBK3hNxDo7TDYIgddOzHG7FQxwuxW2y25SD3CGZPoemYSsxMsyxzATnOglCPK6FHHsFNQqvX6XftU+/SpVWWlJqfQwkb9Q2vmQpyBNA5/9Qm+ws+aKe9ojZz/34x9frLLpiSkQnAXFNyfuuuP0gfkfX9nz8hf38kuLQFKv9bjszuayppVLlzeXu40WR/GFXdu/EfNbDS7Pd0B8bVXemtXnt/dWV4sNE82TF5MdynUwMwfJXTv0k1DJ3wqxvtBVyN2leVDzuOYlzSGN/FzDFYYbDF83PKl9RasoUGElsSAynAzZVDKZUuXHJqvaZiZf622VO3UV+/FXQ2ZPsKREGcQYKXQ+p9Z6pWw//lbIGgio1GKp70nkNrlF94z7UbccZou37l9GNgXkvW96KH2EHt7Tu29H35MeKx33ZoR0Gu0q1Gi1LrUXaQp1XiSdRtOHe1twWsPN1vwD/dLluafTdhssDZ+ihrhpbsfwk41WvcmhF/+844t76c3GW8lg8KNEuY/+W/dovagnbxH71l81x1WTSHqrnvDxDODjCD+KysAS6zSyB+1cuR27VEY1tcC6apVOp1b5jdJjJ21hL3vsVOYj4WXkJcFOsaTEJ/rLsN1oFX1BVKYpcAS9Ho9RpQ6ajAqrj9eKIkIFdrJeVVeYzKLqeSVWkuPI8vzjyOZm6YW4ZumuqXQ77bgz5b9nbkMaHCLGVsw5dBQsMoV8iUVm9iJBYZU4L6mhhanhI8gG6meHiVM4dpA9X6GPy8uy2E/HpnEhmH5afsWepy4IDUqnBhO9z36bDsMHdMl5wW3hTXOchw7GFwa2PSyh0qkbGYMg+YYsGINifGmo+dv428IeCy9qRK1ILpMbRKMIq/wgbhJWWca5rea4NV58D2S62yKEvLj4uAs3pvSFG0DIyw97QzY90pv01Xpe30tfgvBrzII0xQIvvDjrQI284bCXvNd3Jn3Fwa/msHSAttohnaD1Zg7QzBzGomC2wo7EWoyQaLFaLRarRcBIw47KCk1BDR/UqBXFQet+vC2ktXDBavNq8z1m3nwAb0MWrA7pQwKuERLCHcILgkx4BN8DErUE+6RDMHLw9Ta9ZSO9kceulq5uPuUFmy1/53W7E4Qz92sQu2GTc0RUnx/D3XvN/Dc20EMU+mbX53HDElx1NY1oJifMw7yevsJCBnyNtJtIn6zEYKy3wViHuetCN3jNXoETmswbzVwh2Qt4/efgKSHhSxSfE/4h/qHpOeE53zPFz9Q93vB42KhCDnSTn0d1WAibhXCxyV9s8jXU12FfQ12xSTCJuM6KcV1DWBAE0ddg9fkauCAOGoMwDJagEPQFxaCrNlgXLAkWByvbguHg8mBDMBgKh1c3Na0uLi6rqipbPSJv2I+rHhDDt6w2kUPNQozlOp/PrtPJkR3b7UX4FqM8Iefkro46SL+/+JYygebz3VI2YiyqZstdeZGzXaNxaSoVQcXbB7Ay80p5ehI+5DzieM9pAo/Mw871hxzknirMwE5y35wMDaQecr3nMB0ikSSCQRdymN6DvzxP/ll2ACoce5oceArswBPgnvut5QR+dL9QTOBBsgcD+Pq+wuYWNgkyWSLboWLTCihvCkBhUwhKmjRQzOSBMiYPTLYmf6YULWaEP8nsPGh26I0N9aB7+wBKhkc6q6SE1R87GFLDFsrsgd1TPXkZfC0gZo29oMUMCtkSbvUIqzHxwo1u82pMvHBjoQkw8MJWp3E1Jp5PUyS2NBjBq7M6C1tMZM6vI5M8QIHBMOzG7jdZyQnNEyE9IMXN4PmIl3v3kl3ATC8EsHR7LOs0NGdzAJsCLD2rz7x0g9PKwb45oZi7A19aajW6vPMfklXo5+cfmv8+VY35Dzwuo6UUXzp/d4kF0t8imhLFhbgoSg4i3yKpJfhH8/+itOvZsenK+R9Le3K9XQmL4i4VTSF7iQ+wWdIqnV0FWnUD7AVvAq2qA1FsdSCH4PAv1fsKluPl5j59qOBvlr/6tWrLOsta/wSeMJ9nOc9/peVK/0PmRywH/E/6f+43+B1qY9twMfURNaMGyYyGjDQKYaFOMNdZJIPq0eurM5a00O+5xIM9N/s9sDks9BcvrSWPLqpq6LK1IKStq6qqrfMvrbOopdsccvnN0l0ONUbkdj9Y4YKaAlxQTW/4+12WusoSEjtVVlZdXFZWUuyvLPZb6upE6ZqwGbQbwRZasCBcBwmCGSOVRy6oid0tLLQGXS5QeI7Y3ZJgZW1w6dJKA/L0e7gZz5uew2TR3NAvx0hukovyGfmb8sNyhdxZX3mAGl26Oz20ZQdsf3Zk9j9Zlpddmfmsqoo+MCAq83eeG3xSa5wOmvJzK1WmZlUzXrgCidNf1XFSEcw70/dxk/PnOz0uvc3+Nt204o14gE7Ub3ldJmvV0Xcvp/LppgZcCbZb0NvU1Hj3cfdJYgYC+Lcfpfez6Ngx6UaJvJYrRV3012S+gGEO/B73aNmxMq6sYP+x6ANdSzlccoC7GlUAW8liY8vyE5QLI4TcIR13L6ykCm4jZcpzyyCME/if+bP4FNKiuocQz6n3qZVoP24NCc8rsFHRpyBXDu9QyBVOXddD+CJ2W2IH+z4gbF2478efdd34+O7d41t3c/+0dffurYCT253f54/yZnktMtPbnbyJP4ef4S/h5Ty53alDRvxnpMjc7kx/VUpj+os4uL+8ZzeZnWrTuwUEyH79jNUpaExGCszkq6e2o82yc2S9SImMqAB5URmqRo1oNVpDfy37bLQVJdBOdDF6KjQ2Mdk/NHTmpvMubGqeSZUHzomW9HTpVO0hGf05bLdY0hwoKQk085vcDTVWk8nh7l17bjI5Ot7ZdtH5K+qmtwn2gQ2cYlXLBnD+szZ7XJvP37Z587bz+XG/xlBZVVXqH0fVrz+7svrZF54lklxdXW164VnTs7CjB+xZgmZ/aD5cLUHTc1L+vMzH5Sc8L/aTH54pY9DCYAGD6XRlXjgf5qfnh5fk1Z9uj3+1pqGh5nri/bm+tr62hGDzjXXw95362tp6boD4R10kgrs8k/fo3pqGujqaGT9F0ubPJP6fSebrCcbfCF4NhOZ/Xl9f+wYE8JcA2UAquwA8/Ehd9fKjXYDdUFPTwIks07wSkN+SYq821DRUASJ9NWMjc7vRWwsON+MvUvdD/GuO50bAvc4fkO0mTv4d5g5nO6UA7kXVLeop4jTf0IYlp9ur/5r+a4aI8Q7iTLB9MxeewHULayx2y7PWC2wu21P2Owq+4bA6rM5HXJbCK9xfKop5wp6wVydGfSrf0/7H/I+VbF9y1yd0jy157ZO7Uk2WW7XoFt2iW3SLbtEtukW36Bbdolt0i27RLbpFt+gW3aL7n+7KOhbdolt0i27RLbpFt+j++x1CaBX3A/JDePSX7FzSj+LRHwO20xDBOWTgrmQ4j0LcjQyXZeWRIwf3CsMVyM29z3Alms7kUaEa3sFwNXLLyxmuNyjk7eTnh8kf1lvWMhwjrXUjwzmktF7DcB6J1hsYLsvKI0c664MMVyCD9V8ZrkSNmTwq5LCcznA15Hme4Xolb/011IxlPLSlK3yT4uQ30UyFhymuIPHkq4QAV5J4t47iKoq7Ka4GQj3kljrFJR5KuMRDCZd4KOGyrDwSDyVc4qGESzyUcImHEi7xUML1Boc7QHFNFv1aQltlO8V1WfEGglcOUZz8+JehMkpxC+BCZZLi1qz8NsoHCbdnxTtp2c9QvJC2JdVZlJXHm4WX0PzXUbyS4ndQfBnF9xJclUW/KqstXVa8Lt2XbyER1aEaVIsaARtCEygGcD1KoGn4pNAuNENjwhBKAk78CMTHaY4qSGlFk+BENABxW6F8Cs3SUAxgDHKfC36U5tSD64LQKMTG0E5Evgef1D4N7abb6YHad0Hdc1CPCPUmoM44GgN8DPAZSEtm2hEz1NegesBKM6FGFKA0RKCGGcgrQrsRaIfUMYa2s7xrITQBsSR1DmiczfSJ8CFO+zF5UnrGKS9E1AbhUUghsRHKidw+SvUkWE9F2socpI7R/pLQONS9E8omacwc5IpSzokQnx6PbqCJcCdOy01T3gZp+RjNEUNT0CbhdJT6IqMonVek8bMQQ/g3kxnBhX6Q9BRQEYeSs8CFMKMzzmjpzelPhFJHZCFK2ybUb6f9HP9UckTkZSu0N0lryi+36qTUlEPeOO1VIsPLCrSB5prN9HEFtLASZCO3FqmOfjSIyK8f//dqgoZ+FrXhf4s2dNE7dIQqUts6mpqCtBiV1nwJJJTMQb0ztF2JgnHaQopydIT2WqR6s4v2UqIqleF0OjeJS9DxJvwg8hajoxml+WbYiASoRk7TdmZon6SyY6yWGAtHaN0zlOopyJWiaaTUKKUjzeF8bqVYCWnsksfFjGf6EMiEF0breO7M0HAUyoxBOMBGjmiI1G4g005+D+J0lHZSPo1RWT4Rz3aynsaplE9SeU7rXj7vSZlJipVD/ooc6Tlx7RINn5a32bJJatoKcUkqjSk6cmMZaTxRD9KtH09XMEsGSE+kvqRoe2lrlaTyvIvKD5HnaarDkZP2VJK9SI5USbqYYL7UKwknVmGG2QZCbXo00/WQnMQCnUpGJTs6zUZmofa0hsQZl5PUWsXpbwWn2NiS9UXabpM+TNLe7cxwOVeqA3RkIhSPMjk43sbka0I5tbWkn6tQNbgYtZGkje3UksToqEYgjnBoK+RIp1WzOs/Os1sVTHsXrMVshmNpav6RmeETWmLRnVdHT7oOsSgjzdsgThqntNTE6Cw2ySz4gnSfanZJS+XJZxgycv0ZzZnNmrml8ZakIMba2kpleZqNe4D2Ocksv2R7iGWIUP5L45yWY0muZtjqQGohAbVKln46IykRtDDD5tuz/4KxyHAoQvtO+BZntj7KdHUMap9iOrKw6iAtxOksNEtlk9F48rEFfDB3joXRrsjiUZTOMpM5dub4Pp6iPmp947RcOveJrVsgz7qleZ9fmnBNsqfZ/U7TtbD+WdCahZkoPYYBau8TtJXxTDiWJSHEbkkjNAu1LcywEtWjlJYYm6nmMmOZbUukMaxmIz5LtWQyQ0Nar3Nl6ZNzNXuGl3qZPdPkyvQCJ3ZSPk59ynFMzwZkfTbNOBPLoiBKfdLmAl+2QY6xrLkjdQp7LFn+KO1BesZblWPFI1BjglqcE694pZV5epZZ4E96JlvgUbZNyS01S22FNFajrN8nnnMjJxnRZKb3s1RKp2ntkhZJM2/2jP5pJSA9v3WhDprahzohtBFmywEa0w1xIljRAUjZAKF2iG2HmDLIMcjSy+hIbaTzUBfkG6ZznFTHAPi9EB6hNq4TiTRMQusgfy/URcp2oE20jQ6obZDmHKB1r4fYHoAdLB8pEYaYYQgTfA21glJ7vVBKWr93szlRonQI4sVMD3Op6qYtpilbD6EBqL+LpbZC3d20PkI/ab+T4r0ZOjsZpa2UR6RmUmcYKOqhIRI7DLAf8g3S9ltpnyVqe2kfOiFd6ksHpYC0XMX6KuUj/NnAUsgYEfp6wC30qpXyoItSs8C/MMB+oJzUvwZSh+gM0Qcl22lPByn3OhjPSG97aGihV9JIhWlvCFcJD9oBXw+fNRneDVBfomUgq7Zc3m2k6Qu5pP61Mj9MOddHQ9JohGloiI4VSQ2wsRyg/chvdSOVxA6aq5X2eDAjIZ1UeiXq09IptdGXRYnUHhnbbFrSUi2eQkekWtLpw2ykj+cL4Xor5QmhazDT8slqBt38llhXU9soDk3ExPWJ6URq10xMDCeSM4lkJBVPTFeJrZOT4kB860RqVhyIzcaS58aiVaJe3xUbTcZ2in0zsekhUqYnsisxlxInE1vjY+JYYmZXkpQRSfU19WIpAY0BcSAyOTMhdkWmxxJj2yF2bWJiWuyai86SloYm4rPiZHY944mk2BYfnYyPRSZF1iLkSUCj4mxiLjkWAzCe2hlJxsS56WgsKaZIP7qHxJ74WGx6NhYUZ2MxMTY1GotGY1FxUooVo7HZsWR8hnSQthGNpSLxydmqMNQZh1p6pXYiYioZicamIsntYmL85DwaiG2dm4wk02mrsqspXx8fSyYIlRUbYslZ0uKKqpV1LAvk6B9cP9SVgC5ExXWxVGoylsyUEGfnZmYm40D4eGI6VSWOJObEqcgucQ66kCLMItFiKiGOJWORVCwgRuOzM8DAgBiZjoozyTikjkGWGMDIrDgTS07FUymobnQXZVSaHSlIAK4m08g4aSFAIGVnhpyZZCI6N5YKiEQMoGyAlEk3EJ8Wd07ExyayKNsJjcanxybnokRm0tQnpid3ieXxCmlYsrJDDaeiVhrF+PRWMRmbTSXjY4T3Cw2Q4pm6gpQD5XFoJRWbIgOVjEOr0cTO6clEJJrLvYjEKhgw6E4CmgJ/LjUDUhiNkW6SPBOxyZlcjoJmTO9i2cmAQIXAn4n4aBxortLribSMJyYnEzsJyYzVAXE0Mgu0JqYzkpoehPKJVGpmVXV1bLpqZ3x7fCYWjUeqEsmt1SRUDTnPZjJdAcNLxWKWEEaqObESnkh5XmQ5ekiOlwibtyWgT4Q1sXNjk6BYlN25akpYmaOoen0/GZxZKs3Qb2BBDEptTUaAM9GAOJ4EpQPpGZuIJLdCnwmPgVcwolBcTIyCsk0TpkSooUjL2SfvBSEoMjubGItHiHxEE2NzUzAiEUmf45PAmXJSY05vxUFmKV6qoBRFY1BhXBqHE+YTd8ZTEyQ6S9wCTNwI9enkyTjIqdQ2qSsp2UpogSoR6WFAnEpE4+MExihDZuagQ7MTVGGh6tE5oryzJJJJCfSwGjo+GwPjCzWQsWZcOiGpksJDk5LSME5TInZOJKZO0UeiBnPJaSAmRiuIJsCiUlq2xcZSaQFbkGMQ/micKt4qScQjo4lzY1kGH0wgURlKD1GymQVJYUmzExHo1WgsR3MjWR1NkuZnUyBMcRgiUF5J0U/FAKJvXR3iYF/n0MbWgQ6xe1DsH+jb0N3e0S6WtQ5CuCwgbuwe6uobHhIhx0Br79CI2NcptvaOiOu6e9sDYsem/oGOwUGxb0DsXt/f090Bcd294Z7h9u7eNWIblOvtg3mlGzQRKh3qE0mDrKrujkFS2fqOgXAXBFvbunu6h0YCYmf3UC+psxMqbRX7WweGusPDPa0DYv/wQH/fYAc03w7V9nb3dg5AKx3rO3qHqqBViBM7NkBAHOxq7emhTbUOA/UDlL5wX//IQPeariGxq6+nvQMi2zqAsta2ng6pKehUuKe1e31AbG9d37qmg5bqg1oGaDZG3cauDhoF7bXCf3iou6+XdCPc1zs0AMEA9HJgKFN0Y/dgR0BsHegeJAzpHOiD6gk7oUQfrQTK9XZItRBWizkjAllIeHiwY4GW9o7WHqhrkBTOzlylh1VLgu6AyG5kmu40RtEurIf9xDYI/47uhdLpg2z3EpXOuflb+Pv4R/hH4fMQf4Dfs3jOvXjO/Q/wdvGc+7/unFt6erh41v2/86xbGr3F8+7F8+7F8+7F8+58a7545p175p3mzuK59+K59+K59/+4c2/QzYU9ZoTOE+nwb+ieM5azB43l7DLpPlPmkdXK1snWyE4DfyXkjoD1I2t1yWZN4HvxV3hEbWgr5E/SO2GkDnbnGqH5YqAJpe8/5/zxiNwuLkH42DF2K1v6Izenuejk9FaG22clvAU+/tbk1HRADO9KTgbENcnY9oDYE0lNtyYjo7BvPy6NHKZJOWjtOmj0XHrfejf4r9Df9/s5tP0L7mqEuS9wNyOeu4W7BfBbuVsBv427DfAvc7cD/n+4w4D/gfsL4H/l5QjzCl6JeF7FqwBX82rANbwOcD1vRhwv8C6IKeQLIcbNuwEv4lcA3sh3Quoafh3E9PAXAH4h/08QfxF/MeCX8EcA/xP/MeBHZUCuDMvIL27w5Ga1TEPuOcv0MhvgdlkB4A4ZtCIrlLkBL5IVA14iKwW8TFYNeI2sFvA6WQPgy2UrAG+UnQZ4iywEeKusG/C1snWA98h6Ae+T9QHeL9sILW6SjQO+VTYJ+JTsAki9UHYx4JfIvgL4nfIyhOXl8qWIlwcUrQgr2hRdiFd0K9YCvk4xCPiQYgjwYcUmwEcUE4DHFdsQp9iu2A4xk4pJwKcUU4BPK84FfKdiJ+Q5T3EexOxSXAL4pYrLIP5yxb8Afq3iSxB/k/J7CCv3K/cjXvmQ8keAP6n8CeBPK38K+DPKFwD/N+WLgL+k/Bngryh/DvgvlAcB/7/Kfwf8t8rfA/6u8o+AH1EeAfxPyj8B/pESRlb5V+XfAP9YeRTwedXTCKt+qvod4lXvaHYjrLlOcwPiNTdq9QhrDVo74rUFWuCDtlxbCfhSbS3gddp6xGkbtG2Ah7XtEN+hXQN4lxb4o+3W9gC+XtsHeL+2H/DTtacDPqAdBHxIOwL4Zp0HYZ1X50W8TtStA7xHtx5xul7dDOA7dDsgPqlLAj6rmwU8pbsH8Ht190Ke+3T3Qcw+3Xch5ns64JLuIT3IpF6vNyFOb9abARf0NsDtepAcfaG+DmLq9fWAN+gfAfwH+l8A/qr+NcjzS/3vIOYd/TsQ83v9+4B/oD8M+B8M4wgbthq2It4wYbgU8MsMlwF+ueGrgN9lABoM+wz7QL9kGb0mvgZ9nXMgPgLaiqwToJtocpLo5nnIjWSdrQOwb1jfMyKihsHedhGFhgfayXyAmH2QE/2lOEYKsG4SziElMjCcWBQjw2VIjUy0fRLG0DZwoGeoS0SOgb71IvKweC2FiPnm7bHkNJqg/nnUv5L6N1H/m+QxGdpP/Sep/zL1D1L/MPXniY/bprZPbcdrqT9A/c3UH6X+NvoOhxKoVQNdWtKv/+ewnPKYoz3/9CER+GdCZiQgC7IiG7KjAuRATuRChTBGRcA1L+TxIT8qBsu9BJXC+q0cdm2VaCnMkMtg1iHWVU9GBKAcqPx7cBB9E+1HT6FfYAW241K8Avfjbfgz+Ha8H7+ID+IPOY4TOD9Xx23gxrnr+atkh2RH5DJ5p3yb/Gn5X1Q9qjNVk6oLVVerblPtUT2selN1WG1Vb1B/Rn29+i71i+qD6g81nEbQ+DV1mjbNgGZUk9RcBpp8p2af5nHNi5qDmg+1nFbQ+kFz20APR7VJ7WXa67R3avdpH9e+qD2o/VDH6QTgNOET+cZdkGRtEqkpppJkvLkqN7x2Ew3LgA924FkpTUG6Jxj8lQT1HIPlWaVhPHquyAoDp04vzQ0PnUup4WDsBVbDBIOXHZdyHYN7j0t5jMFfHZfyvgQNuvwUg8hgy3EpAwzO5HLKcEVWGDgzXJWX/mQu5zbckhf+KCtM6j9EwzzIvBUkksYZAww2MdieW8fIEycaDeP5DH6GwWsZvJ3mdqAVsOLohDXPBnQW7HymYeVzEboCXYNuRLejr6O96LvoB+hJ9BysI15HbyPGM+N+BtlYG19g8HUG32HwLxI0MRkwmRhkHDbVMRhisJ/BcxhMMsioN93E4NcZ/C6DTzL4CwZZ+6Z5CZo1DDpor/1oLaweN9PdcxKdjy5DV6Hr0C3oTnQ32ocOoMfR0+hF9Bo6iN5BH6L/wBzWYAG7sB9X4jq8CrfhtZhJgplRbu5hcDOD2xg8j8ErGbyFQdYD8wMMMk6aX2TwIINHJCgwDgpMEoUSBhkHhTYGhxiMMngug1cxyDgofJPBAww+w+CbDH4kQYuCQQeDTAotzQz2MjiaK42bPLkSbe2iYQVokgv4X4nq0CqWcjWDNzJ4J4P3MsgotD55vE7YmC7Y2hkcoHnUINfkdK4GNaEQ7Bz6Ye8spe9hkMmvjcmN7RUGGddthyVoRwzqGHSdSMfstzF4N4OMYvszNHcQXYg+g65G16Pb0F1oD3oAPYyeQM+gl9Gv0CH0LjqCPsYyrMNW7MYlOIAbcDNuxz14CJ+Jo3gSp/CFMFNcja/Ht+G78B78AH4YP4GfwS/jX+FD+F18BH/MyTgdZ+XcXAkX4Bq4Zq6dY/JoP8TghxIsYHJUwOSowM9gA4OdDDI5Lphk8CIGmaUtYPJb8DCDTH4KmAUoYBx0sPYcdgYrGWR642Dy6mC23cHacVzPIBsxB2vHwdpxsHYcrB0na8dpZbCcQSanTqavTqYXTqYXTqYXztsZZProfIpBNos5WTsupg8upg8upg8u1h/XBgYZ31zM/rpYOy6m/y4mKy7WL9dzDDIJdDG9L2TtFboYzJuDR+Zz9czdnhfekBfOnrlglj1jb+6se8bHueEzDx+vdW7WR/cog9O5ZbZcdYIyzDK7mTy6PzyZPShiElDEOFbE7EIRswtFexk8cCJd9LBx8TD76KlhsDmXD56782jee6LavGze8DLp9bJavQ25o3DWOVlhmO+9l3yKMDpF+Iq88NV54WvywtfmhW/MC9+WF749L3xHXvjOvPBdeeG7c/nhvTc37Ed54ddzw8XfzQ2XXJMXfic3XHp+brhsU174QG64/Lq88Pu54YqHc8OVeeuzpeflhgPZWgXSs+zKvPCh3HBVKLd81W254ep3YZX5W8Bm/lb//7eDfrq4P3J/hGX1R9xH7EyJ4y3kHEmmkCmQlp726GQemRcZZT5ZMTLLymQBZJWXy8vB/JITmELFOkUf8isGFIOojJ69VGgNWhtaph3SbkDLtZu0I6iJnhKsoucDQXoOcBo9AWije/+wYcAwiM6iu/tz6L4+Qnf0o3TfTeZGF9vNV4PP8Vcpasl4yXyZ9HKWXkN2lfzn+M/BZrVGAdZG957ufcSdJHctya0vg70Q0i/VBxCnr9bXwLjn5r6Q5a6D3GZ+Ob8CIWjhKqDjA/5DJJOvkDcilaIKaNIo/pO674GKKjvzvO9PVVdDVYE0TQiUZVU9qqghhtDUqz9WldXGOA4htiHGJcZlHIblsB6Hw9os67KM6zgex3UdxjGMMcRlXOMQx/YYw3II43qM4xKPwxJCiE07HNp1CWFo13GJ43Ed17j2/u73XlW9Quzppp1N9tzzu/e73733u9+977t/efUImcPMbo6aYyzX+j+sd1ge1Z9v/TvrfVZgK7Y5WCHVV0T1Oag+p63P9p+YyzZg+x7z2Lvsf8LvJzM0KNQ1CHC++fO8PdYr1lG6z8zMwfcNgr1/QY586kENjAUXlZKZJ7SIHBF5nJRTqytsSNUkPpsnkpkHEnldfP52IMVB6xFjqxbVaGGu6KI6FTCXnreAcsUW1WphrvgieklIS+bTtF+9iKxncyWekcVnEplGl10+Kh9ljG4MtbtCE90SZtH9oI1uBgvpTtBBt4HL6R7QRbd+HrrL89GtnJ/u4H6Nbt/KDPKz6QaZ0d2xjeqy021mDt1X5tJN4rLsN7LfYBXZX8z+InuN7v4q6X4tQDdrqn4Pro0L3p7X+aiA3K9D7jfEb7CXqQz/WoRF/CavDVJ/yATLuGWciZZ3LO8wyXLTMs1ky88sP0NuXlsW1Zaty+a9vY5pXyRZo/P84FWwxgxePj3tWp2HkQ4tvrakevEcxKPkd+my+c52K0n+rM5ZC8kbcR4x8soRRuHUDG4h5oQSck6dzyUfI/9kWj/qf+02WdTui6Ex1hHSzEOaKdTnJZpcEbOVGBLjJHOtzoPFix4xksGz4HnYxTKxxMgV7jNReCRWZfBuMUmYFZmoZnCxe15QdhD5JnFyGcrgnmSyMAR3WjiXwT/ITMJZcoeFoxkpLZBzBGeiQxncLZDTIWwD2jL4a8BvgFsv1GXw/ZBfDVcOrMtIsSOlgly+UGZMwTmN393BscfwczPSJhE+ZreE8gzuEJ7iLBtms0JhBv8s+KNwfQLL4HcxE06HA6wbuJ2R0o6U4+T2sLGMlG3YX+wl1wgMZKRxe2tkJzJ43N5q4DL6j+wtSi7Zf5n2xsfFNxijcanZ+s+WZIW85HXyf6TVLGGkSmulfVTr53SeHyvqealcasng5jFZ6oYrlLYY+eJj5GbSgHQxgzuL3DvEO9IJqTeDP8pM0iZpk3hdOiB1ZqRgnhcvZGrC/yYmlYi9mZqIByHbLtnFwws02YlRs0sqk9ZncLcyWZwW66V8qSKDv5aZxGG4KvGJVJiRgvaL5eKMJGdw0X6xWywUR8V5I194DDl74Zg4IN7ISJnGWJkTm0RfBncEcmqEcbFGzM3g90NORIwIF4BHGSndGEUnRKe4Scxor7AXJczCAdEsRsU1GSlNGCt34ZqFu6JrQf3V0IrXX5TBVVHHRSEqXBQzWi04MB5PwXmAuxkpIlIswkHMKbPCHWMKxo4Z88S80IIyI8J4Rtooe0nYJGxi1+EfEM4LAxmp5zEOBgRV2C7sz+AfQ10O1iM4oHlzRspu1CVCl33wQ3QrmE6rh7QmNicUCfEMfhVG8xhWgjGUKclIKcdo5jOAymcAISuVJgjaisl0jjY6Rez/+Khjlh9Zfox16ieW61ibblhuMLNl0jLJXrK8a3mXWSw/tfyUvWyZtfwNy7Lcxsi00mi08fLit8TvY9UdEkfYcvFHsB+fOCnOsApxVnyPxeivla+bO8wdbE3Wm1lvss9mr8j2YQ/N/05WveQZYPEZ5Uf6vJKeI75tmIX+g77XK6L+0/phXaofXhJPptrhRDvew7mAa72WtP4cab2OtN7A9xqWUQv2TpYZywx67T3Le/SXIW2eFTCLctm/rnOakNbDWjJ4mxAehNuaweXP+HQGh38fq54dzeAVIORvpiRrwZ4D2sx85DYsred7aJ/LxyqfozaSDuuJx++x+HmjQ9dsfcaOuJHt0LnJJ5LU+uNZ0OLWwJ/0NXaN1lztSf8G7YPnWD/je91pA1dm43A9jN/Bjhj4ItvP+C1vf4aEXraT8fXgRIaEw3BbGf823cEMCWsZv53bmSGhAWOU353XZUjgT7SQdVG/Jvkf7YmiJyxTL2h/nXzSEj03/uS6da2qSFv+ztBB2p/uM/BNOIPF6c1obsk7DClm2IAHu2Tu+H1xTSptKePvRbYUT8kcMScwAjArm7U9JJ2ZzB7zDTNOF2bs7c3HUnzRnGXGqocSovmaeY8h/3nTfRNWPTPWKnNTii+bj5mPmaZM0+DagY2GErtNV0ywUdMDyNptVg1lGswNptMmaGNCOxErSpcyHTInTEeQchkp601PDaVWmnaaS0y7kAYLNc2mUkzmPHOeqdacZcIe1oR9m2kkXcr00BQ1zZswok0tTETsfLoc9J4yOU3XTRj7pk1InTJ1pXvCBMHgq6DumR6mNZRvm3pk7DBMGPemSdOtdAl5TJ4AX+StMF02XTW0aqc8IGP/Jd9GmV7TWYN+taZa+bh8EmljSDvE254qFZX3yFhn5X5Om1pMbYZyTpNTbpC3I/UYUp2mTaYtBh3XyY9kzB5yO9KYSTVF0yXlWdkv35SxE5frUGOhyZnuEXkYzipfkXH2pLeDnphEQ8mz0rx8ir+bJHtQx1n5lmx4CnKn3CmNy/sl7LFkGemdkHMt3TtSnzSIXeospJ6UBw38bgk7cGkU/INyb7oN0l5ZlQ4gZQApO+UDhpQmuUiCPUvHkVIrtxpkbZCww5D2onaLHJc3GcrMS5USznASf5/JI0fSrZIm4Aol9IKEdQPlnIZSF7D3RA9gZwpauisbekPqkXqwb51Daj5Se6RxaS6tCUY6P+M9RMoeqV8aM8hsFM+IsELxJrV9wCCxWqoWD/NTsjiEtD3ScUOpcrFVxOornua01CDtMZTLk/LEWhHWLx5Cap60XmpIl8Se9a6IGUBsBv1A8kuJdEmsRA5xXMScJdagRqvkMaRdoh0zxgDOrqJ4TzIb0k7iTNvNd5X8TR7MbRPiHUPb94n7aN8tgRoUR9O6COfEeuyjaectbhd7xH6DzA3CEXGdgLlIuAoZe8X0rGQSK8QKoU30Cx1IPYPURrHDUDJPqBWz+AkWp15JzBPXi3VpbYSIgBbzXalYbdDEI9zAKVcQaql96dxZ/OSKEqJwTXQY8p9n9xnmPwHzn74Dp7qFY9B4CisuPxkL+g5cK7GbXdHXaFHYLVw3lMGJGzshPhtj/kPsQroUO4S6+RyA+Q+n8h5DqZVsJ3bD/O9yGCXCvnTvCHlCHqvFbpi3GvOfsD1dij3EmXWedjSY/9hDYUO6HGqfYk52nfY+mP/YlFChpy5t3/jL3W3z26lurJUvdtdt3G/rZ3L9/pv3lFbrNyEpeTe2MMcXUjm49C5+h0fS5WdybsjIeVg8ot/2SbTT5HsOfuuwi/K+QTw+QviNSoOBd1CXt1HnJZ/kR7+xW+ot3xD5P6AdYoLx2bld3w9tpLY0Y1fFtWw0cPnJ5SRpneQttfY/4r1ombDMPefOlOf55kffkdGTFdESPmqTe+YvEq+RTjUnMng1rJvGopEXpzulXRk8P87H/PkZefl0mtqY4i21J7pSPcFjf8LSN7BfJ/8b3OfvnZK++w361uj67jHoW6Pru9Ogr8ZroFPhxhRvqfoeztD3j8k/8oFPMT2CtFntS8j98gfMQe9iDvopTmXZNPvYaPbJoRkg92OU5KOOz7z87+9nSI9NxOO7/8OQW6WfcDVuJY0HCWEl22Pg8zHL70OKyDXpKS/uvPM18r/D+DuwErv5Pl9Z+F+0tPix93dkxBvf/15GfN/75lTcyl76RT5rpL92pP/KwrmBp9YFXAsTIHkhJ/JMyZuLyvvFh5RX+yE4axdKf7J7sTqfTC+sEzukSsbf1Yjyt4RXX2KiATwuLICohzWrj64+vvrk6tOrz63u1/0Lqy+vvqrzR1aPg9b4GufG6purZ8C/Df786gerHydYwpywJvIShQlnoiRRlqhIhBLxxNpEVWJjYnNia6I+0aRxNDmJ5kRroj2xJ7E/cShxJHEs0aPzTyXOwJ1PDCQuJq4kriVGNWl6jUaf6tVr1+olX5ejlX3G/wgt/eA2aq0ztMvYon+gLYZadJlaP2hltXo1fTTfoKGe/3picvXxRAhYm7iVmE3c0SU/0yKN/9y/yn20teUC9onc9viX4FmsjlATH4hfjF+JX0M4Gr8OfzI+GuuP34rPxu/E78Wt8YfwL8YrkGczwierxdUWpExyF+tHzlm4i6stmlsgLS3rHsnhUtIyRkHfAucK8g3A8VK3Vtvj91bnI1WTcoel/xb40Vo7wC5Sa/mszaItaGnFr7Zb0l54QTtXHWA1sY2xzbGtsfpYU6w51hrdEWuP7Yntjx2KHYkdi/XETsXOxM7HBmIXY1eAa7HR2PXYZOxWdA3SepBvP/IdQfpkbJaQIc0gq4fkcCkpGchxJ3YP+R8i9UlcjFvi9nh+vCjuivsQriQpt5bYzpW0ountjJxg1lh1rCZWC9TFGlJ0Q2x7Sv7L4inxFOR/G2dZQXxLfAuj6LtiH85xPxZ/zMzidfFt6PCO+A5yTolTLAt1/S3fIwh1QivKWxn/TxEsUkkQgJro4xiOBzFrLC9WGHPGSmJlsYpYKBaPrY1VPbenFvZ6ur94//Ieexh7EitJ9ldsq95jK+OV8UjsDAfJ4+DyOHh55DPiA3VbTC+uU1KfpC6L6ZGIr4tXx2vitfG6eEN8e7wl3kZ6dcT3xg/EO+Nd8e74iXhv/CzS+uKD8Uux0fhQfJjiY/GJ+FR8Oonn3Pl/rJks1EWo0W2gGk7z6xDCHkC1xNqI1xIeiHXAtZDFaLk010CcaqSneUZpaVltJI9LScvYGzsQ64x1GcpW6/V2wz8R6+WOLe0vDAK9PZ1qbbCXYI1eCl2PDgHD0bEUPRbtM9SyZPvPnFOCsPtV86seROPw53W/KRqPNketoPKihZwXzQttiTqjZsTNyPGY59Ic8jXzMLQlzTNKM8gqJHlcSkpGtDVaFq2IthvKzuv18rJ7olXcseRd9seYU9RqZl3Vs+rUqjPA+VUDKXpg1bGU/KX3aSP9vcOKk3wOY4FbS4Z1VUGkc5UD8Kzyp2j/qvIXcC+y9NZljMgAI9REDkWOwB1D2AocivRETkXORJoj5yMDAV/kYqQQ/hHwr0SuIRyNXI9MRgaQi7tbcOfhjoCnuUxpKVmQweVwKWkZraCbwbmCfLxmXqo5Mot8d5CqSRlg6XuQjzH/VOYRaiJixAJnR5iPUIwURVzh+ogvsjJSGYmERyOJSCRiCVdE1oUnkV4dqQk/REoRd+F65FwJZwk/1NwCaWlZES6HSzHI4Dl84KxDPv7qAC/li9Qibx1SNSmVL6a1r5UQasJt4Q64vQgPAG3hznBXqDXcHT4R7g2fDd0K94XPhjtCa8ODoTvIdyk8FB5GSid3oVbkPAHXAZ7mMqWlZZ3lcrgUg4wDoLvBGUQ+XjMv1R0eQ94JpGpSepfc2mkhn1qb4L9zrAh9JNSEroZG4MZDV4P3QV8N3QjdDM2EbofmQw9Cj8MsbA49Do2o18LWcF5oJFwYdr5WhpQb5Gbg5uFGXivT3AJpaVmPuRwuJS0DOUZCtyHXiny8ZpRCvAR5eQ0kJfRgifdzH2O9CrkI1pAj5FnE+Q23aEu5zclcGwcI1uBQcNjgxvRw6IXWVUWwBhuC2w2uRQ8bPmZdjwRtZarl75p8uu+FoEYdDvR8+pQ6rA5rvjqGcEKdKp9Qp4keRjin3lV5fAKx++qjlJtQJ8rhkP40KBMypaVljZEcLiUlI5gVzA0WBB1Bjy6N1z6FcBrpw0F/sBxO/Vi3ah/j1LSyBn3j/NV2+t3aR2yn9bbtID/JCOcZzkWBtQDsNrAR4eYUWGDrIqgHmoBmoBXAUwnsAfYDh4AjwDGd1wNg3xA4A5wHMA4DF4ErwDUA+/3AdWBS38XwcBa4A9yDDg8RPsEOTGSCakFoBzALq0UIMX+oPmAlgJOYijGoJhCuox0bU2uAWqAOaAC2Ay3I00ZgagewFzgAdILXBXRjti4jCHq4KK2eeG6aMZ6C2quXO7uA35fOrw4+W06DOBYoCrgCvsDKQGUgQkgE1gHVgZpAbaAu0BDYHmgJtAEdgb2EA4HOQFegO3Ai0AucDfQFBgmXAkOBYWAMeSb0vFPAdGAucDdwP/AIsjmealDlwCAhS80FClRHYE71BO6r/sBetRzIQp6spD6qCn32Qp9aNYq0NcB6dQNhE+gtwDbQHI2gdxj1VHcCuwzx3RzqvkCnejDQrR4GfRQ4rp4knAbOAf3QrV/X8QJwWb2qY4QwDprjBugbxLvJEWhTRziScXUGNMftDwbKzOsYUfuBB+o84TFomcvQnwP6N8jQxhn0eRugPxd1JmgODAetyf4P5gULg06gJFgWrADPFwxxBOPqSHAt5EWDVaoc3BjcrPVfcKsRwfpk+wPTwSZ6ftPBZgrJLoKteCYbCG2aXsF2lANSz1d7rrnJ55jRn3JabnCPuiG4P/3cnnmO/NnT8w8eQr1H1PXBYxzBzcGe4CnEF+R/tnzwDHAe5QdQ/mLwSqAzeA3P/QGe+W3gAuKn0vFM+w6OpuPB68Ck+gB280DLH7xlzB+cBe4E76knCQ+DTzSERMI9DSGLepIjyQ/ZEc8HimBzO7Qw5AJ8gUEOsr0Let99EPR8yfEYWqleJVSGIkAibb+cBlL2C5rjMsYfEGgLRTiS9htap45wJO00VE02OR+qQfwxt9vM5w9bh00A3C65LS5ID61DnM8pU/r80KbZccqet+v0NGyZY+G8ckmz81AtZNUBDUFzaDviLaDbeP2hjsBwCHWHDgQmQp28bKgL5fX5KNSA+HagG/QJoCvUGzob6g10BOsDU8F6xDsQ79PyI57MP4i8l4ChYGFoGBgLloWgT2gK9DQwh/hdxO+DfgQ8DZaFZT4Ow1lBJ1ASzg1WhAu0cRd2BDeHPcFTYT/GWpXaH9yongtWhcsRRsNqOj3QoPHDjvR8FegNR4N3aA4EwmswxtPjtpDjGdvYp0NegH2ZCJdrSI7N8PpgU3gDzcm1mJMbkvkwp68L3A1vCkyHtyDcFm4M9RJ2ABtCvQbbihhtC88mQtDnttC68E71QngXn5eonznytfEQ3g1ddpM+e9EH9ckwkAjvI9RgbapTd2Gsq4TG8EGM91ptvggfTq5fWCNUdX34MOa5Wt6f4aOqGj6ajNM8lpGfz0dqOZBchwzrRPj4wvkhcDZ4L4zxHj4dfBg+B/Sn+nzh+vBYHzf6eApfUOcJWEs4kuk6/cy4eiauj4v0OND7Tx8HgUsYAzQOwlcDE+GR8HgwRIAu4ZuQn7EeBFrUc+EZ2NlMsl/Ct2F387A7zKHhB8DjYFWEpePPrC/6vJO0oYXtf/56TPPsnYhZvUqwqiORPPSRHXMYECnU5+vb+nydXE90RJyBuUhJ4H6kLFAbqQi2JuPoo1rMFa2arabXrUgIMjniOtaGeiNVgB4u1DPVjnFa80ciG6GjhhHC5qA5shXzFOaWSD3td7SxURP2cHuKNAWGIs14Vsl07bn0BcYirYGJSHtkD/TdD32T9ngpMEdjbhPG3BY8h/VIP4R4I+I7uL2m9kO8PU0G+9wJ+9z1zL5iwf5NnYkcCbQBenzhc4wcC4YIPWjbKeCMtu5rc0CwVb2sxbm+XD+1P3Jeg2b3wfbIAIe6PrAuchFjD+MI465WHx/nFq4zC+d3yOI3c6OR63g21/makNoXqUibTM/vkVvov9nIHdRzT1UjD6H7E9gAxQPViDcg3rBKVDessgD2wN5V+UBRYJDgCsyt8gXur1oZqF1ViX59drxp65G+30rO08n9EvtV+C3zD9jnbCO2SfZ5+i3zFvot81fpt8xbod9y8efiPcak5VIFNAtIIVYg/b70gBXJNfKX2GF5s/wVdsS00vRn7KjptOktwWo6b7oq5Jquma4JpaZhsyD40RCT0GC2mG1CoznXXCDsMBeai4Q3zQ6zQ2gzO81h4V+Zo+bXhT82f9XcKHzd3GTeLnwr+xPZTqE3+59mDwvnrG/brGIR/wqbuNl21PZ9sdm+2f4V8Zj9q/Ym8bi9w/774hn7fvu3RJxXhFGxiU6O1/hbQl4LgFOZF6cyb1EKzOtaBDiteXFa8+K05o0AOK15cVrz4rTmxWnNi9Oat07n4cTmxYnN2wLgtObFac2L05oXpzVvJ9AF4LTmxUnM26uHOF15+4BB6HAJ4RAwDHoM4QQwBXoa4RxwF7gPPAKeMsHHv1mQBeQCBYAD8AB+oBxQkSdKYL41wHpgA7AJvC3ANsbc9wiCHi6kk3FhsTy+xueWXyiD4Nuhl9u5gL8rnd+3+9lySbllcyX810Gf/KWPDv5Lfz4uttG4+C0aF/X8TiPrTWg0Lu9M31J4eoBTjHnOIDyfAvMMLIKLwBXgGjAKXAcm6bsWzDML3AHu6byHwBPGFBGwALBnJR+AHSuwWwV2q8BuFditEtFD2K4CO1WqmaDAdhXYrlIHGnarwG4VjA0FdqvAbhXYrQK7VWC3Shf4sFsF9qrAbhXYrNJH39dgCmxWgc0qsFlljMAU2K0yBcBulTnw7gKw2xX7CYIeLkorj56bZoynoDzV+CVyJr8kK52/JPfZcjr4d3g3sya2k3Ww/eww62an2Dk2yK6wETbBbrHb7D57IpiFfMEp+IWQsEaoFjYL24SdwnnhnmgXC5nsr/XX+Rv82/0t/jZ/h38vOBT6D/g7/V3+bv8JJmqhvxfUSf9h/2n/OVBn/Pv95/1HQJ1A/rP+blBHeZq/H9QhfxNSB0Dthfxu/3ZQu/yb/Mf9sC5/j78KpTeD6vYnUFMdlVX9O/1rQB3xl/lb/VWgOv0ulF4J6qC/wL/Nr4KqQMkqfyEoH2RX+11M8u/270OOw/6jngLw7aV3/L7Sh6Dk0mm/v/QpcrT76/17/M3+VvcDJpbeLR327yqdADVTetnfWnoT1GTpgL+l9AqosdKz/h2lw0x2zqcd2tPMcpw3l+ZQexPLdZ5YuvOXo/UvOesWd6WP0EqxNN93r3Sl7wmoLN9caXmp/P/Bapwl5UqwcOn3pN9Lfv/W/C/Mu1hWdmV2JcujL6C+Qt84fZW+ZVpAXzEtou+UOpkAK6bbY6GJYT5YjvHnlBcB1hknanFinXFinXFinXFinXFinXGqANYY5xqdh3XGiXXGuQnYAmCdcWKtcO4AMPc7dwGY5537gIN6eBg4ChwHTgPngAvAZWAEGAduADeBGWAeeAA8xjhmgBmwAnlAIX1Tia0oAyqAEGNFE/8wVlR9iDwbgc0LeFv1sP655b7s7fR2ebu9J7y93rPePu+g95J3yDvsHfNOeKe80945713vfe8j71Of7Mvy5foKfA6fx+f3lftUoNwX9a3xrfdtADb5tvi2+Rp9O3w7fbt8u337fAd9h31Hfcd9J32nfed8/b4Lvsu+q74R37jvhu+mb8Z3G27EN6+7B77HpTDCUmtpXmlhqbO0BDEGv6S0rJS/m+cgC2dSASxcIAs3k4W/RBaeRRZuJQvPIQt/lSy8ABa+kS0nC3eba81fYQosPI95s/Nh52Vk5yvJzj9Ddv4aLPyTrBK2/ZcsZPsvtiEWsV21XWNR2PkPYfk/sv2YvW77ie067P8dWP46svwq2PwZjIKzsHz+rnvxL01XrmWUtIyTlq+Tlp8lLX+dtFxPWvLfMRynX1xbsfOEXRZhPS3CPrDoRBrFGDfFGCvFGCPFGA/Fl3XA1oth659o+9B4tWSsZKJkqmS6ZK7kbsn9kkclT72yN8ub6y3wOrwehH74Hm+5l/99Ki9jZntFehUzxxcxU5kwR/0TZjZvwUz1UvYr2a8wC81LL9uKMC9l07xktV2xXWE22w8wO9ltf2X7ryzHNmobZXm2cds4e8X2tm2C5dNMVWB/y/4W+wTqW/bC6uM15VBNuVTTMqrpFaoJu3qhRNhNfX6RfQrrP+akknIdqg7MVyXo95L1ehg15EnGo4b4GkN6uZ6GOa5kk0GWsXySv8VQnmObDjzrkh16fr9Ob2Oq0kVuCBjWaaMbVsYW4RrdBPlTynSKM6fcVe4jfJTiPMWO7h/rmz78/bcStprx39H/Jr2fX6n/pZn+OpnTz3LyWxSX4lNWKpXKysLbSkRJ5LeAt06pLriX301/G+ymvzT/ufjnsJbv8Pfvxe+K32Wi2C/2M0n8nvg9JovXxGvMRH8nNNPfCV9CrmH+hQ7UtZ5/RTlnPRMN4HFhAThfKmhPgfNqcpqXlXv6PIOeS54hz7BnLBnmxD0TninPdCp9znPXc9/zKBlP8Z8qspKl5OZvUAp4uuJQPDntil8pV9RlW5SoskZZr2xQNilblG1Ko7JD2ansUnYr+3Ku5YzmXFcOKoeVo8rxZbuS/FT9kJ/zUDmpnFbOKf3KhVx7bn5ukXI5ma5czZlFykhupTKu3FBu5jiVmZxW5XaynqReC0NlXnlA+j3Ww6R+epiqX5f33HCJ/fah+0vvj4X9s7BfPnR/6Hqk8ifr0+Wk5On6LXzOC9uVLF/COKfEnNQvt6HEWpKXcz5V73P6JZkO25cz3pDn38jPovfkbR/v3QCrympsT+yi3WK32/PtRXaXrdDus6+0V9oj9oR9nb3aXmOvtdfZG+zb7S1Am73Dvtd+wN5pnUdaNfJVIl8C6QfsXRyZ0gyyqkkOl5KSgRzd9hPI34vUs/Y++6D9kn3IPmwfs08gnCIpnUt7o1qeMuVjBrCyHVhpBPpPAZid9XAhzHoo66EEiIZ0YznTgrJfWvE4p8/FsttdZucll3XFiCvPVZgzuOKBy+kcc5W4ylwVOU9dIVfctdZVhZwbkXOza6ur3tWEWHN2e3b9isuuVlc7cu5BzjLXftch2zmkHUHOY64e1ynXGcTOZ7cvs7oGXBdX7M71u5pzhrLrXVdc11yjrrJlkzlPs6+4rmcz12RuuetWzrBr1nVnxRrXPZfV9TBnzPVkxVW36Lbk9Lnt7nx3kdvl9rlXuivdkZwJd8K9ztnrrnbXuGtzptx17gbnJff2pEx3i7vNOo1yHdntzmH33txy94FUuU531wrZ3e26ZS1yn3D3us/a/M7hZRU50+4+xAbdl3LLlx3KGc7d4h5aEXUPo9xYzoRrs3vCPeWehqQ5pG1wbXXfdd9HDY/QE3H30xUej+zJch3JueTJ9RR4HCt25/R5PIDfU+5RrRM5fcvQb57oinFX67InoNYA6z0bPJs8W5Ix3obM2IJ+yYh5tiX7xb7V05gZy2wf6bLDszOvmutiL+GaeXZ5/PZZ9/YPTPtHt5AXZBMZVvBBz/0Dn/QLebY5c57droeefa4yz0HXIetTz2FofXfFA1vUc9Rz3HPSczrnvuuJ55yn37bTcyFPzI2idp9rrecy72uX2WXO3uq5mmkF2ZM8DbERz/iKLZ4boG4CM66SFTc9t1F7O+95zzzqfgD+4+x2hXmuKmbF6rIqeTljSqHbpzgVPFulDKhQQsue2Pa5K5V4zoSy1t2pVCkbXWXWtpxLymZnl6tdsSLXVkip5+U885DSlDOWfcrltBUozbm78zpz17hCK24orbYtuVlKu7LHfULZ76pPxrLrEdPTcrM8UR6j95j5rxgZvUsmWEYtP2ai5SeWt5nZcsPyLnuZ3iLLobfIllnes9zG3pu/RfYq7aA+xAxK/0tlA82jb/Bv5AlD9GsR2kGZ5SWhJqvT2eRsLhp3NhfnOVuLK5zt5ni2Wmx2tjv3ONuzbzv3m+POQ+Ye5xHnMUdd8aSzp/iho9NR5DzliFivZZ9zDH6yF3SRs9nRgTJnHNXZqnUScpqxFnrMhdaNVpa9e7ns6Fxe4Ny/3JOE4xHkAVweAeV5PiMW1y1rinRbRC+uU0ofXZfF9CAZkMvL8TyOatQDnbI6l59GufNaXctvOuqWP3AOOK3OU06n82L2TUenM27Uhcuip/7se5YTqfcsTfSeZZZlzjLHsultSyu9bfnR9wdr6DuV+u80s3FCWZ4F5Grg8eJCDdBKg4NC0fEAZ+bn/c44+ev+Afr+sJWt5f9zJmuGCTokAy04RigUiR7X0h03KL/dcdpxznHY0a+HF/TwshZ+stGQftVxuNClxZOhY8QQIt0x7rjhuOmYkfYivO2YccynQj3fc95wfV7P8z63fuB+jf9u+TCNKCf/JvPLtwiCjoLiWUf+h4GjyCE6XA6fY6WjEvaYANYhnnBUgx9x1CC9llDnSPD8+pP5I+j0Nf6bdvGoeJR+d55l1JTamEVtzKa3eK3URhu1MY/s6hVqYz615lUm0JeuxOQb5S/nPhfCIjxrcVtxZXF1cZGOjuK9xYniA8WdQBdSihDvBt/OUfSweOX/wy8w7GaD6XeUix4BLuApbF/W6OIsLbREQOfqvAI9n4Euxvgo9lC+vKJbRYVFs0XN8Ovh3yq6U7SxqIdcITmk/VJ+fS/Q9/FT738zB0HgX2LC2OX/tU3/a5a4hf+aW7LRb7q/Rn4J+f+b/H9Lfi7l6SL6Mfku4iwn+iTRrxP9A/JryT9Hvpf7QjX32ZvE+Svyv0D8W0TPkr+dOL8gaW7ifJv8CHE+RfR3yV9LOb9BMi9x//2fEf8t8j9LqRNE/zuiSRP2NnF+Tv6/JN9M/P9Gvkhyfo3qoq+YSVSLRLpJGyh/K9FWoo+QrxDn3xD9lPtyB3FmyLeQ/7/I/yn5f03+PPl/R/7fUqlSoql1Ev2+XqYv5cuvEIf6wVRBnDXEeUA0fXFCvkGa26ml2rce3yNa+/bG35BP+gj/mXztexZniR4gmiSwh+R/mnzShNGTEi6Qr6WShQjUVwLZgEBaMeolQft/WXfJJzth1GrmI/+b5P8l+Z8k/zr5v0v+F8mnfmb11CLt+f4W+WSl2pf6hCD5q8j/Q/IT5LdRnkGiX2GX4V9i/P9x3Cb6LU4LlZwWP038OeJ/m+ifEX2K8rxBeaqI/kOiiyjPBOX5OtG/IPp3KE8V5VlH/L8mfjfRf0/0XxD9GU6jnzndR/ydVFYm+iDRG0jObxB9iOgVlL+L8mwi/hqif0C0i+jXyH+bOL9J9E+JdhNtJn+Y5PxPor9LqX9KnBni/BnR3yd6D9HDRK8jHfKI82nimIj+MtGfIvp3if4yp9//DrXxTeK/Tfx3id5NdCXRNUSvJZr6WXid6N/m9PufIv/nxKknaV+lPF8gzjaiQ0R/k2iqS/zn9MTfpzG4kvwD5G8m30M+fRtfPE4+zUVonVbqJOU5SXzuh3Q5J0ky9zuJQyOIr6zwf0j+H5D/ZZKzW69Rk8D9vcTZTz6NL/Hfk0/2Lx4jn0aK+B/Jf4f8IJW9SfQwjfQ/JZ9Gt0hjUGwkn762w9/SYfwL25y+TDTNluLfUyltrnuX/K3E+TzNGKS5RP0gUXslLT99hVKitkg15Mvk00iXtpFPs7Q4RzT1tkRfv5RJsvQXRP93omkkSqeI88+IJp2l2+TTvC3tJJ96WKLRLdG8LTWRT9+flH+b/O8Rh3yZZl0TrSDSG+TTbCDRnCP9Hvn0XESakaSXyNfmapIm/Q711b+mPP+HOJ+h2eP7JN9JPs1F0kWi6ekzRqWo1ThFcZ/6RKT5TaQWidrcvol8evoSzWz/l7pvj/Op+P9/zcyZs8eeS0JCLuu2iY0lt1RSSZKEpA3J/daSJElCkiSXdV+XhCSElhDSTZL6SELuuSUhSiXJx+5+X/M8p7XH4/Ht8fh+f78/vp/HPvY1c17Pc+bMmZnXc2Ze531mVG/IWyDB7Sosk0cgq0OGbI81g+Qs3FdAUwqWeNy0Db52DtIx8tMInYO7zMG1LHPA7fKx3OqQ17OsY9YzlP1yb2bZUV9l2rzFs0H5NLcCIQeqqpD3sEznlIQcwv25kMNVBstByqwG97JZtZr1DSAbsXyRe0gTbwJ5N8t7rQdZNuAa41ZqtWDZzqw2KFdzWRp9Z5a9EW9r1iDjc0y8jtUW8WMsB+SaFFrizLaQPXLb4ypzTnd1xqC5i4zU5XBmDs5cihRWmzGMNu8Jhua+xrKq9YfR69uQwjc4Zx/kZlz1B+RHpkxUZTLr3DdnmWb1NzkxqyHK7tZpI7V53rTcEqZ8UIbdzepOLO8zMvdFxIsjvpXlBrXYtITcmSwdbtEsc01qqbZ5ltQwbvR0McesjzTVSOUZjVhm4uIc4k0Q32DNMi3NXCU2ILWGupJhZqSTrGqyflf2ZFyVybIf4hsQD3L6Gj7PMSsdJusuRp/NJSAyzNOJFKSZgidtaG3k+OFQmvRFBvKQYa4VGdKs4XTRpCxT9Vk8ywaTpjmfNW2MNCnLyVH6G5FCX/NcSO2ckZwTfiI5GleN1mZn4VSsOnnR5ER5eNJzRrJ+I64dg2vH4FlWQ5oy6Rc+u9UB53dAKRnZ3jJzofV4ojSck4a7jEaJJaP0kjUsNyr/JHMtyqF9WM7I2/qcnUgTZW6dR7mhVPFcG5Baw/DuuDYD9xphmZZQCKWdZOKqry7C8X1AR6OUklGG65GTNJRw+xzPSFNu/LzGckcDLRSWJJ43A3dPQek1xNOlolS3hC0BJdPESC5hXJtzAuVGaF3mScfgic4htWJIJ5lZzZTeUZRqS1OqSCcFMgNPnWLaD6P1kdpmWAdKFSmkocbT9ECU6macMxDyAPQHoB+DUg1LGHWUE5Y8Shh1sQFXbcCZh6EpBpliWixtRrvNMCgdgLyYswRPusSUZPZ6lM96tGRTg/P1HJw5x2hMDmmz0dNwc74YDHSlkXKQNs++VX9u+h07xZQ85AX9huE3vcro0dpHQ2bpbJY3GMnnZ+D8DNTUZJT5EpTtEljKPmhCCwpbXSWUp4eyNa10tLEpjmfBUjw8l1mF9Dg4YTHKPAXnpBiUrdVGS7NRd1tRs/VxF3P+HNRIKkpgg0lfvJBztRkxQhYGD+xGbW7QfSBN2Z7FHccgHcfkhG0nC7WcZcoNLbA9LPci8l84rE1TX6yBRNleDM/HtcnWEDzRb+CNTWixJfCkJWCDmZBoaWZdWrne7EzAbaM/Wk4XpN8FbQAsZLiXW4Jh4AGmltmCUONmrV6+i4QcYeodZe7owiZNyDQj+S5oadmzTfnk3IQ2D/bA+dtga9sQX4j7pqBdTc5pjLprjFIdgquGIOVEw9LGapjDV4N1V0Pf3OhhjwvNWsac8yLI22rkpDk0ldBnsaVYXXlUJay6OWZ/8/uxPm+SqR3ZzPSJbKfGRt4xz0WbTNzqZezR6gWerGnurhqHHGjuJeuZOG3G+Qdwzt2mplTNXOP924QaX2PirG8OTQ1oKhiNyQ9tsmtDv9mwVngVWmnJ7E2Im1ytMXF5xE6DNCOBI8bGVVFclWT2MWeZZlIwZ6pMyJ0mt5aN3KYjt7OR24smt4yanv2Yehp3L4J7zUK8EuKmXX1qGQ9Obq5ZUXI72kOQWwZx44v8NPc2nGNWdjyb+6xpb2bVbVkooR6kacM5CWZ0UcjpBtkSfWgNU27WNpZt1HkjrQlo+cb2O5j93Hnk0A31ZWz/MesS9D8bqccibsYeXc3a2awBapt3m13sQZDPQGYgncWIv2DStwdDMxCaBxDfjDyHZx6A3pzT3bRG2ds2/ddQ+02W99pfGCuAXIXUGthrcb4ZKQ3Q5qq29n2QZmxW2N5v8m9fY5467G1xlzR7vkkNHHhvqKFcI80+OyxNOmkyHXHDh+nSgWYANP0gcZXYZe4rfjG5BdpdmnGjL/ch/jNkGJ8NOdpI0Qqyh8l5tqmXLjmPs5yRbfr9hdkljbw0GPZu6qJ39hc4M4xPMvfNqWZk9nSTt5xxpkVlLzRxcGM67Cjd9GKyO+y3e3YzI3OnQWJ0kTsK8aaQYXwBzq8JuRfnzIK+g7kXZPfcPYiPMv1UeFV0F8OfCnI80BQTV5OgqYIz10P/ATRY+VWEM7g3EPdyDWNnmVYtfo/mFGwR5r0Qmfmv6cdPQn81NPMh60AfzhzHQoM5iMDcTWJGJjCXFG0hQy/fw4ifgoR/T1wHiTmdWArZwMjctxHHbE7A90Vhbi9BjofE/Jo+RsqhTwb+KxH6bTC3kndBg1mw6AmJGVku/IcC+ReYVxK8fxTmE+cIzNlF6JXCvDsH8yaJHAqUj0QOZegBw3xTYB5KmGmKMM+Y5wr4oCQ8mQJeSuYdownLM5x/hT7JryHhhxTw7Ck8kYCPUdQACk8Uz3xMHDs7SORTIv8UzpFDX8FkXAU/ntgHFB5LFZYJvIIinMnCMyaxV4nE/n8q9Mpiniixv6AsiRTCmXJYa/BLiC8gw7ktvAoiTAe+Dgp9j8uhge9RhPs7hHP/bdB/Aj18krmIW+EdQ/8qZtYE74rA/JqyoIcHT2HuLJcB7QsJ74FEmatNiKNeBDwGIvSp3gMZ+j/hz5RlkHJYR5hHi9CfE3qPw/rFzFcg5zL0vsJzKzCPFvD0ikeRZlj78EPKaxBHnapJiO+FhB9YwRsp4HWhMzg/9DljtwsBj6gIaw1XydAbCf+MDPdagu0oSAnvqxgCiTKnzVGphh4zlhp+BoFWKsO2ipKUtSPPW9j25rAMvaYPRm2SNQq+IIEcCvh45YNGnxvab+iNB5MI+H/C3SEt+EhVV2iaA4WXm9D2rHSgKDcBLzqFvpfQGxPyxkN4CtzXwpsChVLNha/JQg5V6FuD/41C/wb2fbRCrwjYQOG9AMF/Is4CvRV57oHnDev6fcgWOL8e4si5hJ1K+IdlWI+oL9UHmjCdF6EBg6nQE4j6tcBXAq1RzEEewlKChycHdcpzeCP3QKKcc1FuOfCzUei7C9sqcpWL9sM9otHAe5MDj3Q2LD0ba0Vnwy8k8UYgBzsy5qA0csAb2UgtB9aaDV93DnxH3KsZibaUg/cO2fDeZ6OEc/BeIwc8kH0B8Y8hYSM8szWyJmRl5Bx8kpsFGXrpi0CiheduhIS/Kxfep2z0JtybmngqziRKpONqDKmO/Tp2oiI9unbqRwvSO/bvQ6upJFmN7miZRDXub/pIEjV5sFnDJOr0UEuWg4gHb+SYPW3paipKyVSFrjPvF1lbwPyukwrRtZRE11MKp+JHeockFaZiVJbzfSOVMr9XgL4AKc53cSpHN1BVKm1WqIM+kSy6hkpQeapM1agMFTTvY4EpcklTqnmj1rRV4yQq2vKB+5P4SoOFZwiqEIUVqXrnzr37ikqQNSEbQDaFTIPs0iW9Z3eRATkVchbkPMiFkMu69ezTUayEXAf5MeQmyC09+/TsL7ZD7oE8CHkM8lTPp55IF2chz0NeMlJKSIeT7ygDyGKQ5SBTIGunP9E5XTaAbATZFLIlZBpk+95du/SUXSB7QfaFHAA5uB8nJIdDjoIcBzkZcgaksR3z9YzZMcH+X8SL8N813Bau5RouzrV2Hdd8Ka6TMtwOynLdlucaqcgtBT1DtIfZfyfBB1z//yS9f5QF/kEqbnkF6er/QUwQxi4Eaw9HM2iLkQcZoTC/x/gHedU/yiJ0E/WggTSKMmkhraEDdF6YfSaTRW3RSLQW3cQAMVJMFQvEJenJkrKJ6qeGq4lqnlqhNqjt6qj6zZJWIaucVcO6U9fVjXWa7qEH6lE6Uy/Ua/RmvUef0BdsJ+9JkGu98IrjBbDevB2p9cp8x4zbS644PsvHBejyHu/cEuycMExworAIrpFcb4UiTb0obBRPLWE4Urt8POKK45FXHGfGj4N+8ePCVvz42l35jvnpilW+4rhR/OmLj4jjxVcDd6K94atSbapPjbAHBT9N8a1RuC8MS8yJwg1heN2WKLwQhqWKRWHl+F1LXYwfl5Y4zr8nPV9V2o7CglEYlX7pSji7FDWgxjwiSKMO3K76cssaxm0rg1vXHG5fWVhVcTNtoz10mEfVZ+mCWWJUFBTFRFKUzsgonByF86NwZRRuisLtUXg4Cn+OwqgVlAmiMEq3TGoU3hmFUemVaReF6VE4OApHR+GMKFwShR9GYVSqZQ5E4ekovBSGSdH9k6L7J9WMwkbxll+2YbzUy955xXGzK477XXE8K98xp1++aRwvP+OK48Xx4xpL4sc3tYof19x0xfHpuO3UPIfjYnltsjWPxbpRHxpAQ3iEP45HObNpAS3jfv1D2kRbaRcd5BlNVFs1N0bhtig8GIURXouiMCrNWqWjMKrNWg2jsHkUto/CPlE4LArHReGsKIxqs9b6KIxsqFbUmmqdC8PaUanWLhKF5aKwarzU66TGS6nOFbVWp32cEerkrxXJx+vi59etf8VxkyuOs+LHN9eM18rNVzDczQ2vOL6ild3c4Ipjs8MDx71m0PY3XwGRleAl+AlBwlX4ducv88sMUYbt1uza9Rv3NiWZmRpQE2rHtT8w+j7arH1tk6cKkZR/qmtJqoRIcw80JaDhe5pvvFThCLsXWNF8ZzeBpnje2UVwtsb3CsWYnSrgDr8i1d9w/Tlc84e3nM+0cU2xv682Ovln7GrG5AWTP06jBNIoijSKmzSiPHAO5e/mzvI8fjX3q+SxsrI5TUcV5tyYvQmSqaBVwipvFecesYxV2iprFbMqmW/UrBSrsnW9VcW6Ab+8/FXyHECeM2nLPzkdC+nYZq8xTq0I36uAukfdh1+peXyTYfZQmWvuqrAti0pUiXjT52EkFO5f1DAaGVSKdo80+0fXyKdTXD9Vsadm6Twttz77XuwxL+VfSiJlD0+Sf8/5SlQ/X/o3RPvomN04U/N0pkTypWAPtYfhV40iaPkP2IPon6V/wv/R5EVZrhdp9vuGWaU8Lc+EZaBO2kV4ts1p2UVtnvnYJczOhmYdEJN78SEdUKVVkqqgKqkUVVXVULV5pDJCjVSj1Gg1TmWoyWqqmqFm89hlgVqslqhlKotHMavVOvUhj2U2qS/VVh7R7FL71EEe1xxXp9Rp9bM6yyOcFtZD+kZdTVfXN+lauo6+Wd+m79B363t1C32/fkg/oh/VHXVX3VP31k/oJ/VT+mn9jH5WP6ef10P1C/pF/ZJ+Wb+iX9Vj9Xg9SU/TM/Xr+g39ln5Hv6vf0+/rj/Qn+lP9GY+XvtLf6G/1Xv2dPqJ/0Cf1Gf2r/kP/pbNtYWu7gO3bV9vX2GXssnZ5u6J9vX2DXcW+0a5mV7dr2XXsW+zb7NvtNnZ7u5Pdwy3mlnBLuu3cDm4Xt4eb7vZ1+7sD3cHuMHeEO9Id7Y5zJ7pT3RnubHeeu8Bd7C5zV7ir3XXuh+4Gd6O7ydvp7fEOeIe9o95x74R3yvvZ+807713wLnqXvBxf+raf6Jf0k/wKfiU/xU/1p/jT/df8uf6b/iJ/qb/cX+Wv9d/3PwgeCtoE7YIOQZegW/BcMDR4KXglGBtMCCYF04KZwetcfwdUKfMrQFVGlTG/sFDluS1cr67nWq+iqrB13KhuJK2qq+psI7VULUpQL6gX2FJeVC+ypbykXqJE9bJ6mVz1inqFbXWsGku+Gq/GU6Amcau5Sk1RU6igmq6m09XqNfUaFVJz1VwqrN5Ub1IRtUgtomvU2zzPL6qWqqV0rXpHvUPF1HK1nIqrVWoVlVBr1Vq6Tn2gPqCS6hP1CZVSn6nPqLT6Qn1BZdRX6itKUt+ob6is+lZ9S+XUXrWXyqvv1HfML0fUEaqoflA/ULI6qU7S9eon9RNVUmfUGbpB/aJ+ocrqV/UrVbGaW80pxWpltaIbdYpOoaqa/6iaTtWplKpr6BpUXdfUNamGrq1r00085q5LNfWt+laqpRvoBlRbN9QNqQ6PxBtTXd1UN6WbdXPdnOrpVroV3cLj8zS6VbfT7eg23UF3oPq6i+5Ct/OovQc10Ok6ne7QfXQfulP31X3pLt1P96OGur/uT3frAXoANeLR/UC6Rw/Sg6ixHqwH0716iB5CTfQwPYzu08P1cGqqR+gRdL8eqUdSM54LjKIH9Gg9mprrMXoMtdDj9DhqqSfqifSgnqqnUis9Q8+gh/RsPZta63l6Hj2sF/CcIE0v08voEb1Cr6A2erVeTW31Or2O2ukP9Yf0qP5Yf0zt9Qa9gR7TG/VG6sD2s5k66i16C3XS2/Q26qx36p3UhWche6irPqAPUDd9WB+m7vqYPkY9eG5ygnrq0/o09dJn9Vl6XJ/T5yhdX9AXqLe+pC9RH9t08E/Ylm1RX9vhmcyTtmd71M8uaBekp+widhEy6xCVpqftJDuJBtjl7HL0jF3BrkAD7WQ7mZ61K9mVaJBd2a5Mz9kpdgoNtqvaVel5O9VOpSF2TbsmDbVr27VpmF3Prkcv2Lfat9Jwu75dn160H7EfoRH2o/aj9JLd0e5II+3udnd62b3WvZZGucXd4vSKW8otRaPdtm5betV9zH2Mxrid3c401u3udqdx7uPu4zTefcJ9gjLcp9ynaIL7jPsMTXSfc5+jSe5QdyhNdl90X6Qp7kvuSzTVfcV9haa5Y92xlOlOcCfQdHeKO4VmuNPd6TTTfc19jWa5c9259Jr7pvsmzXYXuYvodXepu5TmuMvd5TTXXeWuonnuWnctveF+4H5A891P3E/oTfdT91Na4H7mfkZveTu8HbTQ2+3tpkXefm8/LfYOeYfobe+Id4SWeD94P9BS70fvR1rmnfRO0jveGe8MZXm/er/Scu8P7w9a4f3p/Unven95f9FK79/ev2mVl+1l02pf+ILe87WvaY1fwC9Aa/3r/OtonV/GL0Pv++X98rTev96/nj7wq/hV6EO/ml+NPvIn+5PpYz/Tz6RP/Fn+LNrgz/Hn0Kf+fH8+bfQX+gvpM3+Jv4Q2+Vl+Fn3ur/RX0mZ/jb+GvvDX+evoS3+9v57+FbQKWtGW4JHgEfoqaBu0pa3BY8Fj9HXQOehM24KuQVf6JhgUDKLtwZBgCO0IRgQjaGcwKhhF3wZjgjG0K8gIMmh3MDGYSHuCqcFU2hvMCGbQvmB2MJv2c0+XQpNUOZWsKqtUVVOdU2N4Pp6pZqk5ar5aqFaqNWq9+lhtVJvVFrVN7VR71AF1WB1TJ7g/O63OWQ9aD+tb9O36Ln2Pvk8/qB/QD+u2+jHdWXfXj+sJeoqerl/Tc/UivVyv0mv1B5xGsv5c/0t/rXfo3Xq/PqS/1z/qn/Qv+nf9p/63zlUnbFeVswvbxe0adju7g93FLe22dzu53dxebh+3nzvAHeQOcUe5Y9wMd7Kb6c5y57jz3YXuEjfLXemucde7H7ubvV3ePu+gd8w77Z31zhnpk2/5ju/5pf1yfrJf2a/q1/Cn+TP91/03/Lf8t/13/Hf994KHg/ZBp+D54IXg5eDVYHwwJZgevBbM5X5lEnoUQo8i0KNI9CUKfYmFvkSjz7DRWySgn3DQTxRAP5GIfsJFP+GhP/DRHwToD65Cf1AQ/cHV6A8KoT8ojP6gCPqDa9AfFEV/cC36g2LoD4qjPyiB/uA69Acl0QeUQh9QGn1AGfB7Evi9LPi9HPi9PPi9Avi9Ivg9Gfx+Pfi9Evj9BvB7ZfB7FfB7Cpj3RjBvVTBvNTBvKpi3Oji3Bjj3JnBuTXBuLXBubbBtHbBtXbDtzWDbemDbW8C2t4JtbwPb1gfb3g62bQC2vQNseyfY9i6wbUOw7d1g20Zg23vAto3Bs/eCZ5uAZ+/DmK8pGPN+cGIzcOID4MTmYMAWYMCWYMAHwYCtwIAPgQFbgwEfBgOmgQEfAQO2Aeu1Beu1A+s9CtZrD9Z7DKzXAazXEazXCazXGazXBazXFazXDazXHazXA6zXE0zXC0z3OJguHUzXGxzXB7z2BHitL3jtSXBZP3DZU+Cy/uCyp8FlA8Blz4DLBoLLngWXDQKXPQcuGwwuex5cNgRcNhRcNgxc9gK4bDi47EVw2Qhw2UvgspFgrpfBWaPAWa+Ap0aDp14FT40BT40FT40DQ40HQ2WAoSaAoSYyQ91KM1VZVVHdoKqpm9Tv6lU1QU1TM9Xr6g31lnpXvafeVx+pT9Xn6l/qa7VD7Vb71SH1vfrRWIHVUv1utbRaq1d1PV1f36kb6Sa6pW6mW+s2ur3upLvpXjpDT9aZepaew6OFhTpLr9Rr9Hq+ZoeqqDfpL/VWvV3v0vv0QX1UH9en9M/6N31eX9Q56kddz05UZe1CdjG7hr6TY23tx+zOert7nfuo29Ht6vZ0e7tPuk+7z7rPuy+7r7rj3UnuNHem+7r7hvuW+7b7jvuu+577vvuR+7n3rbfX+8773vvJ+8X7HTLXV36C7/ql/LJ+Rf8G/0a/uj/Vn+HP9uf5C/zF/jJ/hb86aB08GnQMBuN799HBuGBykBnMCsweuTP/wxjLjF1LgbdKg7fKgLeSMDotC/YqB/YqD/aqAPaqCPZKBntdD/aqBPa6AexVGexVBeyVAva6EexVFexVDeyVCvaqDvaqAfa6CePGmuCwWuCw2uCwOuCwuuCwmzFurAcmuwVMdiuY7DYwWX0w2e1gsgZgsjvAZHeCye4CkzUEk90NJmsEJrsHTNYYTHYvmKwJmOw+MFlTjBvvB581A589AD5rDj5rAT5ribHfgxj7tQK3PQRuaw1uexjjvTQw3CNguDZguLZguHZguEfBcO3BcI+B4TqA4TqC4TqB4TqD4bqA4bqC4bqB4bqD4XqA4XqC4XqB4R4Hw6WD4XqD4fqA4Z4Aw/UFwz0JhusHhnsKDNcfDPc0GG4AGO4ZMNxAMNyzYLhBYLjnwHCDwXDPg+GGgOGGguGGgeFeAMMNB8O9CIYbAYZ7CQw3Egz3MhhuFBjuFTDcaDDcq2C4MWC4sWC4cWC48WC4DDDcBDDcRDDcJDDcZDDcFDDcVDDcNDBcJhhuOhhuBltpafKMhyL0y/jf2UXVKf97/5B/xD9GZldZ47WAy4Wt1/hqFHw1FqxIq1PqFNloAQl2N7sbOSjrAijrROTb/E4tGf4443sqpIbyVWOZIw/ztXlx2/hyBM90zb7p5rvRvrSBttAuOkyn6BzlCEcUEiUpkYpSSSpHlagq1aR61IAaUVP1B+dsuPqT5Qj1F8tR6t8sx9kvsCxt9ySpb7QfZ1nN7s2yuu+T9I77V7E88d+keB4pXkCKF5HiJaQ4HCn2QorpSLEPUgyQYkGkKMiynzBnI9Y3L/ZkXqxfXuypvFj/vNjTebEBf8e8pnmx+xHjkjSlRsS9wS+cg9/072Rxr/An2dwz/Jtr4SP3Y3yVXA8+qAoo+4Jc3lZeyVtRuRskcGtwvbI+DFEb0tQMmX3DTQrmTYvl3sRX/a7GMYviKi8rPDsMFfb6VEv5KoU3m5UplWpH+5FTpPu7tENfW2XUOnZOV/Mhj0Eu/j+/BqF5mquoNbWjTtSLW2svGsDxwTScY6Mpg+Nmz7lZ0XNfhZ3q6qJ1NaCmHG9JaRzrQN04nh6VRhU8+/uQh1GWtdVZeK0VdEMh/wV5DvipyG7OQL4LefQ/ouyKoNTMm5UR/D+a4xlcYkNoNs2nxVEsi7Xm9/vro1IsgtZ0JzWh5vzfmuOm9JtEKYWxwawdHpVnyv9jeb4Aeeg/rmwTonKqTY2pGbXinLeJSjAhsr6SEduF5XQjnu11yIP5yudSvuc/9X/+ycP93fHWR/5IUpr3YuZLbPPLgMt6JU/mIeGu8Oa9UCuUQ9VIcys/6ygaF9NVYl1/WhbTmRUHOpjfZkFn0lxB4T7seasN4Kv8RHyV7+KrfA9f5fv4Kj/AV/mF8VV+EXyVfw3WHEAbxHpQ/5uv+oVzHHKnebch15uvARQ/vQqQz2qmK5cL+M98xfUb/1/Ipx+nAml++29+n3w4T2/JAfx3XpovDcyvoTfnIeY7dWG+x5Cn8nRSNpbb8PtO85Xn5TPX8f8QbjEka+Q7t6Scj1+4SXlKlsx3tvlldnPO0Xa5Rx68fL44Lc2XaHUZWSc/Nl9S5F1hviQqzfo5/Gxt8l2xTprffduMjJLjTDzvimE82jClUDWfLp11ezg3bcSYfNrW5msJTqGhbCJy8unN9yiLWZ8ia8i6+e7ZSPKIR5jfL+/Mp02VBcl8FytFjkjNpy8muA5EF1LiuDgt5lxGeNzDzy6aMLJFbOd8Xb7mS8FlbFIRtS/Xn1gpFgouZ2G+LUnKp88Qs4T5ysl8GeJc1tNsMUKYXweY2jt7ub5pJI0U6eZX7WR+m7AnH5IuWopGIo3MrpIC3yOHiOYeraWoK1KEeb9m1lKYn++q2qKgKCnMG+fh/D8q31Ul+e+8kMhVD/7vE2GhHXHbx0pAPtZtDLDyw1UJaxLWUEG2iZN0Ndp+Ktp+ddhODf+Uf4puwpoPNWFHsHZnx/94lRgpM/nOf1tiopybd20pvnYXJXPLPEqp8hinc4v9jP0M3Y7UGiC1O5DanUitSR4TmfUbwrUeWbp4Ix2uOyHXhm+pHYyF+JkEWACsxWlazFqLjEWRWdFB8LhJYR2LJIzKKpm1ZxC7IS9WGTGub27zGWCrVFxTjMeC4TWGCf++6nK8chTPd6VpUZyT2lw3/WkQDePWMYYmUmbUV2dxH72eR+ubaSvtpH08Yj9Op+k3usCt1xKJXPNFTd2LSqKqqCnqiQbcfppyK0oT7UUX0Uv0FQPEYDFcjBLjxGQxQ8wRC8QSORa7xvNIl3MxnuV4zouUGWYHPazuIuVEOYnlJC4VKScz40o5xdSUnMq8K5l9M1GD0005cD1KOZNbkLQmcwuS9kBuQTJhDbOq5Ha0BTsuf8XyK2cry61Yb+prsO025xusPbWd5XbTipwdzKzh6jiGi3ex3OXsZrnbYd5w9jh7We41ew07+5z9LPc7B1gecHjM7HznHGR50DnE8hAzuHQOO0dYmjVLpHOUa18yp/O8C+uXSOcHs/+kc9zssY11rqRzglu9dE5yC5Hc9h9g+QC3eum24FYvue3zbABtX/oY6XBLVNGvAgXG8ESpUQ///8vCStDfczvPbc6lmmOkPIm2mkUiWMZcUoh5oZHoIAZxDS8Tm8VRcUkWlamyiewih3AtrZBb5HEmpBKqpmqmevDca5ZarbapU5bF44m6Vksr3RppzbHWWTutn7WjjR+mte6rR+v5+kO9R/9me3ay3cBuY/e3x9kL7Q32Aft8QsGEygkNE9onDEyYmLAkYVPC4YSLThGnqtPY6eQMdqY6Wc6XXM45BYoVqFGgaYFuBYYVmFFgZYGtBU4kysSSibUTmyf2ShyRODtxTeL2xNOu7Sa59Xic0scd5c5z17u73LNeolfBq++lef28Md4C72Nvn3fOD/xK/p1+O3+An+Ev9jf6B/0LQaEgJWgUdOA5ulmRyKGAipgWnpCDdn4S8kQeMg7IOCDjYsh4IOOBjI8hGUAygGTEkAlAJgCZEEMmApkIZGIMmQRkEpBJMWQykMlAJseQKUCmAJkSQ6YCmQpkagyZBmQakGkxJBNIJpDMGDIdyHQg02PITCAzgcyMIXOAzAEyJ4bMBTIXyNwYMg/IPCDzYsgbQN4A8kYMmQ9kPpD5MeRNIG8CeTOGLACyAMiCGPIWkLeAvBVDFgJZCGRhDFkEZBGQRTFkMZDFQBbHkLeBvA3k7RiyBMgSIEtiyFIgS4EsjSHLgCwDsiyGvAPkHSDvxJAsIFlAsmLIciDLgSyPISuArACyIoa8C+RdIO/GkJVAVgJZGUNWAVkFZFUMWQ1kNZDVMeQ9IO8BeS+GrAGyBsiaGLIWyFoga2PIOiDrgKyLIe8DeR/I+zFkPZD1QNbHkA+AfADkgxiyAcgGIBtiyKdAPgXyaQzZCGQjkI0x5DMgnwH5LIZsArIJyKYY8jmQz4F8HkM2A9kMZHMM+QLIF0C+iCFfAvkSyJcx5CsgXwH5KoZsBbIVyNYY8jWQr4F8HUO2AdkGZFsM+QbIN0C+iSHbgWwHsj2G7ACyA8iOGLITyE4gO2PIt0C+BfJtDNkFZBeQXTFkN5DdQHbHkD1A9gDZE0P2AtkLZG8M2QdkH5B9MWQ/kP1A9seQA0AOADkQQ74D8h2Q72LIQSAHgRyMIYeAHAJyKIYcBnIYyOEYcgTIESBHYshRIEeBHI0h3wP5Hsj3MeQYkGNAjsWQH4D8AOSHGHIcyHEgx2PIj0B+BPJjfsRCT2uhp7ViPa0ZwSbkGClPQl5GBgEZBGRQfgTj3ZwEMFJCjJHMGDghx0h5EvIysgXIFiBbYggsy4FlOTHLcmBZDizLiVmWA8tyYFlOzLIcWJYDy3JiluXAshxYlhOzLAeW5cCynJhlObAsB5blxCzLgWU5sCwnZlkOLMuBZTkxy3JgWQ4sy4lZlgPLcmBZTsyyHFiWA8tyYpblwLIcWJYTsywHluXAspyYZTmwLAeW5cQsy4FlObAsJ2ZZDizLgWU5MctyYFkOLMuJWZYDy3JgWU7MshxYlgPLcmKW5cCyHFiWE7MsB5blwLKcmGU5sCwHluXELMuBZTmwLCdmWQ4sy4FlOTHLcmBZDizLiVmWA8tyYFlOzLLMPIqRE0BOxJCTQE4COZkf4XkUI0bKk5B5iFsGc54yBoG8jCQBSQKSFEPKAikLpGwMKQekHJByMaQ8kPJAyseQCkAqAKkQQyoCqQikYgxJBpIMJDmG3A/kfiD3x5AHgDwA5IEY0gJICyAt8iNmVpqQY6Q8CXkZ+QnIT0B+iiGngZwGcjqGnAFyBsiZGPIzkJ+B/BxDfgHyC5BfYshZIGeBnAUiqWD+OTH8RQF8PinwF9XCLLk5Zskt4O1pibnyg5grt4Ln5yl4fvpj3jwY8+bnMW8ewvPms2TeOcwjn5KoMs+e61NjakntYruxGT81vB+IwQOCGLwgiMETghi8IYjBI4IYvCKIwTOCGLwjiMFDghi8JPD5NCMJX5QVehKidXSnEbnNWO8i92a1nTZUlGrQrdSMOlC/2N5xm2k7HaDjdJYuCk8UFUmismiMu5jeITP0DmCklYk+c2akMf1AJmr/b802aE7n03wDzRloTIrbkaKJ7ciL7cyLfZsX25Xvzrtx5x/y0tiTd9bevNi+vNj+vNiBfGl8hzSO56VxMO+sQ3mxw4iF7asoxhqZPFpV8jUOv+Rwdl5qR/FUP//9nMZrza1uIc+yEuQynjd5MovnO758l+cpV8nVPCO4mv5+F1sySsOMnV/DOHl2pPkCmi+hMR7MtZyH/O9Fvo9q3/gh4W8Mj7iWjZdIyrqyAesawU9UPdJVkCks+0Ve+7+1gSzKz9OO/0rm14vzIofv0xB/Vgw5IEzNt5ddYtpNYiunU0Q2ls1i+mViNVnikrgkU2XtGDJZzCItjpo/WfSKuw8Uw8iszZtf10Wks1whLsW0zURr+q/irgMqimSLds8MeYgDCEjOmZ4ho+QsOQlIkgwSJUgSgRFBVBQQJEdFTEhSQQFJYkAXQVExEhQJCiigoqD87iG66/7df87fs9SZouu97qqa6vfurdDVgwYL4PD2J7kCqAaXm0gK3T9pOEEYW8Ei0mzoupQcpIPjg+C5jVJkNyCcuxoYAh79SY7sFUSDwuAO0m81rcuRnYQYkA4OWqDzTxpkvxkGmAPmQFFw20+aI0AmQAY8QwJ8nfhPOmS3IhlwnRRmQOafdNYAsk/wx08yZKcjUuuJn6TiAGFtHWFVhuyfRAE3QeyKFLGyC6j+/9M8+dqKFwlnQRLOokgIi4YRdgxGKARV+UmoKkCagRRcmVtHdv0sYxaCVqR1MBh7QNJ7OkDSmw5WVwH+T+sKcJ8CTWoPxBvXn2ggkEpLJcVXVmZgkeP0n2dKSSPvVNIoO4ukR+xHYWWHqjBpNRFDeps86WwSUzXA7IXM3GKWZ3bh/9MkPXrlN60aKK7CtUL6LUi9eAFabCu2DduO7cDewHZib2JvYW9j72C7sHex9/6wRwoE9gH0cFuuPrGhtbJyvIP0hII/jPbwfaCzQn0lxd9I8QIpXiTF30nxD1K8hMTI00JwDJJiFCmmJsU0pBiLxORxpDj+T/dUra2A0DIBGPQp9BvkHZIrz4sEk3QI0ooCBrQ4gB49iP4AoNFx8OcufDyHnoCPJtF18PHwil7hf9GTs67rgdXnCI6ulUoAHGmZAeY/KTUBPfBT/stn/qr8v3HmSk3gM39ZJ861VmIBKNCv4DOK0YukXJdX9Zdx/iawuj6NrDINrXkD5aqFAsiaPzeJX5hJXHFjrafQuXK06unrfLLa/0DyAIDlffzLO/kBrkLSExukP64siMiVTk4lnmSQ9IUWpECVELmIsGgfCgTxNBAVOZkEHRrFQQZAruTUEuQgBiQqokBMiRVkAUlukHCWccdzwuaJBDPADQgFgmDj9ATC4I8aEiC+DZlhmEWXujG+V+f42L1evH2vR6nKm+fiX0Jks4KImHaIiD5XgkaBKBROFq7i1SZ6U9vXXp5KpApfhWjXaguSwfWKIFUTbYMhx6FsrPA4iBFJUOKobV1DfXwDvcOCAvEMEB0ipMBRWHp6BAQFeuC5IU5EQo1jMfF1DwkKDfIK49UOCgkOCnEN84Wv4IN4ED0ax7aut/YN8JSyCnMNCOY119aEuDfR4hUgZUgRryivJKewA04qbUhCCbX/SM2wEDWip8GhNc208SKQ0HKKO1DbN9jHM4RXx0qXV9fKVEVBS09BiqAjT5BSJmjj8UKQwPIX4vzlF7LyDNnj6+4JEUH+jQ0MkgFoIkgPwHJqFBEEgUJHWRVFetTxslMzpl1OF4viXrI0f8ShzlDkPdX0rJN4XizHKfY6altWQVfAztF5gw+/0W02nKRQ3CqmwlaU8n1BsqDKeymMpYDqIBk/7a3zfcrnGXiZZOKa89i+t97SPnLLRJFTkbuIXWT0LdWLBKxgW+oczVhnnsn12c/hZUPW/ENXGme2HmUP8Hh7yJFW88EW0cBMrTZOW3rX+bhXGpU3zaN3HtVg4EeNdD7dw248dYchpiO6ia/9c0Y0v4twStH0okdKAmi8FPNY7sCtZCfJw+0BM/T1OIHvJvzx9XLCDYI9l3KIXwYPHssrMK29IlEgQztakfCS9ZyNkpi65nH0t/703W0oGDjBk0SQCm4RMogLblIuOgwrhplBfvHsnHm+s52+1LbuJ4P1jG1cX0kmxCWAYYNY45kF5OafWuoFU09qLOxZqJOo7pCvo4eskRN4MCaQEWRYol+im6TtExYWrCIj4x7iLx2wep+k3YMCZIL9fBGpTHBIkEe4e1iozNptRO4i6SbCRikNnwLZkVPCfklGRgGCGGNoG2SwmoZQSVtXCoiIiPhVAZ4h/yXnMAiH1FcIg5jgSpZoyt/5IxqxEotD91rzb4Kt8Rwx/XYl/GzRylFTcy+vfQoefhtlutX/UV4hNosifd/ck0A23hz9wZnv3Wn3NQDOiQGxTOP8R4+8tvb2CjFmNMk5k5F/s+EIaclvyFWtPZi2vdJQl8/m7hYBeSVmexb9xMPT6j39bEGYyhOjvS1am5PfXPS9P19Zb/9MdmxW/pjy4S2FMhyfVHaYG9j0DMZTszoc2ror5Yjnpp05/ttUOzRsWJwm8p/eb75ZqHgMp3MxYm+3+SxNScQ+ujqHoBjT1hwtSi3J/tcy2sIx6PNM31Osagb1R5KLVdS3fM11002rOpARp2XrtZe2VyBDsp9Y9zr30mnPPtnnIkcqxcYhIjnsMuixDSjWQZdf0V/74oskCcU6NrYaDYxi+/4RrBCFhJednmej3sOT18rXOxDOFcExXgKEx5PATBFSwuMJEBzklsFsPQmF/SP1W9Gj/0T/l2jUaPtEqbeGPM5Q6mxAnXtx9LUrKnwOl3IupvadSijpDO+UnCZqiNcnWEXMuoPUTd2KiWgNbVuiUfckz5Xv8QF32tOdyG692G4PDGHf2b76/rEhTaQlfNtieG2I3ZVOg3xZN7LerMzyFmX+ylQmEz23ZwT27nP8jtsNaoJ073jvcXOCDp6UEe3kMRd/mvScg1EooX3uk7f0aBTXp2HO8DnTe7cWR1to4vXFlu7/5luDpdn5zvtt4uZ8k+8B+iq3nra5us5kMZXSUlx05+ufy+VcirRJmCqPGuMlulA/u2zFbg3a0ianp7bv/WidFD/k9pwYqibs/EGD6YHyI2E07YGDeBdqmsOraBQHt0jMMtwIIXCzRszGlOCap6I3wFUFzomHL8VmDD1VtElhYsb6oDx7FWSBqBkxMGCc0oN0fkc0chABSZHhJAiyEIQnSLgrQXJu8p6uUnLKbnJScgRZJSklWQWClIeSPN7LlUCQl/Ny/wkBDQI9RszJHhLPbVJU5L8ccKYrHJX15wj4S4AKCg4lgSBsLbAZw0YM2y9ivi5IJAUpSkFKJAR03YCANhDcV9mAgLp/WcAqCP6XIsIgLFJxHAguYVAQ8DtvRhNRIGCSbSa372Pw8YLXjziMChj3+QnfKBecG9DpE7xWt4syJTfvLn40OH+JmauaQjnuDbQFx/+K7naWd2Pgvvm9WafSiIrHT+9/aIhqu1BpP51eX+EF0JUZC/W9GHWiQHWJynluUd5fmSV+tKtkjFKF84dajIZhpslRayHqkZpb1FO7FW/mOyt8qtDSWWhKrqZtlX8qnOyy5D0tGvblEIRhPOR9z0h+5y6+0Y5Uiv3O+ecLd/OICVMx9n0iPnygQCF2cSwjIC0OuHPGYaoH47lQSmdrdW8mJ2W2mOX4bfIb7pauKDNbA85PC+FMXZe/zrX7ujSWFtL67hd5t1+Nyw/fMUX38UaidvIUvoAcIOyt5z10lVJgYns1W19tM8t7xUmPh34sKIGbh2STVXrzr7SesJcsAa0SQZeZmLbo6vd9/ZafXcITdOxZlUSsGs1nnXcPfHli8QL/iMNdXjx7X7GXost9G9np2q4mSYFzOtxTC94Gl8a0OugPWdiV6aFchXewtzhmjp/RCB51gIz3xveZe5eVT9G9U738cSSKe+iTHXtQY0pA5DCvndDSG4O6t1UfazUwm/TM+7D+6cyxU13Dn4Vfbd6C8baQpj+16YvWknp6Cn6+oqluRMXyhbhs3DaPdM9+T8Yrz3fVX/K3XGw5vJv1hmR3aF7JuBNlm65uuVjSexAf4Bx2czsMl0RyCpgDppc5gNqV1UeOBP2cv+/AupDQlJoqQzjl+IykB8jOioatEc8ObfpJSLVmrLAZSizDpuA6bFoGBcHYCZuur5evu2uYJ69meJhPUIhvWBSC7ZAiJAfJ4gnyspAyjO0EPCkpCyHJf68H/VfwXlzqXzPw3CBDfK+fNPtQ8/DrzlwLAfPK7pdspoL0U70VvcaVYRAv4zuKR9ZZLIaZm7UyLuY4QsLPAL+xmOb3KRT0X+gwOR9S7vHclRVMLpyZ8+aUXIwZPcg1MWp6srRNwKor9Zvufaoe56qeai1M2dfT/se9n4i+0LOqTuoZEdWTFrmQZGZjiX2DllzYlZYGBSbP2kOF3/Y9zq4b48veN/8AN0tZbxVgeUk3rdgA2KbvxSgi5nUm+81D8oRtZV8TKxj1mamIxYmTNpE/wDwuc8oDAAOkN1n/SkCv8YaUdXEVd6QmPuJe/sCW/cdLXVGXuWhrFr/k14Ld/EbWS1/JOtp5aVbh/TzcIhUQ/RrikEFo+N8GOP9l55IGUdNjMLD9JUEM5FQrlMACIhIASshZxuaENCghNZ6Z7gJxp8Z2kewRIdyi+BC1VZb9m1Ol7qdc/3HzJDJEVbKWbisprzQOtZujwEl7QubLpGAI6UO6Jdolmknqf79bvKYOgUtEoJxECNYbCMEAgtltAyEo/S9dYuR7aC/n+je7w3BbM2Qf6nBE6yi8HL9UGfG8O8rCBKyRDtvtEIDFne++HnOsQbqPqexIgFuDLequKS/OPPdltMawbWOVXR7nEBeYdKExcuZwz/st4NTw9WPUZLdTDYY/WLG8NDuf8WY0ddej+La3mTPkMgfQ4+nigvzBC58X30TmStN+oRgObmIzLTzqRx2S1VCqXOAt1WlBN+HmqM6ac5hXfZiCg/D1Hn7bHryqRAjN7Ylg1aUD1LiBdmrXox+eNGx6Z3o4rlNewvlky7umWBqtmD6rEL4pqKsx0tPRAdxEzUz34BlzzqetV73s6qRkRr8eSLpnsX2sMDjT/4Kycd/nqJZzbNFuYtNl+WJy5BEcbndUuQN4iB9obkk23teuG/n6Pvby61NnwuQbTDt3CzAJ76HZanlk9w49beamurpqE+/bxVpL8VF88UUskNeYFpMzx+0ifr4e7XGJ8cY5g3uSff2EeGNhcQNBlx0T26dPv8ot7FIJak4QCSNnnNrD15JPbBOxvlKzSzWldI/rpcBS3OmWc/ofmIK+HyL41/4YsLh9ROCOV3MhVzKTB0pVqsr+WMMbvpHL1V3ulyKtyfo0pc0vZFaXR56vKzkRzvE0IxkXzi9DOEMZWOJwRKilZDqxi+/xO26zO3lThoNfQM+gFJrY27633wZOVGR348WW6DodHPtNNpf2f5MpUpe2YfW7gzv5HSJSRENEMrdVKqBLe0CiAvTvRwEJB/8RKCZA0LJDiv0dh1wfEOBh2lAiQPLKy6ShQEriIST5rw9YiKg/cgcK4Q4UzB2wz53/8C2EgVO6sj/wHJHBRO7azBU7vmKtzeJ+4zvMzzWQK3FgDK/FdWC5Xyr63WTqp/mg1J5LXn1b+RHIjNd6mEIb5ZG8L3OnoH9VkWHBuI/zg4F8q1pqyY6qp2clLkZTVT05Yd+1k4Ns3GvPGMFSmElm9Dyl+f06nXqn/hvS6PDzPrN3A2ZVHEtZ5/SuDSp5XAj0kI88XeJOL/VQ4/j861cUtI8co8oNxUZpr5fgIq5nqk4vvJbYwcBjsl20LDpkkEml3tC5f3JSO33/05jamKTNT9VqjjiNpZglcsyUyti/SdsidVHWrrNe7QfhYR1ataa2KkNp34PCeMlPptvT+eSFOpQDPeKsrhXQV7ILJN6du4ZOSv3i8qHHsuVIZnJTK1+YkAub6JV7IqJKQjnK2xTu763JuMgpUHHW670rz64hUcNCl4PDQk4P+YzULG9ctlUXRH/ojXaQeSTwOtiJ3kIvom4eGGq6gCK6PG9lqWve3GdjNKpcSj8uYNjE1qCzV/dNW0dI9GDIqOBAi15u53Q7p+3z/anvTQyhivNHB947FFctvqz2Gm7LToiZfDxpNGooVoETPV0R6x3/9pBbpEutTOIT2wLHlghR0Y+TAR2ixySPaSiatQ0d0Em5QWXc2VeuLROW9SVwPpLXThLntDMrT81MNvFZ9cFNr4pM505UN+mV+Oc8GHx88Mgad07C3Dn+C/pbJ89fjkvY1y5gRmGw3NSAFRAOuAHagObPvPoHUt444gmRUkHh07SvMpOZDk1U3ML3CqTIQTuWyQ2ZQDUrMSkxSjL8n+Z8YL+FvRZ21rVBiQsk60IgkGjOeQPNWULmkOkGmtP6ezT3X/IPgxKKkcrzYhKyoYRMKCF9rZGk0VDCfkh9tTgUyCr7V8MsjyD3UPib+Qa4hkS5B4dK+4QFQBprGaAgOW4CLxdgDHgC3oAr4A+4AMGkOWVfwB2IglOhQBgsR+aXA+APsgFCmpfrVwMx75mk8pxB6ygO6Yf9Yd78+TQnGIfcM3K1TsQ+iMKmtXm6SEuqzXeE9Abs/3FdfYy6a0uL/tmTs77P3Vv45cuznTwT02IP65nb9GMz9j7gMOKc3ap12LKn+rvfazUKabH8t6qby/suc0VkKg+Pe9zRUY2MFpjFxZ5OC9ufOndXGKUn3n6IofHUWTJs/qTPNx/prBJxdXE/O0N3HirfwB05J97sn2s9Nqsn8WpxS0+z/HSg0MWRKpHJnpezdFW5otk5JnSqNDOUKY95Oghswx86pbodii4ZKlPfpG6/WXlxpPbpc5aDFrp2SoTdIhxxNXMi868kVXh9c2rtU3wCgyrqwzo0yMhPg+KiakR1nIkXTWudyaehY3GcQSyxuhV7RjTEPU92OFm6JXVwuStkJw08m52fYS3NExn6rTy7Z8rJXfO1A0VBshp5BHkveU04D/N1V9fLH17c3Iy5PqB5i0506pWnzPvsz6WOJ/qBx6V6zfaz2eVURgYMufE8PYBYZ01+ubpuBLf8zQdlZcXR0fzfDLJ4zi/oC8R/Kppv8as3yh5+Fx7J8X5CMTeKzWjpcZ2AT/jbqm+Lh9/RxE/4bqlahCYxxkcHBsID3NNVewu3m5q1xNvyl0YyEviipzWpa9QXztw75dRWejDfdvd2UwPdVq07+XscqOMN/L5HFbc1BwTsumMZiqONNv8NT8RUQ0TMBRQIQglZ/zZx/Xo2cH1ppCThBgI+K0ZMhcZjN667wLVYT9Hg6aCNWhZIYP1CDB6GtpPRrRWpGa/Ipl3soq+h7ySKbP/+BPLYcAkWvx2yLhGPFwVMSI4VArsYsnTjBbsTL2ANOxridN6w3BU+8gGiSoXjBf/Us62jgoO8Q1yDfaJ4f8fNGCIIuJn95vc9u/thudau6+NlpV1vuaW5nrBon0n3PuAufSxptz6G7LrMXR3nM1Y2j3Z0h/t4WPNf4zzKKvpDyURWv9ft9tlvE7blEh+1R8bVdNXvG3q7OCUsJA2b1RCAccrDlw7sjIZMDeytuQ4N8ieI1St2N3KJWGm7ZrnOnHoQFvVksT5S1elwVODZkMvCnS/br88GRwQuWoTz0Q08LigX4QuXv8TZnRfv8G72wKnYl7v1Ti9EMmg/18vko/QZTfhtRHA6WK+kKKJRt3PTJonoh1bznuZ042Wf+ne3vqeDHEsStqjrNEdgho4fZ7C9kFwENny1uEteumvsk7JIzBHjiBNjR5XYPs+VElGicPdEcP0ekeOJKBZYxEgyzaP/2kD81+tsG2zSCWLbaJI06+uFIFz4moYMT49MI+PxeDlITk4OL7fjDxZpAhx44j4nfmNm21XtScvRb4MeKJHfDZkQW5Ef7w1njH3UIMSLkrx1yZuQ6dtNjE7ZzCNVxSg8c2Yz5YWPDYZ3mzwSPtnO4H8UDxHCe1mFvE9errGAUfK81sxIKLivxd9jKDNqwupjqXtZkVlEhiKzrTNn8KO4sf6lwcu+ZTsvumXZ7bhIMU7Bfncx9Mrj2ALK1vxU4TsnVd6JexuVoyI1anvajJJ8as+qPWYI0jwZ+i3kKzhXT2d2z7n5tA6ry4XXzfZ9TrsWWijYFStlYm9fz8pr6C+aZixV1tKsT8sh0m5xDtf221V2VVrENPbupXsVAzlTiV0NexT8czY5nPjKFhvhWjAuTTbrqNisly4qYvda4MFoV+CZx/HyLzVqkJ8B+Q+6ZXLJDQplbmRzdHJlYW0NCmVuZG9iag0KMjggMCBvYmoNClsgMFsgNjAwXSAgM1sgNjAwXSAgMTFbIDYwMCA2MDBdICAxNVsgNjAwIDYwMCA2MDAgNjAwXSAgMjBbIDYwMCA2MDAgNjAwXSAgMjVbIDYwMF0gIDI5WyA2MDBdICAzNlsgNjAwXSAgMzhbIDYwMCA2MDAgNjAwXSAgNDNbIDYwMCA2MDBdICA0OFsgNjAwIDYwMF0gIDUxWyA2MDAgNjAwXSAgNTVbIDYwMF0gIDU3WyA2MDBdICA2OFsgNjAwIDYwMCA2MDAgNjAwIDYwMCA2MDAgNjAwIDYwMCA2MDBdICA3OFsgNjAwIDYwMCA2MDAgNjAwIDYwMCA2MDBdICA4NVsgNjAwIDYwMCA2MDAgNjAwIDYwMF0gIDkxWyA2MDAgNjAwXSAgMTEyWyA2MDAgNjAwXSAgMTM1WyA2MDBdIF0gDQplbmRvYmoNCjI5IDAgb2JqDQpbIDYwMCAwIDAgMCAwIDAgMCAwIDYwMCA2MDAgMCAwIDYwMCA2MDAgNjAwIDYwMCAwIDYwMCA2MDAgNjAwIDAgMCA2MDAgMCAwIDAgNjAwIDAgMCAwIDAgMCAwIDYwMCAwIDYwMCA2MDAgNjAwIDAgMCA2MDAgNjAwIDAgMCAwIDYwMCA2MDAgMCA2MDAgNjAwIDAgMCA2MDAgMCA2MDAgMCAwIDAgMCAwIDAgMCAwIDAgMCA2MDAgNjAwIDYwMCA2MDAgNjAwIDYwMCA2MDAgNjAwIDYwMCAwIDYwMCA2MDAgNjAwIDYwMCA2MDAgNjAwIDAgNjAwIDYwMCA2MDAgNjAwIDYwMCAwIDYwMCA2MDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDYwMCA2MDBdIA0KZW5kb2JqDQozMCAwIG9iag0KPDwvVHlwZS9YUmVmL1NpemUgMzAvV1sgMSA0IDJdIC9Sb290IDEgMCBSL0luZm8gMTQgMCBSL0lEWzw5QTcxRTUyNjY1NUZEQTQwOUY4RjBBNTk1QUIzRTVBMj48OUE3MUU1MjY2NTVGREE0MDlGOEYwQTU5NUFCM0U1QTI+XSAvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMDk+Pg0Kc3RyZWFtDQp4nDXMMQ5AQBAF0L/YtYRC4RCO4wI6x3AJ91BKFGo3IQqlRMmYzxTz8pM/A8jct5FdAC8dGRWzKLZWHMipxBVpyK54RwZyKckBBHJbwpGYeGLJV0nkIJ3+ZEhAQhJJJWv1dd4rK9M2Aw+Z9Q9+DQplbmRzdHJlYW0NCmVuZG9iag0KeHJlZg0KMCAzMQ0KMDAwMDAwMDAxNSA2NTUzNSBmDQowMDAwMDAwMDE3IDAwMDAwIG4NCjAwMDAwMDAxMjUgMDAwMDAgbg0KMDAwMDAwMDE4MSAwMDAwMCBuDQowMDAwMDAwNDU0IDAwMDAwIG4NCjAwMDAwMDEzNjEgMDAwMDAgbg0KMDAwMDAwMTUzNiAwMDAwMCBuDQowMDAwMDAxNzgwIDAwMDAwIG4NCjAwMDAwMDE4MzMgMDAwMDAgbg0KMDAwMDAwMTg4NiAwMDAwMCBuDQowMDAwMDAyMDI0IDAwMDAwIG4NCjAwMDAwMDIwNTQgMDAwMDAgbg0KMDAwMDAwMjIyMSAwMDAwMCBuDQowMDAwMDAyMjk1IDAwMDAwIG4NCjAwMDAwMDI1NDAgMDAwMDAgbg0KMDAwMDAwMDAxNiA2NTUzNSBmDQowMDAwMDAwMDE3IDY1NTM1IGYNCjAwMDAwMDAwMTggNjU1MzUgZg0KMDAwMDAwMDAxOSA2NTUzNSBmDQowMDAwMDAwMDIwIDY1NTM1IGYNCjAwMDAwMDAwMjEgNjU1MzUgZg0KMDAwMDAwMDAyMiA2NTUzNSBmDQowMDAwMDAwMDIzIDY1NTM1IGYNCjAwMDAwMDAwMjQgNjU1MzUgZg0KMDAwMDAwMDAyNSA2NTUzNSBmDQowMDAwMDAwMDAwIDY1NTM1IGYNCjAwMDAwMDMxNzMgMDAwMDAgbg0KMDAwMDAwMzQ3NCAwMDAwMCBuDQowMDAwMDU4NzI1IDAwMDAwIG4NCjAwMDAwNTkwNjggMDAwMDAgbg0KMDAwMDA1OTU5MSAwMDAwMCBuDQp0cmFpbGVyDQo8PC9TaXplIDMxL1Jvb3QgMSAwIFIvSW5mbyAxNCAwIFIvSURbPDlBNzFFNTI2NjU1RkRBNDA5RjhGMEE1OTVBQjNFNUEyPjw5QTcxRTUyNjY1NUZEQTQwOUY4RjBBNTk1QUIzRTVBMj5dID4+DQpzdGFydHhyZWYNCjU5OTAxDQolJUVPRg0KeHJlZg0KMCAwDQp0cmFpbGVyDQo8PC9TaXplIDMxL1Jvb3QgMSAwIFIvSW5mbyAxNCAwIFIvSURbPDlBNzFFNTI2NjU1RkRBNDA5RjhGMEE1OTVBQjNFNUEyPjw5QTcxRTUyNjY1NUZEQTQwOUY4RjBBNTk1QUIzRTVBMj5dIC9QcmV2IDU5OTAxL1hSZWZTdG0gNTk1OTE+Pg0Kc3RhcnR4cmVmDQo2MDY3OA0KJSVFT0Y=",
              "title" : "contexte-actuel-Jeanne-L.pdf"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIDocumentReference"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Goal/tddui-pp-pa-goal-attente-famille-example",
      "resource" : {
        "resourceType" : "Goal",
        "id" : "tddui-pp-pa-goal-attente-famille-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-attente"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Goal_tddui-pp-pa-goal-attente-famille-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : But tddui-pp-pa-goal-attente-famille-example</b></p><a name=\"tddui-pp-pa-goal-attente-famille-example\"> </a><a name=\"hctddui-pp-pa-goal-attente-famille-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-goal-attente.html\">TDDUI Goal Attente</a></p></div><p><b>Lien vers le projet personnalisé</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>identifier</b>: <code>https://identifiant-medicosocial-attente.esante.gouv.fr</code>/3480787529/123456789-ATTE-1234</p><p><b>lifecycleStatus</b>: Active</p><p><b>description</b>: <span title=\"Codes :\">- Prévenir les chutes<br/>- Stabiliser le poids et le plaisir alimentaire<br/>- Maintenir le lien familial (visios)</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>note</b>: </p><blockquote><div><p>Famille</p>\n</div></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-reference",
            "valueReference" : {
              "reference" : "CarePlan/tddui-pp-pa-careplan-example"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-attente.esante.gouv.fr",
            "value" : "3480787529/123456789-ATTE-1234"
          }
        ],
        "lifecycleStatus" : "active",
        "description" : {
          "text" : "- Prévenir les chutes\n- Stabiliser le poids et le plaisir alimentaire\n- Maintenir le lien familial (visios)"
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-discriminator",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-discriminator-cs",
                      "code" : "origineAttente"
                    }
                  ]
                }
              }
            ],
            "text" : "Famille"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIGoalAttente"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Goal/tddui-pp-pa-goal-attente-usager-example",
      "resource" : {
        "resourceType" : "Goal",
        "id" : "tddui-pp-pa-goal-attente-usager-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-attente"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Goal_tddui-pp-pa-goal-attente-usager-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : But tddui-pp-pa-goal-attente-usager-example</b></p><a name=\"tddui-pp-pa-goal-attente-usager-example\"> </a><a name=\"hctddui-pp-pa-goal-attente-usager-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-goal-attente.html\">TDDUI Goal Attente</a></p></div><p><b>Lien vers le projet personnalisé</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>identifier</b>: <code>https://identifiant-medicosocial-attente.esante.gouv.fr</code>/3480787529/123456789-ATTE-1235</p><p><b>lifecycleStatus</b>: Active</p><p><b>description</b>: <span title=\"Codes :\">- Garder la main sur l'organisation de ses journées <br/>- Participer à une chorale et à un club lecture<br/>- Se sentir en sécurité lors des déplacements</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>note</b>: </p><blockquote><div><p>Usager</p>\n</div></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-reference",
            "valueReference" : {
              "reference" : "CarePlan/tddui-pp-pa-careplan-example"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-attente.esante.gouv.fr",
            "value" : "3480787529/123456789-ATTE-1235"
          }
        ],
        "lifecycleStatus" : "active",
        "description" : {
          "text" : "- Garder la main sur l'organisation de ses journées \n- Participer à une chorale et à un club lecture\n- Se sentir en sécurité lors des déplacements"
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-discriminator",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-discriminator-cs",
                      "code" : "origineAttente"
                    }
                  ]
                }
              }
            ],
            "text" : "Usager"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIGoalAttente"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Goal/tddui-pp-pa-goal-objectif-1-example",
      "resource" : {
        "resourceType" : "Goal",
        "id" : "tddui-pp-pa-goal-objectif-1-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Goal_tddui-pp-pa-goal-objectif-1-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : But tddui-pp-pa-goal-objectif-1-example</b></p><a name=\"tddui-pp-pa-goal-objectif-1-example\"> </a><a name=\"hctddui-pp-pa-goal-objectif-1-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-goal-objectif.html\">TDDUI Goal Objectif</a></p></div><p><b>Lien vers le projet personnalisé</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>Pièce jointe</b>: <a href=\"DocumentReference-tddui-pp-pa-documentreference-bilan-objectif-1-example.html\">DocumentReference : masterIdentifier = 3480787529/123456789-PPER-bilanObj-1234; status = current</a></p><p><b>identifier</b>: <code>https://identifiant-medicosocial-objectif.esante.gouv.fr</code>/3480787529/123456789-OBJE-1234</p><p><b>lifecycleStatus</b>: Active</p><p><b>description</b>: <span title=\"Codes :\">Réduire le risque de chute et la peur associée en 6 mois.</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>addresses</b>: <a href=\"ServiceRequest-tddui-pp-pa-servicerequest-besoin-1-example.html\">ServiceRequest </a></p><p><b>note</b>: </p><blockquote><div><p>Objectif 1</p>\n</div></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-reference",
            "valueReference" : {
              "reference" : "CarePlan/tddui-pp-pa-careplan-example"
            }
          },
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-attachment",
            "valueReference" : {
              "reference" : "DocumentReference/tddui-pp-pa-documentreference-bilan-objectif-1-example"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-objectif.esante.gouv.fr",
            "value" : "3480787529/123456789-OBJE-1234"
          }
        ],
        "lifecycleStatus" : "active",
        "description" : {
          "text" : "Réduire le risque de chute et la peur associée en 6 mois."
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "addresses" : [
          {
            "reference" : "ServiceRequest/tddui-pp-pa-servicerequest-besoin-1-example"
          }
        ],
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-discriminator",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-discriminator-cs",
                      "code" : "titreObjectif"
                    }
                  ]
                }
              }
            ],
            "text" : "Objectif 1"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIGoalObjectif"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Goal/tddui-pp-pa-goal-objectif-2-example",
      "resource" : {
        "resourceType" : "Goal",
        "id" : "tddui-pp-pa-goal-objectif-2-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Goal_tddui-pp-pa-goal-objectif-2-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : But tddui-pp-pa-goal-objectif-2-example</b></p><a name=\"tddui-pp-pa-goal-objectif-2-example\"> </a><a name=\"hctddui-pp-pa-goal-objectif-2-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-goal-objectif.html\">TDDUI Goal Objectif</a></p></div><p><b>Lien vers le projet personnalisé</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>identifier</b>: <code>https://identifiant-medicosocial-objectif.esante.gouv.fr</code>/3480787529/123456789-OBJE-1235</p><p><b>lifecycleStatus</b>: Active</p><p><b>description</b>: <span title=\"Codes :\">Stabiliser l'état nutritionnel et restaurer le plaisir alimentaire sur 12 mois.</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>addresses</b>: <a href=\"ServiceRequest-tddui-pp-pa-servicerequest-besoin-2-example.html\">ServiceRequest </a></p><p><b>note</b>: </p><blockquote><div><p>Objectif 2</p>\n</div></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-reference",
            "valueReference" : {
              "reference" : "CarePlan/tddui-pp-pa-careplan-example"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-objectif.esante.gouv.fr",
            "value" : "3480787529/123456789-OBJE-1235"
          }
        ],
        "lifecycleStatus" : "active",
        "description" : {
          "text" : "Stabiliser l'état nutritionnel et restaurer le plaisir alimentaire sur 12 mois."
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "addresses" : [
          {
            "reference" : "ServiceRequest/tddui-pp-pa-servicerequest-besoin-2-example"
          }
        ],
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-discriminator",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-discriminator-cs",
                      "code" : "titreObjectif"
                    }
                  ]
                }
              }
            ],
            "text" : "Objectif 2"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIGoalObjectif"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Goal/tddui-pp-pa-goal-objectif-3-example",
      "resource" : {
        "resourceType" : "Goal",
        "id" : "tddui-pp-pa-goal-objectif-3-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Goal_tddui-pp-pa-goal-objectif-3-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : But tddui-pp-pa-goal-objectif-3-example</b></p><a name=\"tddui-pp-pa-goal-objectif-3-example\"> </a><a name=\"hctddui-pp-pa-goal-objectif-3-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-goal-objectif.html\">TDDUI Goal Objectif</a></p></div><p><b>Lien vers le projet personnalisé</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>identifier</b>: <code>https://identifiant-medicosocial-objectif.esante.gouv.fr</code>/3480787529/123456789-OBJE-1236</p><p><b>lifecycleStatus</b>: Active</p><p><b>description</b>: <span title=\"Codes :\">Maintenir le lien social.</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p><p><b>addresses</b>: <a href=\"ServiceRequest-tddui-pp-pa-servicerequest-besoin-3-example.html\">ServiceRequest </a></p><p><b>note</b>: </p><blockquote><div><p>Objectif 3</p>\n</div></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-reference",
            "valueReference" : {
              "reference" : "CarePlan/tddui-pp-pa-careplan-example"
            }
          }
        ],
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-objectif.esante.gouv.fr",
            "value" : "3480787529/123456789-OBJE-1236"
          }
        ],
        "lifecycleStatus" : "active",
        "description" : {
          "text" : "Maintenir le lien social."
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "addresses" : [
          {
            "reference" : "ServiceRequest/tddui-pp-pa-servicerequest-besoin-3-example"
          }
        ],
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-discriminator",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-discriminator-cs",
                      "code" : "titreObjectif"
                    }
                  ]
                }
              }
            ],
            "text" : "Objectif 3"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIGoalObjectif"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Practitioner/tddui-pp-pa-practitioner-ide-example",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "tddui-pp-pa-practitioner-ide-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_tddui-pp-pa-practitioner-ide-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Praticien tddui-pp-pa-practitioner-ide-example</b></p><a name=\"tddui-pp-pa-practitioner-ide-example\"> </a><a name=\"hctddui-pp-pa-practitioner-ide-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-practitioner.html\">TDDUI Practitioner</a></p></div><p><b>identifier</b>: <code>urn:oid:1.2.250.1.71.4.2.1</code>/10101234567</p><p><b>name</b>: Élodie Bernard </p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R48-DiplomeEtatFrancais/FHIR/TRE-R48-DiplomeEtatFrancais DE09}\">DE Infirmier</span></td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "urn:oid:1.2.250.1.71.4.2.1",
            "value" : "10101234567"
          }
        ],
        "name" : [
          {
            "family" : "Bernard",
            "given" : ["Élodie"],
            "prefix" : ["MME"]
          }
        ],
        "qualification" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "https://mos.esante.gouv.fr/NOS/TRE_R48-DiplomeEtatFrancais/FHIR/TRE-R48-DiplomeEtatFrancais",
                  "code" : "DE09",
                  "display" : "DE Infirmier"
                }
              ]
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIPractitioner"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/QuestionnaireResponse/tddui-pp-pa-questionnaire-response-aggir-pa-example",
      "resource" : {
        "resourceType" : "QuestionnaireResponse",
        "id" : "tddui-pp-pa-questionnaire-response-aggir-pa-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"QuestionnaireResponse_tddui-pp-pa-questionnaire-response-aggir-pa-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : RéponseQuestionnaire tddui-pp-pa-questionnaire-response-aggir-pa-example</b></p><a name=\"tddui-pp-pa-questionnaire-response-aggir-pa-example\"> </a><a name=\"hctddui-pp-pa-questionnaire-response-aggir-pa-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-questionnaire-response.html\">TDDUI QuestionnaireResponse</a></p></div><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 1px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top;\"><tr style=\"border: 2px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top\"><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Le linkID de lélément\">LinkID</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Texte de lélément\">Texte</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Nombre minimum et maximum de fois que lélément peut apparaître dans linstance\">Définition</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Le type de lélément\">Réponse</a><span style=\"float: right\"><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/></a></span></th></tr><tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck1.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_q_root.gif\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"QuestionnaireResponseRoot\" class=\"hierarchy\"/> tddui-pp-pa-questionnaire-response-aggir-pa-example</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\">Questionnaire :<a href=\"Questionnaire-tddui-questionnaire-aggir-pa-ssiad.html\">Évaluation AGGIR PA SSIAD</a></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: #F7F7F7\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck00.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin_end.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon-q-string.png\" alt=\".\" style=\"background-color: #F7F7F7; background-color: inherit\" title=\"Élément\" class=\"hierarchy\"/> resultat-eval</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\">Résultat évaluation</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"/><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><span><span><a href=\"https://interop.esante.gouv.fr/terminologies/1.4.0/CodeSystem-terminologie-cisis.html#terminologie-cisis-MED-341\">TerminologieCISIS - Terminologie des concepts non trouvés dans les autres terminologies: MED-341</a> (GIR-3)</span></span></td></tr>\r\n<tr><td colspan=\"4\" class=\"hierarchy\"><br/><a href=\"https://hl7.org/fhir/R4/formats.html#table\" title=\"Légende pour ce format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/> Documentation pour ce format</a></td></tr></table></div>"
        },
        "identifier" : {
          "system" : "https://identifiant-medicosocial-evaluation.esante.gouv.fr",
          "value" : "3480787529/123456789-EVAL-1234"
        },
        "questionnaire" : "https://interop.esante.gouv.fr/ig/fhir/tddui/Questionnaire/tddui-questionnaire-aggir-pa-ssiad",
        "status" : "completed",
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        },
        "item" : [
          {
            "linkId" : "resultat-eval",
            "text" : "Résultat évaluation",
            "answer" : [
              {
                "valueCoding" : {
                  "system" : "https://smt.esante.gouv.fr/fhir/CodeSystem/terminologie-cisis",
                  "code" : "MED-341",
                  "display" : "GIR-3"
                }
              }
            ]
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIQuestionnaireResponse"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/ServiceRequest/tddui-pp-pa-servicerequest-besoin-1-example",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "id" : "tddui-pp-pa-servicerequest-besoin-1-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_tddui-pp-pa-servicerequest-besoin-1-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : DemandeService tddui-pp-pa-servicerequest-besoin-1-example</b></p><a name=\"tddui-pp-pa-servicerequest-besoin-1-example\"> </a><a name=\"hctddui-pp-pa-servicerequest-besoin-1-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-service-request-besoin.html\">TDDUI ServiceRequest Besoin</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-besoin.esante.gouv.fr</code>/3480787529/123456789-BESO-1234</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>code</b>: <span title=\"Codes :\">Besoin d'aide pour la mobilité et les déplacements.</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-besoin.esante.gouv.fr",
            "value" : "3480787529/123456789-BESO-1234"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "status" : "active",
        "intent" : "plan",
        "code" : {
          "text" : "Besoin d'aide pour la mobilité et les déplacements."
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        }
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIServiceRequestBesoin"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/ServiceRequest/tddui-pp-pa-servicerequest-besoin-2-example",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "id" : "tddui-pp-pa-servicerequest-besoin-2-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_tddui-pp-pa-servicerequest-besoin-2-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : DemandeService tddui-pp-pa-servicerequest-besoin-2-example</b></p><a name=\"tddui-pp-pa-servicerequest-besoin-2-example\"> </a><a name=\"hctddui-pp-pa-servicerequest-besoin-2-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-service-request-besoin.html\">TDDUI ServiceRequest Besoin</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-besoin.esante.gouv.fr</code>/3480787529/123456789-BESO-1235</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>code</b>: <span title=\"Codes :\">Besoin en terme de nutrition et alimentation.</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-besoin.esante.gouv.fr",
            "value" : "3480787529/123456789-BESO-1235"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "status" : "active",
        "intent" : "plan",
        "code" : {
          "text" : "Besoin en terme de nutrition et alimentation."
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        }
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIServiceRequestBesoin"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/ServiceRequest/tddui-pp-pa-servicerequest-besoin-3-example",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "id" : "tddui-pp-pa-servicerequest-besoin-3-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_tddui-pp-pa-servicerequest-besoin-3-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : DemandeService tddui-pp-pa-servicerequest-besoin-3-example</b></p><a name=\"tddui-pp-pa-servicerequest-besoin-3-example\"> </a><a name=\"hctddui-pp-pa-servicerequest-besoin-3-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-service-request-besoin.html\">TDDUI ServiceRequest Besoin</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-besoin.esante.gouv.fr</code>/3480787529/123456789-BESO-1236</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>code</b>: <span title=\"Codes :\">Besoin de maintien du lien social et d'activités récréatives.</span></p><p><b>subject</b>: <a href=\"Patient-tddui-pp-pa-patient-example-pp.html\">Jeanne L. (official) Female, Date de Naissance inconnue ( Patient internal identifier: 3480787529/123456789)</a></p></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-besoin.esante.gouv.fr",
            "value" : "3480787529/123456789-BESO-1236"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "status" : "active",
        "intent" : "plan",
        "code" : {
          "text" : "Besoin de maintien du lien social et d'activités récréatives."
        },
        "subject" : {
          "reference" : "Patient/tddui-pp-pa-patient-example-pp"
        }
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUIServiceRequestBesoin"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-action-1-ergo-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-action-1-ergo-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-action-1-ergo-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-action-1-ergo-example</b></p><a name=\"tddui-pp-pa-task-action-1-ergo-example\"> </a><a name=\"hctddui-pp-pa-task-action-1-ergo-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-action.html\">TDDUI Task Action</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-action.esante.gouv.fr</code>/3480787529/123456789-ACTI-1235</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-ime-careplan-example.html\">CarePlan Projet personnalisé de Hugo en IME</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Évaluer et aménagr la chambre (éclairage, barres, tapis)</p><p><b>owner</b>: Ergothérapeute</p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem titre}\">Titre de l'action à mener.</span></p><p><b>value</b>: Action de l'ergothérapeute pour atteindre l'objectif 1</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem objectif}\">Objectif(s).</span></p><p><b>value</b>: <a href=\"Goal-tddui-pp-pa-goal-objectif-1-example.html\">Goal : extension = -&gt;CarePlan Projet personnalisé de Mme Jeanne L.,-&gt;DocumentReference : masterIdentifier = 3480787529/123456789-PPER-bilanObj-1234; status = current; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1234; lifecycleStatus = active; description = ; note = Objectif 1</a></p></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
            "value" : "3480787529/123456789-ACTI-1235"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-ime-careplan-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Évaluer et aménagr la chambre (éclairage, barres, tapis)",
        "owner" : {
          "display" : "Ergothérapeute"
        },
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Action de l'ergothérapeute pour atteindre l'objectif 1"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "objectif"
                }
              ]
            },
            "valueReference" : {
              "reference" : "Goal/tddui-pp-pa-goal-objectif-1-example"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskAction"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-action-1-ide-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-action-1-ide-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-action-1-ide-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-action-1-ide-example</b></p><a name=\"tddui-pp-pa-task-action-1-ide-example\"> </a><a name=\"hctddui-pp-pa-task-action-1-ide-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-action.html\">TDDUI Task Action</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-action.esante.gouv.fr</code>/3480787529/123456789-ACTI-1236</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-ime-careplan-example.html\">CarePlan Projet personnalisé de Hugo en IME</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Atelier éducation risque de chute</p><p><b>owner</b>: <a href=\"Practitioner-tddui-pp-pa-practitioner-ide-example.html\">Practitioner Élodie Bernard </a></p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem titre}\">Titre de l'action à mener.</span></p><p><b>value</b>: Action de l'IDE pour atteindre l'objectif 1</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem objectif}\">Objectif(s).</span></p><p><b>value</b>: <a href=\"Goal-tddui-pp-pa-goal-objectif-1-example.html\">Goal : extension = -&gt;CarePlan Projet personnalisé de Mme Jeanne L.,-&gt;DocumentReference : masterIdentifier = 3480787529/123456789-PPER-bilanObj-1234; status = current; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1234; lifecycleStatus = active; description = ; note = Objectif 1</a></p></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
            "value" : "3480787529/123456789-ACTI-1236"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-ime-careplan-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Atelier éducation risque de chute",
        "owner" : {
          "reference" : "Practitioner/tddui-pp-pa-practitioner-ide-example"
        },
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Action de l'IDE pour atteindre l'objectif 1"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "objectif"
                }
              ]
            },
            "valueReference" : {
              "reference" : "Goal/tddui-pp-pa-goal-objectif-1-example"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskAction"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-action-1-kine-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-action-1-kine-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-action-1-kine-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-action-1-kine-example</b></p><a name=\"tddui-pp-pa-task-action-1-kine-example\"> </a><a name=\"hctddui-pp-pa-task-action-1-kine-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-action.html\">TDDUI Task Action</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-action.esante.gouv.fr</code>/3480787529/123456789-ACTI-1237</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-ime-careplan-example.html\">CarePlan Projet personnalisé de Hugo en IME</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Programme équilibre/marche 2×/semaine 12 semaines</p><p><b>owner</b>: Kinésithérapeute</p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem titre}\">Titre de l'action à mener.</span></p><p><b>value</b>: Action du kinésithérapeute pour atteindre l'objectif 1</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem objectif}\">Objectif(s).</span></p><p><b>value</b>: <a href=\"Goal-tddui-pp-pa-goal-objectif-1-example.html\">Goal : extension = -&gt;CarePlan Projet personnalisé de Mme Jeanne L.,-&gt;DocumentReference : masterIdentifier = 3480787529/123456789-PPER-bilanObj-1234; status = current; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1234; lifecycleStatus = active; description = ; note = Objectif 1</a></p></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
            "value" : "3480787529/123456789-ACTI-1237"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-ime-careplan-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Programme équilibre/marche 2×/semaine 12 semaines",
        "owner" : {
          "display" : "Kinésithérapeute"
        },
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Action du kinésithérapeute pour atteindre l'objectif 1"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "objectif"
                }
              ]
            },
            "valueReference" : {
              "reference" : "Goal/tddui-pp-pa-goal-objectif-1-example"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskAction"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-action-2-anim-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-action-2-anim-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-action-2-anim-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-action-2-anim-example</b></p><a name=\"tddui-pp-pa-task-action-2-anim-example\"> </a><a name=\"hctddui-pp-pa-task-action-2-anim-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-action.html\">TDDUI Task Action</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-action.esante.gouv.fr</code>/3480787529/123456789-ACTI-12341</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-ime-careplan-example.html\">CarePlan Projet personnalisé de Hugo en IME</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Atelier cuisine mensuel co‑animé avec résidents</p><p><b>owner</b>: Animatrice</p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem titre}\">Titre de l'action à mener.</span></p><p><b>value</b>: Action de l'animatrice pour atteindre l'objectif 2</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem objectif}\">Objectif(s).</span></p><p><b>value</b>: <a href=\"Goal-tddui-pp-pa-goal-objectif-2-example.html\">Goal : extension = -&gt;CarePlan Projet personnalisé de Mme Jeanne L.; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1235; lifecycleStatus = active; description = ; note = Objectif 2</a></p></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
            "value" : "3480787529/123456789-ACTI-12341"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-ime-careplan-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Atelier cuisine mensuel co‑animé avec résidents",
        "owner" : {
          "display" : "Animatrice"
        },
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Action de l'animatrice pour atteindre l'objectif 2"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "objectif"
                }
              ]
            },
            "valueReference" : {
              "reference" : "Goal/tddui-pp-pa-goal-objectif-2-example"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskAction"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-action-2-ide-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-action-2-ide-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-action-2-ide-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-action-2-ide-example</b></p><a name=\"tddui-pp-pa-task-action-2-ide-example\"> </a><a name=\"hctddui-pp-pa-task-action-2-ide-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-action.html\">TDDUI Task Action</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-action.esante.gouv.fr</code>/3480787529/123456789-ACTI-12342</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-ime-careplan-example.html\">CarePlan Projet personnalisé de Hugo en IME</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Pesée mensuelle et dépistage dénutrition</p><p><b>owner</b>: <a href=\"Practitioner-tddui-pp-pa-practitioner-ide-example.html\">Practitioner Élodie Bernard </a></p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem titre}\">Titre de l'action à mener.</span></p><p><b>value</b>: Action de l'IDE pour atteindre l'objectif 2</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem objectif}\">Objectif(s).</span></p><p><b>value</b>: <a href=\"Goal-tddui-pp-pa-goal-objectif-2-example.html\">Goal : extension = -&gt;CarePlan Projet personnalisé de Mme Jeanne L.; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1235; lifecycleStatus = active; description = ; note = Objectif 2</a></p></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
            "value" : "3480787529/123456789-ACTI-12342"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-ime-careplan-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Pesée mensuelle et dépistage dénutrition",
        "owner" : {
          "reference" : "Practitioner/tddui-pp-pa-practitioner-ide-example"
        },
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Action de l'IDE pour atteindre l'objectif 2"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "objectif"
                }
              ]
            },
            "valueReference" : {
              "reference" : "Goal/tddui-pp-pa-goal-objectif-2-example"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskAction"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-action-3-psy-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-action-3-psy-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-action-3-psy-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-action-3-psy-example</b></p><a name=\"tddui-pp-pa-task-action-3-psy-example\"> </a><a name=\"hctddui-pp-pa-task-action-3-psy-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-action.html\">TDDUI Task Action</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-action.esante.gouv.fr</code>/3480787529/123456789-ACTI-1238</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-ime-careplan-example.html\">CarePlan Projet personnalisé de Hugo en IME</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Entretien de satisfaction semestriel</p><p><b>owner</b>: Psychologue</p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem titre}\">Titre de l'action à mener.</span></p><p><b>value</b>: Action du psychologue pour atteindre l'objectif 3</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem objectif}\">Objectif(s).</span></p><p><b>value</b>: <a href=\"Goal-tddui-pp-pa-goal-objectif-3-example.html\">Goal : extension = -&gt;CarePlan Projet personnalisé de Mme Jeanne L.; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1236; lifecycleStatus = active; description = ; note = Objectif 3</a></p></blockquote></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
            "value" : "3480787529/123456789-ACTI-1238"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-ime-careplan-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Entretien de satisfaction semestriel",
        "owner" : {
          "display" : "Psychologue"
        },
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Action du psychologue pour atteindre l'objectif 3"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-action-codesystem",
                  "code" : "objectif"
                }
              ]
            },
            "valueReference" : {
              "reference" : "Goal/tddui-pp-pa-goal-objectif-3-example"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskAction"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-moyen-ressource-ergo-1-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-moyen-ressource-ergo-1-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-moyen-ressource-ergo-1-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-moyen-ressource-ergo-1-example</b></p><a name=\"tddui-pp-pa-task-moyen-ressource-ergo-1-example\"> </a><a name=\"hctddui-pp-pa-task-moyen-ressource-ergo-1-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-moyen-ressource.html\">TDDUI Task MoyenRessource</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-moyenressource.esante.gouv.fr</code>/3480787529/123456789-MORE-1234</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>partOf</b>: <a href=\"Task-tddui-pp-pa-task-action-1-ergo-example.html\">Task : identifier = https://identifiant-medicosocial-action.esante.gouv.fr#3480787529/123456789-ACTI-1235; status = in-progress; intent = plan; description = Évaluer et aménagr la chambre (éclairage, barres, tapis)</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Barres d'appui et balisage lumineux (budget EHPAD)</p><h3>Inputs</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem titre}\">Titre du moyen ou de la ressource à utiliser.</span></td><td>Moyens mis en œuvre pour l'objectif 1 (avec rattachement SERAFIN‑PH)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-moyenressource.esante.gouv.fr",
            "value" : "3480787529/123456789-MORE-1234"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "partOf" : [
          {
            "reference" : "Task/tddui-pp-pa-task-action-1-ergo-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Barres d'appui et balisage lumineux (budget EHPAD)",
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Moyens mis en œuvre pour l'objectif 1 (avec rattachement SERAFIN‑PH)"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskMoyenRessource"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-moyen-ressource-ide-1-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-moyen-ressource-ide-1-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-moyen-ressource-ide-1-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-moyen-ressource-ide-1-example</b></p><a name=\"tddui-pp-pa-task-moyen-ressource-ide-1-example\"> </a><a name=\"hctddui-pp-pa-task-moyen-ressource-ide-1-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-moyen-ressource.html\">TDDUI Task MoyenRessource</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-moyenressource.esante.gouv.fr</code>/3480787529/123456789-MORE-1236</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>partOf</b>: <a href=\"Task-tddui-pp-pa-task-action-1-ide-example.html\">Task : identifier = https://identifiant-medicosocial-action.esante.gouv.fr#3480787529/123456789-ACTI-1236; status = in-progress; intent = plan; description = Atelier éducation risque de chute</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Temps de coordination IDE/médecin coordonnateur</p><h3>Inputs</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem titre}\">Titre du moyen ou de la ressource à utiliser.</span></td><td>Moyens mis en œuvre pour l'objectif 1 (avec rattachement SERAFIN‑PH)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-moyenressource.esante.gouv.fr",
            "value" : "3480787529/123456789-MORE-1236"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "partOf" : [
          {
            "reference" : "Task/tddui-pp-pa-task-action-1-ide-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Temps de coordination IDE/médecin coordonnateur",
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Moyens mis en œuvre pour l'objectif 1 (avec rattachement SERAFIN‑PH)"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskMoyenRessource"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-moyen-ressource-ide-2-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-moyen-ressource-ide-2-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-moyen-ressource-ide-2-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-moyen-ressource-ide-2-example</b></p><a name=\"tddui-pp-pa-task-moyen-ressource-ide-2-example\"> </a><a name=\"hctddui-pp-pa-task-moyen-ressource-ide-2-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-moyen-ressource.html\">TDDUI Task MoyenRessource</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-moyenressource.esante.gouv.fr</code>/3480787529/123456789-MORE-123615</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>partOf</b>: <a href=\"Task-tddui-pp-pa-task-action-2-ide-example.html\">Task : identifier = https://identifiant-medicosocial-action.esante.gouv.fr#3480787529/123456789-ACTI-12342; status = in-progress; intent = plan; description = Pesée mensuelle et dépistage dénutrition</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: Carnet de suivi poids</p><h3>Inputs</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem titre}\">Titre du moyen ou de la ressource à utiliser.</span></td><td>Moyens mis en œuvre pour l'objectif 2 (avec rattachement SERAFIN‑PH)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-moyenressource.esante.gouv.fr",
            "value" : "3480787529/123456789-MORE-123615"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "partOf" : [
          {
            "reference" : "Task/tddui-pp-pa-task-action-2-ide-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "Carnet de suivi poids",
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Moyens mis en œuvre pour l'objectif 2 (avec rattachement SERAFIN‑PH)"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskMoyenRessource"
      }
    },
    {
      "fullUrl" : "https://test-server.fr/Task/tddui-pp-pa-task-moyen-ressource-kine-1-example",
      "resource" : {
        "resourceType" : "Task",
        "id" : "tddui-pp-pa-task-moyen-ressource-kine-1-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_tddui-pp-pa-task-moyen-ressource-kine-1-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task tddui-pp-pa-task-moyen-ressource-kine-1-example</b></p><a name=\"tddui-pp-pa-task-moyen-ressource-kine-1-example\"> </a><a name=\"hctddui-pp-pa-task-moyen-ressource-kine-1-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-tddui-task-moyen-ressource.html\">TDDUI Task MoyenRessource</a></p></div><p><b>identifier</b>: <code>https://identifiant-medicosocial-moyenressource.esante.gouv.fr</code>/3480787529/123456789-MORE-1235</p><p><b>basedOn</b>: <a href=\"CarePlan-tddui-pp-pa-careplan-example.html\">CarePlan Projet personnalisé de Mme Jeanne L.</a></p><p><b>partOf</b>: <a href=\"Task-tddui-pp-pa-task-action-1-kine-example.html\">Task : identifier = https://identifiant-medicosocial-action.esante.gouv.fr#3480787529/123456789-ACTI-1237; status = in-progress; intent = plan; description = Programme équilibre/marche 2×/semaine 12 semaines</a></p><p><b>status</b>: In Progress</p><p><b>intent</b>: plan</p><p><b>description</b>: 30 h de kinésithérapie/6 mois</p><h3>Inputs</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem titre}\">Titre du moyen ou de la ressource à utiliser.</span></td><td>Moyens mis en œuvre pour l'objectif 1 (avec rattachement SERAFIN‑PH)</td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://identifiant-medicosocial-moyenressource.esante.gouv.fr",
            "value" : "3480787529/123456789-MORE-1235"
          }
        ],
        "basedOn" : [
          {
            "reference" : "CarePlan/tddui-pp-pa-careplan-example"
          }
        ],
        "partOf" : [
          {
            "reference" : "Task/tddui-pp-pa-task-action-1-kine-example"
          }
        ],
        "status" : "in-progress",
        "intent" : "plan",
        "description" : "30 h de kinésithérapie/6 mois",
        "input" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-moyen-ressource-codesystem",
                  "code" : "titre"
                }
              ]
            },
            "valueString" : "Moyens mis en œuvre pour l'objectif 1 (avec rattachement SERAFIN‑PH)"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "TDDUITaskMoyenRessource"
      }
    }
  ]
}

```

# TDDUI Task MoyenRessource - Médicosocial - Transfert de données DUI v2.3.0

## : TDDUI Task MoyenRessource 

 
Profil de la ressource Task permettant de représenter les moyens ou ressources utilisées dans le cadre du projet personnalisé. 

**Utilisations:**

* Utilise ce/t/te Profil: [TDDUI Bundle](StructureDefinition-tddui-bundle.md)
* Exemples pour ce/t/te Profil: [Task/tddui-pp-pa-task-moyen-ressource-ergo-1-example](Task-tddui-pp-pa-task-moyen-ressource-ergo-1-example.md), [Task/tddui-pp-pa-task-moyen-ressource-ide-1-example](Task-tddui-pp-pa-task-moyen-ressource-ide-1-example.md), [Task/tddui-pp-pa-task-moyen-ressource-ide-2-example](Task-tddui-pp-pa-task-moyen-ressource-ide-2-example.md) and [Task/tddui-pp-pa-task-moyen-ressource-kine-1-example](Task-tddui-pp-pa-task-moyen-ressource-kine-1-example.md)
* CapabilityStatements utilisant ce Profil: [TDDUI-Consommateur](CapabilityStatement-TDDUIConsommateur.md) and [TDDUI-Producteur](CapabilityStatement-TDDUIProducteur.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-task-moyen-ressource)

### 

 . 

*   
*   
*   
*   

#### Bindings terminologiques (différentiel)

#### Bindings terminologiques

#### Contraintes

** Résumé **

Obligatoire : 6 éléments

**Structures**

Cette structure fait référence à ces autres structures:

* [TDDUI CarePlan Projet Personalise (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-projet-personnalise)](StructureDefinition-tddui-careplan-projet-personnalise.md)
* [TDDUI Task Action (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action)](StructureDefinition-tddui-task-action.md)
* [TDDUI QuestionnaireResponse (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response)](StructureDefinition-tddui-questionnaire-response.md)
* [TDDUI DocumentReference (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference)](StructureDefinition-tddui-document-reference.md)

**Slices**

Cette structure définit les [slices](http://hl7.org/fhir/R4/profiling.html#slices) suivantes:

* The element 1 is sliced based on the value of Task.input

#### Bindings terminologiques (différentiel)

 **View** 

#### Bindings terminologiques

#### Contraintes

** Résumé **

Obligatoire : 6 éléments

**Structures**

Cette structure fait référence à ces autres structures:

* [TDDUI CarePlan Projet Personalise (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-projet-personnalise)](StructureDefinition-tddui-careplan-projet-personnalise.md)
* [TDDUI Task Action (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action)](StructureDefinition-tddui-task-action.md)
* [TDDUI QuestionnaireResponse (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response)](StructureDefinition-tddui-questionnaire-response.md)
* [TDDUI DocumentReference (https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference)](StructureDefinition-tddui-document-reference.md)

**Slices**

Cette structure définit les [slices](http://hl7.org/fhir/R4/profiling.html#slices) suivantes:

* The element 1 is sliced based on the value of Task.input

 

 ,  



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "tddui-task-moyen-ressource",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource",
  "version" : "2.3.0",
  "name" : "TDDUITaskMoyenRessource",
  "title" : "TDDUI Task MoyenRessource",
  "status" : "active",
  "date" : "2026-06-16T16:50:35+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Profil de la ressource Task permettant de représenter les moyens ou ressources utilisées dans le cadre du projet personnalisé.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "specmetier-to-TDDUITaskMoyenRessource",
    "uri" : "https://interop.esante.gouv.fr/ig/fhir/tddui/sfe_modelisation_contenu.html",
    "name" : "Modèle de contenu DUI"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Task",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Task",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Task",
      "path" : "Task",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "MoyenRessource"
      }]
    },
    {
      "id" : "Task.identifier",
      "path" : "Task.identifier",
      "short" : "Identifiant du moyen ou de la ressource",
      "min" : 1,
      "max" : "1",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "idMoyenRessource"
      }]
    },
    {
      "id" : "Task.identifier.system",
      "path" : "Task.identifier.system",
      "min" : 1,
      "patternUri" : "https://identifiant-medicosocial-moyenressource.esante.gouv.fr"
    },
    {
      "id" : "Task.identifier.value",
      "path" : "Task.identifier.value",
      "min" : 1,
      "example" : [{
        "label" : "du format d'identifiant à respecter : 3+FINESS/identifiantLocalUsagerESSMS-MORE-numMoyenRessource",
        "valueString" : "3480787529/123456789-MORE-1234"
      }]
    },
    {
      "id" : "Task.basedOn",
      "path" : "Task.basedOn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-projet-personnalise"]
      }],
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "ProjetPersonnalise"
      }]
    },
    {
      "id" : "Task.partOf",
      "path" : "Task.partOf",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"]
      }],
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "Action"
      }]
    },
    {
      "id" : "Task.code.text",
      "path" : "Task.code.text",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "typeMoyenRessource"
      }]
    },
    {
      "id" : "Task.description",
      "path" : "Task.description",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "descriptionMoyenRessource"
      }]
    },
    {
      "id" : "Task.executionPeriod.start",
      "path" : "Task.executionPeriod.start",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "dateDebutMoyenRessource"
      }]
    },
    {
      "id" : "Task.executionPeriod.end",
      "path" : "Task.executionPeriod.end",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "dateFinMoyenRessource"
      }]
    },
    {
      "id" : "Task.input",
      "path" : "Task.input",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "type"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Task.input.type",
      "path" : "Task.input.type",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://interop.esante.gouv.fr/ig/fhir/tddui/ValueSet/tddui-task-input-moyen-ressource"
      }
    },
    {
      "id" : "Task.input:titre",
      "path" : "Task.input",
      "sliceName" : "titre",
      "short" : "Titre du moyen ou de la ressource",
      "min" : 1,
      "max" : "1",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "titreMoyenRessource"
      }]
    },
    {
      "id" : "Task.input:titre.type",
      "path" : "Task.input.type",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-moyen-ressource",
          "code" : "titre"
        }]
      }
    },
    {
      "id" : "Task.input:titre.value[x]",
      "path" : "Task.input.value[x]",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "Task.input:evaluation",
      "path" : "Task.input",
      "sliceName" : "evaluation",
      "short" : "Evaluation",
      "min" : 0,
      "max" : "1",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "evaluationMoyenRessource"
      }]
    },
    {
      "id" : "Task.input:evaluation.type",
      "path" : "Task.input.type",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-moyen-ressource",
          "code" : "evaluation"
        }]
      }
    },
    {
      "id" : "Task.input:evaluation.value[x]",
      "path" : "Task.input.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"]
      }]
    },
    {
      "id" : "Task.input:pieceJointe",
      "path" : "Task.input",
      "sliceName" : "pieceJointe",
      "short" : "Pièce jointe associée",
      "min" : 0,
      "max" : "*",
      "mapping" : [{
        "identity" : "specmetier-to-TDDUITaskMoyenRessource",
        "map" : "pieceJointeMoyenRessource"
      }]
    },
    {
      "id" : "Task.input:pieceJointe.type",
      "path" : "Task.input.type",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-moyen-ressource",
          "code" : "pieceJointe"
        }]
      }
    },
    {
      "id" : "Task.input:pieceJointe.value[x]",
      "path" : "Task.input.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference"]
      }]
    }]
  }
}

```

# TDDUI Observation Type - Médicosocial - Transfert de données DUI v2.3.0

## CodeSystem: TDDUI Observation Type 

 
CodeSystem pour la défintion des types d'Observation 

* [TDDUIObservationType](ValueSet-tddui-observation-type.md)

-------

 . 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "tddui-observation-type",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-observation-type",
  "version" : "2.3.0",
  "name" : "TDDUIObservationType",
  "title" : "TDDUI Observation Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-16T11:08:56+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "CodeSystem pour la défintion des types d'Observation",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "PERIODESCOL",
    "display" : "Période scolaire"
  },
  {
    "code" : "OBSAMENAGEMENT",
    "display" : "Observation sur l’aménagement du moyen de transport"
  }]
}

```

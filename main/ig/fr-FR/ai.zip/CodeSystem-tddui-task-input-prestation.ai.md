# TDDUI Task Input Prestation - Médicosocial - Transfert de données DUI v2.3.0

## CodeSystem: TDDUI Task Input Prestation 

 
CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les prestations du projet personnalisé. 

* [TDDUITaskInputPrestation](ValueSet-tddui-task-input-prestation.md)

-------

 . 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "tddui-task-input-prestation",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-prestation",
  "version" : "2.3.0",
  "name" : "TDDUITaskInputPrestation",
  "title" : "TDDUI Task Input Prestation",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-16T08:52:34+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les prestations du projet personnalisé.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "compositional" : false,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "titre",
    "display" : "Titre de l'action à mener."
  },
  {
    "code" : "typePrestation",
    "display" : "Type de la prestation."
  },
  {
    "code" : "evaluation",
    "display" : "Evaluation de l'action."
  },
  {
    "code" : "pieceJointe",
    "display" : "Pièce(s) jointe(s) de l'action."
  }]
}

```

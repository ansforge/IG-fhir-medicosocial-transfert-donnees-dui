# Synthèse des flux - Médicosocial - Transfert de données DUI v2.4.0

## Synthèse des flux

**Les flux présentés ci-dessous doivent utiliser HTTPS**

* Processus métier: * Transfert des données d'un logiciel DUI

  * Flux techniques: * Flux 1.1 - Transmission de données DUI : interaction « transaction » de FHIR
* Flux 1.2 - Résultat de la transmission de données DUI : réponse à la requête HTTP POST
Lien vers la description détaillée :[flux 1](description_flux_1_transmission_donnees_dui.md)


# TDDUI PP PA Task Action 1 IDE Example - Médicosocial - Transfert de données DUI v2.3.0-ballot

## Example Task: TDDUI PP PA Task Action 1 IDE Example

Profile: [TDDUI Task Action](StructureDefinition-tddui-task-action.md)

**identifier**: `https://identifiant-medicosocial-action.esante.gouv.fr`/3480787529/123456789-ACTI-1236

**basedOn**: [CarePlan Projet personnalisé de Hugo en IME](CarePlan-tddui-pp-ime-careplan-example.md)

**status**: In Progress

**intent**: plan

**description**: Atelier éducation risque de chute

**owner**: [Practitioner Élodie Bernard ](Practitioner-tddui-pp-pa-practitioner-ide-example.md)

> **input****type**: Titre de l'action à mener.**value**: Action de l'IDE pour atteindre l'objectif 1

> **input****type**: Objectif(s).**value**: [Goal: extension = ->CarePlan Projet personnalisé de Mme Jeanne L.,->DocumentReference: masterIdentifier = 3480787529/123456789-PPER-bilanObj-1234; status = current; identifier = https://identifiant-medicosocial-objectif.esante.gouv.fr#3480787529/123456789-OBJE-1234; lifecycleStatus = active; description = ; note = Objectif 1](Goal-tddui-pp-pa-goal-objectif-1-example.md)



## Resource Content

```json
{
  "resourceType" : "Task",
  "id" : "tddui-pp-pa-task-action-1-ide-example",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"]
  },
  "identifier" : [{
    "system" : "https://identifiant-medicosocial-action.esante.gouv.fr",
    "value" : "3480787529/123456789-ACTI-1236"
  }],
  "basedOn" : [{
    "reference" : "CarePlan/tddui-pp-ime-careplan-example"
  }],
  "status" : "in-progress",
  "intent" : "plan",
  "description" : "Atelier éducation risque de chute",
  "owner" : {
    "reference" : "Practitioner/tddui-pp-pa-practitioner-ide-example"
  },
  "input" : [{
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-action",
        "code" : "titre"
      }]
    },
    "valueString" : "Action de l'IDE pour atteindre l'objectif 1"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-task-input-action",
        "code" : "objectif"
      }]
    },
    "valueReference" : {
      "reference" : "Goal/tddui-pp-pa-goal-objectif-1-example"
    }
  }]
}

```

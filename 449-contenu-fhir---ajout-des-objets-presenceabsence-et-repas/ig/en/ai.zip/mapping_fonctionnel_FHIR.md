# Mapping FHIR du modèle de contenu DUI - Médicosocial - Transfert de données DUI v2.3.0-ballot

## Mapping FHIR du modèle de contenu DUI

 Ce mapping représente les données fonctionnelles trouvant leur équivalence dans l'actuelle version des spécifications techniques. 

### Mapping Usager

### Mapping PeriodeScolaire

### Mapping Contact

### Mapping Entité Juridique

### Mapping Professionnel

### Mapping Sejour

### Mapping Evènement

### Mapping Présence Absence

### Mapping Repas

### Mapping Transport

### Mapping Evaluation

### Vue globale du Projet Personnalisé

#### Mapping Projet Personnalisé

##### Mapping Accord

#### Mapping Besoin

#### Mapping Objectif

#### Mapping MoyenRessource

#### Mapping Action

#### Mapping Prestation

#### Mapping Attente

#### Mapping Bilan


# Mapping FHIR du modèle de contenu DUI - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Mapping FHIR du modèle de contenu DUI**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

## Mapping FHIR du modèle de contenu DUI

* [Mapping global](#mapping-global)
* [Mapping Usager](#mapping-usager)
* [Mapping Sejour & EntiteJuridique](#mapping-sejour--entitejuridique)
* [Mapping Professionnel](#mapping-professionnel)
* [Mapping Evènement](#mapping-evènement)
* [Mapping Transport](#mapping-transport)

 Ce mapping représente les données fonctionnelles trouvant leur équivalence dans l'actuelle version des spécifications techniques. 

### Mapping global

### Mapping Usager

### Mapping Sejour & EntiteJuridique

### Mapping Professionnel

### Mapping Evènement

### Mapping Transport

| | | |
| :--- | :--- | :--- |
|  [<prev](annexes.md) | [top](#top) |  [next>](annexes_documents_reference.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# TDDUIBundleExample - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUIBundleExample**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-ExampleTDDUIBundle.xml.md) 
*  [JSON](Bundle-ExampleTDDUIBundle.json.md) 
*  [TTL](Bundle-ExampleTDDUIBundle.ttl.md) 

## Example Bundle: TDDUIBundleExample

Profil: [TDDUI Bundle](StructureDefinition-tddui-bundle.md)

Bundle ExampleTDDUIBundle de type transaction

-------

Entry 1 - fullUrl = https://test-server.fr/Patient/tddui-patient-ins-example

Ressource Patient :

> 

Profil: [TDDUI Patient INS](StructureDefinition-tddui-patient-ins.md)

DUPONT Male, Date de Naissance :1947-04-03 ( NIR définitif (use: official, ))
-------

Requête :

```
POST TDDUIPatientINS

```

-------

Entry 2 - fullUrl = https://test-server.fr/Organization/tddui-organization-example

Ressource Organization :

> 

Profil: [TDDUI Organization](StructureDefinition-tddui-organization.md)

**identifier**: Identification nationale de structure définie par l’ANS dans le CI_SIS/1480787529**name**: Les Chênes Verts

Requête :

```
POST TDDUIOrganization

```

-------

Entry 3 - fullUrl = https://test-server.fr/Encounter/tddui-encounter-sejour-example

Ressource Encounter :

> 

Profil: [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md)

**Date d’admission**: 2023-04-11**Libellé mode d'entrée**: Date de début du suivi post-opératoire : 14/04/2023**Libellé mode de sortie**: Sortie prévisionnelle prévue pour le 5 mai 2023**Extension Definition for Encounter.plannedEndDate for Version 5.0**: 2023-05-05**identifier**: Identifiant du séjour/3480787529/147720425367411-SEJOUR-1012**status**: In Progress**class**:home health**subject**:[DUPONT Male, Date de Naissance :1947-04-03 ( NIR définitif (use: official, ))](Patient-tddui-patient-ins-example.md)**serviceProvider**:[Organization Les Chênes Verts](Organization-tddui-organization-example.md)

Requête :

```
POST TDDUIEncounterSejour

```

-------

Entry 4 - fullUrl = https://test-server.fr/Encounter/tddui-encounter-evenement-example

Ressource Encounter :

> 

Profil: [TDDUI Encounter Evenement](StructureDefinition-tddui-encounter-evenement.md)

> **Ressources utilisées**
* TDDUIRessourceType: Vehicle

**Rapport de l’évènement**: Observations cliniques : ; Recommandations pour les jours à venir : ; Prochaine visite : 15 avril 2023, 10h30 ; Remarque : Monsieur Dupont a compris les consignes pour la gestion de sa douleur et la mobilisation de sa hanche opérée.**Commentaire**: Cet évènement a débuté plus tard l’usager était sous la douche à l’heure du début du rendez-vous.**Libellé de l'évènement**: Visite à domicile pour soins infirmier.**Motif de l’évènement**: Suivi post-opératoire suite à intervention chirurgicale de la hanche.**identifier**: Visit Number/3480787529/147720425367411-EVN-12548**status**: completed**class**:home health**type**:Intervention d'un infirmer salarié,Intervention**subject**:[DUPONT Male, Date de Naissance :1947-04-03 ( NIR définitif (use: official, ))](Patient-tddui-patient-ins-example.md)**partOf**:[Encounter : extension = 2023-04-11,Date de début du suivi post-opératoire : 14/04/2023,Sortie prévisionnelle prévue pour le 5 mai 2023,2023-05-05; identifier = Identifiant du séjour: 3480787529/147720425367411-SEJOUR-1012; status = in-progress; class = home health (ActCode#HH); period = 2023-04-14 --> (ongoing)](Encounter-tddui-encounter-sejour-example.md)**serviceProvider**:[Organization Les Chênes Verts](Organization-tddui-organization-example.md)
> **participant**

### Locations

| | |
| :--- | :--- |
| - | **Location** |
| * | [Location](Location-tddui-event-location-example.md) |


Requête :

```
POST TDDUIEncounterEvenement

```

-------

Entry 5 - fullUrl = https://test-server.fr/Practitioner/tddui-practitioner-example

Ressource Practitioner :

> 

Profil: [TDDUI Practitioner](StructureDefinition-tddui-practitioner.md)

**identifier**:`urn:oid:1.2.250.1.71.4.2.1`/10103441234**name**: Claire Martin
> **qualification****code**:DE Infirmier

> **qualification****code**:Infirmier

Requête :

```
POST TDDUIPractitioner

```

-------

Entry 6 - fullUrl = https://test-server.fr/PractitionerRole/tddui-practitioner-role-example

Ressource PractitionerRole :

> 

Profil: [TDDUI Practitioner Role](StructureDefinition-tddui-practitioner-role.md)

**practitioner**:[Practitioner Claire Martin](Practitioner-tddui-practitioner-example.md)**organization**:[Organization Les Chênes Verts](Organization-tddui-organization-example.md)**code**:Coordonnateur de parcours

Requête :

```
POST TDDUIPractitionerRole

```

-------

Entry 7 - fullUrl = https://test-server.fr/Task/tddui-task-transport-professionel-example

Ressource Task :

> 

Profil: [Transport Professionnel](StructureDefinition-tddui-task-transport-professionnel.md)

**identifier**: 3480787529/147720425367411-TPPro-154674**status**: Completed**intent**: Plan**code**:Véhicule individuel**for**:[Practitioner Claire Martin](Practitioner-tddui-practitioner-example.md)**encounter**:[Encounter : extension = ,Observations cliniques : ; Recommandations pour les jours à venir : ; Prochaine visite : 15 avril 2023, 10h30 ; Remarque : Monsieur Dupont a compris les consignes pour la gestion de sa douleur et la mobilisation de sa hanche opérée.,Cet évènement a débuté plus tard l’usager était sous la douche à l’heure du début du rendez-vous.,Visite à domicile pour soins infirmier.,Suivi post-opératoire suite à intervention chirurgicale de la hanche.; identifier = Visit Number; status = finished; class = home health (ActCode#HH); type = Intervention d'un infirmer salarié,; period = 2023-04-14 10:30:00+0200 --> 2023-04-14 11:15:00+0200](Encounter-tddui-encounter-evenement-example.md)**executionPeriod**: 2023-04-14 10:30:00+0200 --> 2023-04-14 11:15:00+0200**owner**:[Organization Les Chênes Verts](Organization-tddui-organization-example.md)
> **input****type**:Type de motorisation associée au véhicule utilisé lors du transport.**value**:Véhicule électrique

> **input****type**:Budget prévisionnel pour assurer le transport de la personne physique.**value**:€2,00(EUR)

> **input****type**:Budget réel pour assurer le transport de la personne physique.**value**:€2,00(EUR)

> **input****type**:Distance du transport de la personne physique.**value**: No display for Distance (value : 4; unit : kilometers; system : http://unitsofmeasure.org; code : km)

> **input****type**:Durée théorique du transport de la personne physique.**value**: No display for Duration (value : 10; unit : minutes; system : http://unitsofmeasure.org; code : min)

Requête :

```
POST TDDUITaskTransportProfessionnel

```

-------

Entry 8 - fullUrl = https://test-server.fr/Task/tddui-task-transport-usager-example

Ressource Task :

> 

Profil: [Transport Usager](StructureDefinition-tddui-task-transport-usager.md)

**identifier**: 3480787529/147720425367411-TPU-154675**status**: Completed**intent**: Plan**code**:Taxi**encounter**:[Encounter : extension = ,Observations cliniques : ; Recommandations pour les jours à venir : ; Prochaine visite : 15 avril 2023, 10h30 ; Remarque : Monsieur Dupont a compris les consignes pour la gestion de sa douleur et la mobilisation de sa hanche opérée.,Cet évènement a débuté plus tard l’usager était sous la douche à l’heure du début du rendez-vous.,Visite à domicile pour soins infirmier.,Suivi post-opératoire suite à intervention chirurgicale de la hanche.; identifier = Visit Number; status = finished; class = home health (ActCode#HH); type = Intervention d'un infirmer salarié,; period = 2023-04-14 10:30:00+0200 --> 2023-04-14 11:15:00+0200](Encounter-tddui-encounter-evenement-example.md)**executionPeriod**: 2023-04-14 10:30:00+0200 --> 2023-04-14 11:15:00+0200
> **input****type**:Budget prévisionnel pour assurer le transport de la personne physique.**value**:€2,00(EUR)

> **input****type**:Budget réel pour assurer le transport de la personne physique.**value**:€2,00(EUR)

> **input****type**:Distance du transport de la personne physique.**value**: No display for Distance (value : 4; unit : kilometers; system : http://unitsofmeasure.org; code : km)

> **input****type**:Durée théorique du transport de la personne physique.**value**: No display for Duration (value : 10; unit : minutes; system : http://unitsofmeasure.org; code : min)

> **input****type**:Accompagnement nécessaire ou non de l'usager.**value**: true

> **input****type**:Lors du transport de l'usager l'asepsie est rigoureusement respectée ou n'est pas nécessaire.**value**: false

> **input****type**:Nature du transport de l'usager.**value**:Transports liés au projet individuel

Requête :

```
POST TDDUITaskTransportUsager

```

| | | |
| :--- | :--- | :--- |
|  [<prev](Task-tddui-task-transport-usager-example.ttl.md) | [top](#top) |  [next>](Bundle-ExampleTDDUIBundle.xml.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# Transport Professionnel - JSON Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Transport Professionnel**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](StructureDefinition-tddui-task-transport-professionnel.md) 
*  [Detailed Descriptions](StructureDefinition-tddui-task-transport-professionnel-definitions.md) 
*  [Mappings](StructureDefinition-tddui-task-transport-professionnel-mappings.md) 
*  [Examples](StructureDefinition-tddui-task-transport-professionnel-examples.md) 
*  [XML](StructureDefinition-tddui-task-transport-professionnel.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-tddui-task-transport-professionnel.profile.ttl.md) 

## Resource Profile: TDDUITaskTransportProfessionnel - JSON Profile

| |
| :--- |
| Active as of 2025-10-01 |

JSON representation of the tddui-task-transport-professionnel resource profile.

[Raw json](StructureDefinition-tddui-task-transport-professionnel.json) | [Download](StructureDefinition-tddui-task-transport-professionnel.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-task-transport-professionnel.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-tddui-task-transport-professionnel.profile.ttl.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


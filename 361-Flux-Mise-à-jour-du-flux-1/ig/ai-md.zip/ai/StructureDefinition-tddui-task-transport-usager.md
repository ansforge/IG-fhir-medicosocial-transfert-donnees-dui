# Transport Usager - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Transport Usager**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-tddui-task-transport-usager-definitions.md) 
*  [Mappings](StructureDefinition-tddui-task-transport-usager-mappings.md) 
*  [Examples](StructureDefinition-tddui-task-transport-usager-examples.md) 
*  [XML](StructureDefinition-tddui-task-transport-usager.profile.xml.md) 
*  [JSON](StructureDefinition-tddui-task-transport-usager.profile.json.md) 
*  [TTL](StructureDefinition-tddui-task-transport-usager.profile.ttl.md) 

## Resource Profile: Transport Usager 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-transport-usager | *Version*:2.0.0-ballot |
| Active as of 2025-10-01 | *Computable Name*:TDDUITaskTransportUsager |

 
Profil de la ressource TDDUITaskTransport permettant de représenter le transport de l'usager. 

**Usages:**

* Use this Profile: [TDDUI Bundle](StructureDefinition-tddui-bundle.md)
* Examples for this Profile: [Task/tddui-task-transport-usager-example](Task-tddui-task-transport-usager-example.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-task-transport-usager)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [TDDUITaskTransport](StructureDefinition-tddui-task-transport.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [TDDUITaskTransport](StructureDefinition-tddui-task-transport.md) 

**Résumé**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [TDDUITaskTransport](StructureDefinition-tddui-task-transport.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [TDDUITaskTransport](StructureDefinition-tddui-task-transport.md) 

**Résumé**

 

Other representations of profile: [CSV](StructureDefinition-tddui-task-transport-usager.csv), [Excel](StructureDefinition-tddui-task-transport-usager.xlsx), [Schematron](StructureDefinition-tddui-task-transport-usager.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-tddui-task-transport-professionnel.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-tddui-task-transport-usager-definitions.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


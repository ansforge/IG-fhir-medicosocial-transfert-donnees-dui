# InputTaskTransportCodeSystem - JSON Representation - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **InputTaskTransportCodeSystem**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](CodeSystem-input-tddui-task-transport-codesystem.md) 
*  [XML](CodeSystem-input-tddui-task-transport-codesystem.xml.md) 
*  [JSON](#) 
*  [TTL](CodeSystem-input-tddui-task-transport-codesystem.ttl.md) 

## : InputTaskTransportCodeSystem - JSON Representation

| |
| :--- |
| Active as of 2025-10-01 |

[Raw json](CodeSystem-input-tddui-task-transport-codesystem.json) | [Download](CodeSystem-input-tddui-task-transport-codesystem.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-input-tddui-task-transport-codesystem.xml.md) | [top](#top) |  [next>](CodeSystem-input-tddui-task-transport-codesystem.ttl.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


# InputTaskTransportCodeSystem - Médicosocial - Transfert de données DUI v2.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **InputTaskTransportCodeSystem**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0-ballot) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-input-tddui-task-transport-codesystem.xml.md) 
*  [JSON](CodeSystem-input-tddui-task-transport-codesystem.json.md) 
*  [TTL](CodeSystem-input-tddui-task-transport-codesystem.ttl.md) 

## CodeSystem: InputTaskTransportCodeSystem 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-transport-codesystem | *Version*:2.0.0-ballot |
| Active as of 2025-10-01 | *Computable Name*:InputTDDUITaskTransportCodeSystem |

 
CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les transports dans le cadre du DUI. 

 This Code system is referenced in the content logical definition of the following value sets: 

* Cette terminologie de référence (CodeSystem) nest pas utilisée ici; elle peut être utilisée ailleurs (par exemple spécifications et/ou implémentations qui utilisent ce contenu)

Profil: [Shareable CodeSystem](http://hl7.org/fhir/R4/shareablecodesystem.html)

This case-sensitive code system `https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/input-tddui-task-transport-codesystem` defines the following codes:

| | | |
| :--- | :--- | :--- |
|  [<prev](ValueSet-tddui-serafin-valueset.ttl.md) | [top](#top) |  [next>](CodeSystem-input-tddui-task-transport-codesystem-testing.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0-ballot based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  


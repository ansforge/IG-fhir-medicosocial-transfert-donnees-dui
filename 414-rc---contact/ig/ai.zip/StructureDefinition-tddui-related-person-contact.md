# TDDUI RelatedPerson Contact - Médicosocial - Transfert de données DUI v2.2.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI RelatedPerson Contact**

## Resource Profile: TDDUI RelatedPerson Contact 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-related-person-contact | *Version*:2.2.0-ballot |
| Active as of 2026-01-23 | *Computable Name*:TDDUIRelatedPersonContact |

 
Profil de la ressource FRCoreRelatedPersonProfile permettant de représenter le contact PersonnePhyisique. 

**Utilisations:**

* Ce Profil nest utilisé par aucun profil dans ce guide dimplémentation

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.tddui|current/StructureDefinition/tddui-related-person-contact)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-tddui-related-person-contact.csv), [Excel](StructureDefinition-tddui-related-person-contact.xlsx), [Schematron](StructureDefinition-tddui-related-person-contact.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "tddui-related-person-contact",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-related-person-contact",
  "version" : "2.2.0-ballot",
  "name" : "TDDUIRelatedPersonContact",
  "title" : "TDDUI RelatedPerson Contact",
  "status" : "active",
  "date" : "2026-01-23T10:30:04+00:00",
  "publisher" : "ANS",
  "contact" : [
    {
      "name" : "ANS",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://esante.gouv.fr"
        }
      ]
    }
  ],
  "description" : "Profil de la ressource FRCoreRelatedPersonProfile permettant de représenter le contact PersonnePhyisique.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "FRANCE"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "specmetier-to-TDDUIRelatedPersonContact",
      "uri" : "https://interop.esante.gouv.fr/ig/fhir/tddui/sfe_modelisation_contenu.html",
      "name" : "Modèle de contenu DUI"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "RelatedPerson",
  "baseDefinition" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-related-person|2.1.0",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "RelatedPerson",
        "path" : "RelatedPerson",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "ContactPersonnePhysique"
          }
        ]
      },
      {
        "id" : "RelatedPerson.extension",
        "path" : "RelatedPerson.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "RelatedPerson.extension:nationality",
        "path" : "RelatedPerson.extension",
        "sliceName" : "nationality",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-nationality|2.2.0-ballot"
            ]
          }
        ],
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "paysNationalite"
          }
        ]
      },
      {
        "id" : "RelatedPerson.extension:comment",
        "path" : "RelatedPerson.extension",
        "sliceName" : "comment",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-comment|2.2.0-ballot"
            ]
          }
        ],
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "commentaire"
          }
        ]
      },
      {
        "id" : "RelatedPerson.identifier",
        "path" : "RelatedPerson.identifier",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "identifiantPP"
          }
        ]
      },
      {
        "id" : "RelatedPerson.patient",
        "path" : "RelatedPerson.patient",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient|2.2.0-ballot",
              "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins|2.2.0-ballot"
            ]
          }
        ]
      },
      {
        "id" : "RelatedPerson.name",
        "path" : "RelatedPerson.name",
        "type" : [
          {
            "code" : "HumanName",
            "profile" : [
              "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-human-name|2.2.0-ballot"
            ]
          }
        ]
      },
      {
        "id" : "RelatedPerson.name.given",
        "path" : "RelatedPerson.name.given",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "prenom"
          }
        ]
      },
      {
        "id" : "RelatedPerson.name.prefix",
        "path" : "RelatedPerson.name.prefix",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "civilite"
          }
        ]
      },
      {
        "id" : "RelatedPerson.telecom",
        "path" : "RelatedPerson.telecom",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "telecommunication"
          }
        ]
      },
      {
        "id" : "RelatedPerson.gender",
        "path" : "RelatedPerson.gender",
        "short" : "male | female | unknown",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-patient-gender-INS|2.1.0"
        },
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "sexe"
          }
        ]
      },
      {
        "id" : "RelatedPerson.birthDate",
        "path" : "RelatedPerson.birthDate",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "dateNaissance"
          }
        ]
      },
      {
        "id" : "RelatedPerson.address",
        "path" : "RelatedPerson.address",
        "max" : "1",
        "mapping" : [
          {
            "identity" : "specmetier-to-TDDUIRelatedPersonContact",
            "map" : "adresse"
          }
        ]
      }
    ]
  }
}

```

# Transfert des données à un tiers - Médicosocial - Transfert de données DUI v2.4.0

## Transfert des données à un tiers

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Définition des Processus collaboratif

* Service attendu: Pré-conditions
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: * Un SI Tiers a demandé à l’ESSMS de lui transmettre tout ou partie des données médico-sociales de l’usager.

* Service attendu: Post-conditions
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: N/A
* Service attendu: Contraintes fonctionnelles
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: N/A
* Service attendu: Scénario nominal
  * L'ESSMS d'origine transfère des données de son logiciel DUI vers un système cible : un SI-Tiers.: Scénario conforme aux cas d'usages décrits dans["Cas d'usage"](sfe_cas_usage.md).

### Liste des acteurs pour l’ensemble des processus

#### Le producteur

Le rôle de producteur incarné par un système correspond à l’acteur à l’origine de l’export des données d’un logiciel DUI.

#### Le consommateur

Le rôle de consommateur incarné par un système se caractérise par réceptionner puis importer l’export des données DUI dans son système (SI-tiers).

### Identification des flux

* Processus métier: * Export des données d'un logiciel DUI

  * Flux techniques: * Flux 1.1 - Transmission de données DUI
* Flux 1.2 - Résultat de la transmission de données DUI
Lien vers la description détaillée :[flux 1](description_flux_1_transmission_donnees_dui.md)


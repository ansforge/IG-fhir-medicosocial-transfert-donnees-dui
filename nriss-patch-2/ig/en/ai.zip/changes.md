# Historique des changements - Médicosocial - Transfert de données DUI v2.4.0

## Historique des changements

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Release 2.4.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.4.0](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.4.0) :

* [ANS-009-004 Fix invariant](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/494)

### Release 2.4.0-ballot de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.4.0-ballot](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.4.0-ballot) :

* [ANS-009-004-Fix CapabilityStatement](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/491)
* [ANS-009-004 - Correction fhirpath motivationLocaleRequired](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/490)
* [fix: remplacer valueCodeableConcept par value.ofType(CodeableConcept) dans les invariants FHIRPath](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/489)
* [feat: adopt container mode for CI-build workflow](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/485)
* [Correction TDDUI Bundle](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/484)
* [Revert "ANS-006-168 - Ajout des objets PresenceAbsence et Repas"](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/483)
* [Passage au template 2 : i18n et expansion-params](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/482)
* [ANS-006-168 - Ajout des objets demandeorientation decision droitprestation](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/455)
* [ANS-006-168 - Ajout du projet de vie](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/453)
* [ANS-006-168 - Ajout des objets PresenceAbsence et Repas](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/452)
* [juridiction](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/467)
* [Ajout des url pour JDV NOS lot2,3](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/465)
* [Création onglet problématiques connues](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/454)
* [Sfe lot 3 serafin](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/423)

### Release 2.3.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Aucune modification apportée dans la release 2.3.0 par rapport à la release de concertation 2.3.0-ballot.

### Release 2.3.0-ballot de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.3.0-ballot](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.3.0-ballot) :

* [lot2 SFE modification role participant](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/444)
* [ANS-006-168 - Mise à jour de l'évènement](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/439)
* [ANS-006-168 - Mise à jour de l'usager](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/437)
* [ANS-006-168 - Mise à jour de l'évaluation](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/434)
* [ANS-006-168 - Ajout causes de décès, mobilité et période scolaire](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/433)
* [ANS-006-168 - Mise à jour du séjour](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/428)
* [SFE SERAFIN lot 2](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/411)

### Release 2.2.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.2.0](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.2.0) :

* [ANS-006-168 - Paramètre pin-all](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/427)
* [ANS-006-168 - Mise en place des bonnes pratiques (SD, CS, VS)](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/425)
* [ANS-006-168 - Contact](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/424)
* [SFE Modelisation Contact Personne Physique Morale](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/410)

### Release 2.2.0-ballot de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.2.0-ballot](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.2.0-ballot) :

* [SFE - Ajout du Projet Personnalisé](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/376)
* [ANS-006-168 - Ajout du projet personnalisé](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/391)
* [ANS-006-168 - Mise à jour du flux 1](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/400)
* [ANS-006-168 - Mise à jour des Capability Statements](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/401)
* [ANS-006-168 - Gestion des slices remontant un warning](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/397)

### Release 2.1.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Aucune modification apportée dans la release 2.1.0 par rapport à la release de concertation 2.1.0-ballot.

### Release 2.1.0-ballot de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.1.0-ballot](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.1.0-ballot) :

* [ANS-006-150 - Ajout des blocs "Evènement" et "Evaluation" au flux 1](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/373)
* [ANS-006-150 - Mise à jour des Capability Statements](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/372)
* [ANS-006-150 - Ajout de l'évènement](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/367)
* [ANS-006-150 - Verification du QA](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/385)
* [ANS-006-150 - Gestion des identifiants métiers](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/381)
* [ANS-006-150- Modification cardinalité du professionnel pour l'évènement](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/380)
* [ANS-006-150 - Ajout de l'évaluation](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/374)

### Release 2.0.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.0.0](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.0.0) :

* [Coquille SFE Modélisation Contenu](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/368)
* [ANS-006-150 - Héritage TDDUIPatientINS](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/364)
* [ANS-006-150 - Correction HTTPS](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/358)
* [ANS-006-150 - Gestion des id](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/354)
* [Modélisation - Statut d'un évènement et d'une évaluation](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/352)
* [ANS-006-150 - Correction du flux 1](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/347)

### Release 2.0.0-ballot de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [2.0.0-ballot](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A2.0.0-ballot) :

* [Mise à jour de la dépendance avec l'IG terminonogies](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/323)
* [ANS-006-150 - Création des profils TDDUI](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/325)
* [ANS-006-150 - Restructuration du guide d'implémentation](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/327)
* [Renommage et réorganisation de longlet spécifications fonctionnelles](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/328)
* [ANS-006-150 -Création dun exemple de cas dusage ssiad](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/329)
* [ANS-006-150 -Ajouter un mapping technique fonctionnel](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/331)
* [ANS-006-150 -Mise a jour des requêtes de flux pour intégrer les nouvelles rc](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/333)
* [Remise des anciens noms : mode entrée et mode sortie du séjour](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/334)
* [Renommage de l'ordre de naissance](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/339)
* [Mise à jour du lien vers les nouvelles issues](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/340)
* [ANS-006-150 - Correction des erreurs remontées par le QA](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/341)

### Release 1.1.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans cette release [1.1.0](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pulls?q=is%3Apr+is%3Aclosed+milestone%3A1.1.0) :

* [Ajout de l'Historique dans le Menu IG](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/292)
* [Préparation de la release 110](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/290)
* [Ajout JDV_ResultatQuestionEvaluation_CISIS](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/255)
* [ANS-006-141 - Correction des erreurs et de plusieurs warning remontés par le contôle qualité de l'IG](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/276)
* [ANS-006-141 - Mise a jour du mapping](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/269)
* [ANS-006-141 - Mise à jour de l'exemple TDDUIBundleExample](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/268)
* [ANS-006-141 - Mise a jour exemple & nom validateur CDA](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/266)
* [ANS-006-141 - #172 - Mise a jour contenu éléments transversaux](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/263)
* [ANS-006-141 - #179 - Ajout du numéro de sécurité sociale dans les ST](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/262)
* [ANS-006-141 - #165 - Mise a jour contenu sejour](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/261)
* [ANS-006-141 - #169/#203/#165 - Mise a jour contenu evenement](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/260)
* [ANS-006-141 - #215/#165/#213/#169 - Mise a jour contenu evaluation](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/259)
* [ANS-006-141 - #202 - Ajout des entrées FR-Document-attache et FR-Type-document-attache](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/258)
* [ANS-006-141 - MAJ templates génériques](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/253)
* [ajout des ayants droit dans AMO et AMC](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/250)
* [SFE - numero sécurité sociale NIR et NIA de l'usager](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/245)
* [Ajout profession et rôle du PS](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/244)
* [ANS-006-141 - MAJ Capability Statement Producteur - interaction patch](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/242)
* [suppression statut juridique dans EJ](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/220)
* [ajout JDV grille AGGIR SSIAD PA et PH](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/218)

### Release 1.0.1 de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans la release [1.0.1]

* [Rendre plus générique les cas d’usage, les rôles des acteurs sur le transfert de données](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/49)
* [Corrections de l'IG](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/35)
* [Supprimer les images .svg générées manuellement](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/51)
* [Nettoyage de tableau + renommage des .md + autres](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/36)

### Release 1.0.0 de l'Implementation Guide du volet "Transfert de dossier DUI"

Modifications apportées dans la release [1.0.0]

* [Ajout des spécifications pour la partie transport](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/10)
* [Correctif au niveau du contenu CDA de la grille d'évaluation (section FR-Evaluation-du-statut-fonctionnel)](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/pull/11)


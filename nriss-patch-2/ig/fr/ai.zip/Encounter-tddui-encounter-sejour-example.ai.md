# TDDUI Encounter Sejour Example - Médicosocial - Transfert de données DUI v2.4.0

## Exemple Encounter: TDDUI Encounter Sejour Example

-------

**French**

-------

Profil: [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md)

**TDDUI Admission Date**: 2023-04-11

**TDDUI Entry Mode label**: Date de début du suivi post-opératoire : 14/04/2023

**TDDUI Exit Mode Label**: Sortie prévisionnelle prévue pour le 5 mai 2023

**R5: The planned end date/time (or discharge date) of the encounter (new)**: 2023-05-05

**identifier**: Identifiant du séjour/3480787529/147720425367411-SEJOUR-1012, Numéro de dossier administratif du séjour/1012

**status**: In Progress

**class**: [ActCode: HH](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-HH) (home health)

**subject**: [DUPONT Male, Date de Naissance :1947-04-03 ( Patient internal identifier: 3480787529/194704032)](Patient-tddui-patient-ins-example.md)

**period**: 2023-04-14 --> (en cours)

### Hospitalizations

| | | |
| :--- | :--- | :--- |
| - | **Origin** | **AdmitSource** |
| * | [Organization Les Résidences du Lac](Organization-tddui-organization-origine-example.md) | Autre modalité d'entrée |

**serviceProvider**: [Organization Les Chênes Verts](Organization-tddui-organization-example.md)



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "tddui-encounter-sejour-example",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-sejour"]
  },
  "extension" : [{
    "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-admission-date",
    "valueDateTime" : "2023-04-11"
  },
  {
    "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-entry-mode-label",
    "valueString" : "Date de début du suivi post-opératoire : 14/04/2023"
  },
  {
    "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-exit-mode-label",
    "valueString" : "Sortie prévisionnelle prévue pour le 5 mai 2023"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Encounter.plannedEndDate",
    "valueDateTime" : "2023-05-05"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-encounter-identifier",
        "code" : "SEJ",
        "display" : "Identifiant du séjour"
      }]
    },
    "system" : "https://identifiant-medicosocial-sejour.esante.gouv.fr",
    "value" : "3480787529/147720425367411-SEJOUR-1012"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-encounter-identifier",
        "code" : "NUMDOSS",
        "display" : "Numéro de dossier administratif du séjour"
      }]
    },
    "system" : "https://identifiant-medicosocial-sejour.esante.gouv.fr",
    "value" : "1012"
  }],
  "status" : "in-progress",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "HH"
  },
  "subject" : {
    "reference" : "Patient/tddui-patient-ins-example"
  },
  "period" : {
    "start" : "2023-04-14"
  },
  "hospitalization" : {
    "origin" : {
      "reference" : "Organization/tddui-organization-origine-example"
    },
    "admitSource" : {
      "coding" : [{
        "system" : "https://smt.esante.gouv.fr/fhir/CodeSystem/terminologie-cisis",
        "code" : "GEN-092.06.07",
        "display" : "Autre modalité d'entrée"
      }]
    }
  },
  "serviceProvider" : {
    "reference" : "Organization/tddui-organization-example"
  }
}

```

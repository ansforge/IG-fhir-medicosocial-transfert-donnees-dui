# Resource Médicosocial - Transfert de données DUI



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "ans.fhir.fr.tddui",
  "language" : "fr",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/ImplementationGuide/ans.fhir.fr.tddui",
  "version" : "2.4.0",
  "name" : "TDDUI",
  "title" : "Médicosocial - Transfert de données DUI",
  "status" : "active",
  "date" : "2026-07-27T13:01:06+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "packageId" : "ans.fhir.fr.tddui",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7_fhir_fr_core",
    "uri" : "https://hl7.fr/ig/fhir/core/ImplementationGuide/hl7.fhir.fr.core",
    "packageId" : "hl7.fhir.fr.core",
    "version" : "2.1.0"
  },
  {
    "id" : "ans_fr_terminologies",
    "uri" : "https://interop.esante.gouv.fr/terminologies/ImplementationGuide/ans.fr.terminologies",
    "packageId" : "ans.fr.terminologies",
    "version" : "1.11.1"
  },
  {
    "id" : "hl7_fhir_uv_xver_r5_r4",
    "uri" : "http://hl7.org/fhir/uv/xver/ImplementationGuide/hl7.fhir.uv.xver-r5.r4",
    "packageId" : "hl7.fhir.uv.xver-r5.r4",
    "version" : "0.1.0"
  },
  {
    "id" : "hl7_fhir_uv_extensions",
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions",
    "version" : "5.2.0"
  },
  {
    "id" : "ihe_iti_mhd",
    "uri" : "https://profiles.ihe.net/ITI/MHD/ImplementationGuide/ihe.iti.mhd",
    "packageId" : "ihe.iti.mhd",
    "version" : "4.2.0"
  },
  {
    "id" : "ans_fhir_fr_annuaire",
    "uri" : "https://interop.esante.gouv.fr/ig/fhir/annuaire/ImplementationGuide/ans.fhir.fr.annuaire",
    "packageId" : "ans.fhir.fr.annuaire",
    "version" : "1.1.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2023+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "trial-use"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../expansion-params.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations/en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://interop.esante.gouv.fr/ig/fhir/tddui/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/expansion-parameters",
      "valueReference" : {
        "reference" : "Parameters/expansion-parameters"
      }
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2023+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "trial-use"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../expansion-params.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations/en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://interop.esante.gouv.fr/ig/fhir/tddui/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-related-person-contact-description.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-related-person-contact-description"
      },
      "name" : "Description",
      "description" : "Description du contact PersonnePhysique.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-admission-date.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-admission-date"
      },
      "name" : "TDDUI Admission Date",
      "description" : "Date d’admission dans la structure ESSMS.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-assessment-method.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-assessment-method"
      },
      "name" : "TDDUI Assessment Method",
      "description" : "Mode d'évaluation, texte libre permettant de mettre le contexte de l'évaluation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-attachment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-attachment"
      },
      "name" : "TDDUI Attachment",
      "description" : "Extension permettant de véhiculer des pièces jointes que ce soit pour l'évaluation, l'évènement ou le projet personnalisé. L'extension référence le profil PDSm_SimplifiedPublish.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-basic-decision.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-basic-decision"
      },
      "name" : "TDDUI Basic Decision",
      "description" : "Profil de la ressource Basic permettant de représenter la décision de la CDAPH ainsi que les droits associés.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Basic"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Basic-tddui-basic-decision-example.html"
      }],
      "reference" : {
        "reference" : "Basic/tddui-basic-decision-example"
      },
      "name" : "TDDUI Basic Decision Example",
      "description" : "Exemple de la ressource TDDUIBasicDroitDecision",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-basic-decision"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-basic-decision-identifier.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-basic-decision-identifier"
      },
      "name" : "TDDUI Basic Decision Identifier",
      "description" : "ValueSet pour la définition des codes d'identifiant de la décision de la CDAPH.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-basic-decision-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-basic-decision-identifier"
      },
      "name" : "TDDUI Basic Decision Identifier",
      "description" : "CodeSystem pour la définition des codes d'identifiant de la décision de la CDAPH",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-basic-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-basic-type"
      },
      "name" : "TDDUI Basic Type",
      "description" : "ValueSet pour le code de la ressource Basic.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-basic-type.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-basic-type"
      },
      "name" : "TDDUI Basic Type",
      "description" : "CodeSystem pour la définition de la ressource Basic",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-birth-order.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-birth-order"
      },
      "name" : "TDDUI Birth Order",
      "description" : "Ordre d’enregistrement de la naissance dans le registre d’état civil de la commune de naissance pour le mois de la naissance. Il compose les 3 derniers chiffres du NIR de l'usager avant la clé de sécurité et permet de distinguer les personnes nées au même lieu et à la même période. Il est obligatoire si le NIR n'est pas transmis.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-bundle.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-bundle"
      },
      "name" : "TDDUI Bundle",
      "description" : "Profil générique créé pour transmettre des données d'un logiciel DUI.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-tddui-bundle-example.html"
      }],
      "reference" : {
        "reference" : "Bundle/tddui-bundle-example"
      },
      "name" : "TDDUI Bundle Example",
      "description" : "Exemple de bundle conforme au profil TDDUIBundle",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-bundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-careplan-reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-careplan-reference"
      },
      "name" : "TDDUI CarePlan Projet Perso Ref",
      "description" : "Liens vers le projet personnalisé, utilisables dans le profil TDDUIGoalObjectif.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-careplan-projet-personnalise.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-careplan-projet-personnalise"
      },
      "name" : "TDDUI CarePlan Projet Personalise",
      "description" : "Profil de la ressource CarePlan représentant le projet personnalisé d'un usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-care-plan-supporting-info.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-care-plan-supporting-info"
      },
      "name" : "TDDUI CarePlan supportingInfo",
      "description" : "ValueSet définissant les types de notes pour l'élément CarePlan.supportingInfo.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-cim-10.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-cim-10"
      },
      "name" : "TDDUI CIM10",
      "description" : "ValueSet incluant les codes de la terminologie CIM-1O.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-comment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-comment"
      },
      "name" : "TDDUI Comment",
      "description" : "\n- **Séjour** : commentaire relatif au séjour.\n- **Événement** : commentaires sur le déroulé de l’évènement.\n- **Évaluation** : commentaire libre sur le contenu ou le résultat de l’évaluation.\n- **Champ évalué** : commentaire spécifique à un item ou sous-item évalué.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-consent-accord.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-consent-accord"
      },
      "name" : "TDDUI Consent Accord",
      "description" : "Profil de la ressource Consent permettant de représenter l'accord de l'usager, de son entourage ou de la structure.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-contact-protection-juridique.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-contact-protection-juridique"
      },
      "name" : "TDDUI Contact Protection Juridique",
      "description" : "ValueSet définissant la protection juridique.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-contact-relation.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-contact-relation"
      },
      "name" : "TDDUI Contact Relation",
      "description" : "ValueSet définissant les relations.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-decision.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-decision"
      },
      "name" : "TDDUI Decision",
      "description" : "Extension complexe représentant la décision et les droits associés",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-discriminator.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-discriminator"
      },
      "name" : "TDDUI Discriminator",
      "description" : "Extension pour discriminer les éléments CarePlan.supportingInfo et Goal.note.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-discriminator.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-discriminator"
      },
      "name" : "TDDUI Discriminator",
      "description" : "ValueSet définissant les codes discriminants.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-discriminator.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-discriminator"
      },
      "name" : "TDDUI Discriminator",
      "description" : "CodeSystem définissant les codes discriminants.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-document-reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-document-reference"
      },
      "name" : "TDDUI DocumentReference",
      "description" : "Profil de la ressource SimplifiedPublishDocumentReference permettant de véhiculer des pièces jointes que ce soit pour l'évaluation, l'évènement ou le projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-encounter-evenement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-encounter-evenement"
      },
      "name" : "TDDUI Encounter Evenement",
      "description" : "Profil de la ressource Encounter permettant de regrouper les évènements liés à la prise en charge de l’usager dans une structure ESSMS.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-tddui-encounter-evenement-example.html"
      }],
      "reference" : {
        "reference" : "Encounter/tddui-encounter-evenement-example"
      },
      "name" : "TDDUI Encounter Evenement Example",
      "description" : "Exemple d'un évènement",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-evenement"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-encounter-identifier.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-encounter-identifier"
      },
      "name" : "TDDUI Encounter Identifier",
      "description" : "ValueSet pour la définition des codes d'identifiant de séjour",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-encounter-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-encounter-identifier"
      },
      "name" : "TDDUI Encounter Identifier",
      "description" : "CodeSystem pour la définition des codes d'identifiant de séjour",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-encounter-participant.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-encounter-participant"
      },
      "name" : "TDDUI Encounter Participant",
      "description" : "ValueSet pour la définition des codes de participant d'un événement",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-encounter-sejour.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-encounter-sejour"
      },
      "name" : "TDDUI Encounter Sejour",
      "description" : "Profil de la ressource Encounter permettant de regrouper les informations relatives au séjour d'un usager dans une structure ESSMS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-tddui-encounter-sejour-example.html"
      }],
      "reference" : {
        "reference" : "Encounter/tddui-encounter-sejour-example"
      },
      "name" : "TDDUI Encounter Sejour Example",
      "description" : "Exemple d'un séjour en ESSMS",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-encounter-sejour"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-encounter-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-encounter-type"
      },
      "name" : "TDDUI Encounter Type",
      "description" : "ValueSet pour la définition des codes de type de séjour",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-entry-date-origin.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-entry-date-origin"
      },
      "name" : "TDDUI Entry Date Origin",
      "description" : "Extension permettant de véhiculer la date d'entrée dans l'ESSMS de provenance.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-entry-mode-label.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-entry-mode-label"
      },
      "name" : "TDDUI Entry Mode label",
      "description" : "Libellé du mode d’entée du séjour.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-evaluation-reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-evaluation-reference"
      },
      "name" : "TDDUI Evaluation Ref",
      "description" : "Liens vers l'évaluation, utilisables dans le profil TDDUIGoalObjectif.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-event-cancel-reason.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-event-cancel-reason"
      },
      "name" : "TDDUI Event Cancel Reason",
      "description" : "Motif associé au statut de non-réalisation de l’évènement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-event-label.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-event-label"
      },
      "name" : "TDDUI Event Label",
      "description" : "Titre donné à l’évènement par la structure.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-tddui-event-location-example.html"
      }],
      "reference" : {
        "reference" : "Location/tddui-event-location-example"
      },
      "name" : "TDDUI Event Location Example",
      "description" : "Lieu de l'évènement",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-outside-service.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-outside-service"
      },
      "name" : "TDDUI Event Outside Service",
      "description" : "Evénement hors prestation prévue dans le projet personnalisé de l’usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-event-reason.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-event-reason"
      },
      "name" : "TDDUI Event Reason",
      "description" : "Contexte justifiant la réalisation de l’évènement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-event-report.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-event-report"
      },
      "name" : "TDDUI Event Report",
      "description" : "Zone de texte liée à l’événement pour compte rendu des actions réalisées.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-exercise-mode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-exercise-mode"
      },
      "name" : "TDDUI Exercise Mode",
      "description" : "Extension permettant de représenter le mode d'exercice du professionnel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-exit-mode-label.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-exit-mode-label"
      },
      "name" : "TDDUI Exit Mode Label",
      "description" : "Libellé du mode de sortie du séjour.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-facturation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-facturation"
      },
      "name" : "TDDUI Facturation",
      "description" : "Indique si une facture a été établie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-goal-attente.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-goal-attente"
      },
      "name" : "TDDUI Goal Attente",
      "description" : "Profil de la ressource Goal permettant de représenter les attentes pour un usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-goal-attente-note.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-goal-attente-note"
      },
      "name" : "TDDUI Goal Attente Note",
      "description" : "ValueSet définissant les types de notes pour l'élément Goal.note.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-goal-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-goal-identifier"
      },
      "name" : "TDDUI Goal Identifier",
      "description" : "CodeSystem pour la défintion des identifiants de la ressource Goal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-goal-Identifier-projet-vie.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-goal-Identifier-projet-vie"
      },
      "name" : "TDDUI Goal Identifier Projet Vie",
      "description" : "ValueSet définissant les types de notes pour l'élément Goal.note.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-goal-objectif.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-goal-objectif"
      },
      "name" : "TDDUI Goal Objectif",
      "description" : "Profil de la ressource Goal permettant de représenter les résultats à atteindre dans le cadre du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-goal-objectif-note.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-goal-objectif-note"
      },
      "name" : "TDDUI Goal Objectif Note",
      "description" : "ValueSet définissant les types de notes pour l'élément Goal.note.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-goal-projet-vie.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-goal-projet-vie"
      },
      "name" : "TDDUI Goal Projet Vie",
      "description" : "Profil de la ressource Goal permettant de représenter le projet de vie de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-goal-projet-vie-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-goal-projet-vie-example"
      },
      "name" : "TDDUI Goal ProjetVie Example",
      "description" : "Exemple du projet de vie d'un usager.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-projet-vie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-household-situation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-household-situation"
      },
      "name" : "TDDUI Household Situation",
      "description" : "Extension complexe regroupant la situation familiale, la composition du foyer et sa description textuelle de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-human-name.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-human-name"
      },
      "name" : "TDDUI Human Name DataType",
      "description" : "French profile of datatype HumanName with constraints on prefix and suffix | Profilage du type de données HumanName pour prise en compte de la civilté au niveau de l'élément prefix et du titre au niveau de l'élément suffix",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-meal.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-meal"
      },
      "name" : "TDDUI Meal",
      "description" : "Repas du professionnel prévu dans le cadre de l'événement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-nationality.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-nationality"
      },
      "name" : "TDDUI Nationality Extension",
      "description" : "The nationality of the patient or a related person.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-observation-cause-mortalite.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-observation-cause-mortalite"
      },
      "name" : "TDDUI Observation Cause Mortalite",
      "description" : "Profil de la ressource Observation permettant de représenter les causes de mortalité d'un usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-tddui-observation-cause-mortalite-example.html"
      }],
      "reference" : {
        "reference" : "Observation/tddui-observation-cause-mortalite-example"
      },
      "name" : "TDDUI Observation Cause Mortalite Example",
      "description" : "Exemple de la ressource TDDUIObservationMortalite",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-observation-cause-mortalite"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-observation-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-observation-identifier"
      },
      "name" : "TDDUI Observation Identifier",
      "description" : "CodeSystem pour la définition des codes d'identifiant d'observation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-observation-mobilite-usager.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-observation-mobilite-usager"
      },
      "name" : "TDDUI Observation Mobilite Usager",
      "description" : "Profil de la ressource Observation permettant de représenter la mobilité de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-tddui-observation-mobilite-usager-example.html"
      }],
      "reference" : {
        "reference" : "Observation/tddui-observation-mobilite-usager-example"
      },
      "name" : "TDDUI Observation Mobilite Usager Example",
      "description" : "Exemple de la ressource TDDUIObservationMobiliteUsager",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-observation-mobilite-usager"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-observation-periode-scolaire.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-observation-periode-scolaire"
      },
      "name" : "TDDUI Observation Periode Scolaire",
      "description" : "Profil de la ressource Observation permettant de représenter la période scolaire de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-observation-periode-scolaire.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-observation-periode-scolaire"
      },
      "name" : "TDDUI Observation Periode Scolaire",
      "description" : "ValueSet pour l'Observation de la Période Scolaire.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-observation-periode-scolaire.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-observation-periode-scolaire"
      },
      "name" : "TDDUI Observation Periode Scolaire",
      "description" : "CodeSystem pour l'Observation de la Période Scolaire.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-tddui-observation-periodescolaire-example.html"
      }],
      "reference" : {
        "reference" : "Observation/tddui-observation-periodescolaire-example"
      },
      "name" : "TDDUI Observation PeriodeScolaire Example",
      "description" : "Exemple de la ressource TDDUIObservationPeriodeScolaire",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-observation-periode-scolaire"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-observation-repas.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-observation-repas"
      },
      "name" : "TDDUI Observation Repas",
      "description" : "Profil de la ressource Observation permettant de représenter si l'usager bénéficie ou non des repas.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-tddui-observation-repas-example.html"
      }],
      "reference" : {
        "reference" : "Observation/tddui-observation-repas-example"
      },
      "name" : "TDDUI Observation Repas Example",
      "description" : "Exemple de la ressource TDDUIObservationRepas",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-observation-repas"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-observation-identifier-repas.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-observation-identifier-repas"
      },
      "name" : "TDDUI Observation Repas Identifier",
      "description" : "ValueSet pour la définition des codes d'identifiant du repas",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-observation-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-observation-type"
      },
      "name" : "TDDUI Observation Type",
      "description" : "ValueSet pour les types d'Observation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-observation-type.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-observation-type"
      },
      "name" : "TDDUI Observation Type",
      "description" : "CodeSystem pour la défintion des types d'Observation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-organization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-organization"
      },
      "name" : "TDDUI Organization",
      "description" : "Profil de la ressource FRCoreOrganizationProfile permettant de représenter les entités juridiques.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-tddui-organization-example.html"
      }],
      "reference" : {
        "reference" : "Organization/tddui-organization-example"
      },
      "name" : "TDDUI Organization Example",
      "description" : "ESSMS - Les Chênes Verts",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-tddui-organization-origine-example.html"
      }],
      "reference" : {
        "reference" : "Organization/tddui-organization-origine-example"
      },
      "name" : "TDDUI Organization Origine Example",
      "description" : "ESSMS - Les Résidences du Lac",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-organization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-participant-present.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-participant-present"
      },
      "name" : "TDDUI Participant Present",
      "description" : "Indique la présence du participant à l'événement.\n- **Événement** :Indique la présence du participant à l'événement.\n- **Repas** : Indique la présence de l'usager au repas.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-patient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-patient"
      },
      "name" : "TDDUI Patient",
      "description" : "Profil de la ressource FrCorePatientProfile permettant de représenter un usager lorsque l'INS n'est pas transmis.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-tddui-patient-example.html"
      }],
      "reference" : {
        "reference" : "Patient/tddui-patient-example"
      },
      "name" : "TDDUI Patient Example",
      "description" : "Exemple de la ressource TDDUIPatient",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-patient-identifier.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-patient-identifier"
      },
      "name" : "TDDUI Patient Identifier",
      "description" : "ValueSet pour la définition des codes d'identifiant de l'usager",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-identifier"
      },
      "name" : "TDDUI Patient Identifier",
      "description" : "CodeSystem pour la définition des codes d'identifiant de l'usager",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-patient-ins.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-patient-ins"
      },
      "name" : "TDDUI Patient INS",
      "description" : "Profil de la ressource FRCorePatientINSProfile permettant de représenter un usager lorsque l'INS est transmis.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-tddui-patient-ins-example.html"
      }],
      "reference" : {
        "reference" : "Patient/tddui-patient-ins-example"
      },
      "name" : "TDDUI Patient INS Example",
      "description" : "Exemple de la ressource TDDUIPatientINS",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient-ins"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-patient-present.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-patient-present"
      },
      "name" : "TDDUI Patient Present",
      "description" : "\n- **Événement** : évènement nécessitant ou non la présence physique de l’usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-patient-validation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-patient-validation"
      },
      "name" : "TDDUI Patient Validation",
      "description" : "Validation par l'usager que l'événement a eu lieu.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-planned-absence.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-planned-absence"
      },
      "name" : "TDDUI Planned Absence",
      "description" : "Absence prévue",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-tddui-pp-ime-bundle-example.html"
      }],
      "reference" : {
        "reference" : "Bundle/tddui-pp-ime-bundle-example"
      },
      "name" : "TDDUI PP IME Bundle Example",
      "description" : "Exemple de bundle conforme au profil TDDUIBundle contenant le projet personnalisé en IME",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-bundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-tddui-pp-ime-careplan-example.html"
      }],
      "reference" : {
        "reference" : "CarePlan/tddui-pp-ime-careplan-example"
      },
      "name" : "TDDUI PP IME CarePlan Example",
      "description" : "Exemple du projet personnalisé d'un enfant en IME",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-projet-personnalise"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-tddui-pp-ime-consent-accord-example.html"
      }],
      "reference" : {
        "reference" : "Consent/tddui-pp-ime-consent-accord-example"
      },
      "name" : "TDDUI PP IME Consent Accord Example",
      "description" : "Exemple d'un accord de la structure",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-consent-accord"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-ime-goal-objectif-1-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-ime-goal-objectif-1-example"
      },
      "name" : "TDDUI PP IME Goal Objectif 1 Example",
      "description" : "Exemple d'un objectif dans le cadre du projet personnalisé en IME.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-ime-goal-objectif-2-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-ime-goal-objectif-2-example"
      },
      "name" : "TDDUI PP IME Goal Objectif 2 Example",
      "description" : "Exemple d'un objectif dans le cadre du projet personnalisé en IME.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-tddui-pp-ime-patient-example.html"
      }],
      "reference" : {
        "reference" : "Patient/tddui-pp-ime-patient-example"
      },
      "name" : "TDDUI PP IME Patient Example",
      "description" : "Exemple de la ressource TDDUIPatient dans le cadre d'un projet personnalisé en IME",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-ime-task-action-1-aesh-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-ime-task-action-1-aesh-example"
      },
      "name" : "TDDUI PP IME Task Action 1 AESH Example",
      "description" : "Exemple d'une action de l'objectif 1 réalisée par l'AESH dans le cadre du projet personnalisé en IME.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-ime-task-action-1-educ-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-ime-task-action-1-educ-example"
      },
      "name" : "TDDUI PP IME Task Action 1 Educ Example",
      "description" : "Exemple d'une action de l'objectif 1 réalisée par l'éducateur spécialisé dans le cadre du projet personnalisé en IME.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-tddui-pp-pa-bundle-example.html"
      }],
      "reference" : {
        "reference" : "Bundle/tddui-pp-pa-bundle-example"
      },
      "name" : "TDDUI PP PA Bundle Example",
      "description" : "Exemple de bundle conforme au profil TDDUIBundle contenant le projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-bundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-tddui-pp-pa-careplan-example.html"
      }],
      "reference" : {
        "reference" : "CarePlan/tddui-pp-pa-careplan-example"
      },
      "name" : "TDDUI PP PA CarePlan Example",
      "description" : "Exemple d'un projet personnalisé PA",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-careplan-projet-personnalise"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-tddui-pp-pa-consent-accord-example.html"
      }],
      "reference" : {
        "reference" : "Consent/tddui-pp-pa-consent-accord-example"
      },
      "name" : "TDDUI PP PA Consent Accord Example",
      "description" : "Exemple d'un accord de la structure",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-consent-accord"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-tddui-pp-pa-documentreference-bilan-objectif-1-example.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/tddui-pp-pa-documentreference-bilan-objectif-1-example"
      },
      "name" : "TDDUI PP PA DocumentReference Bilan Objectif 1 Example",
      "description" : "Bilan de l'objectif 1 du projet personnalisé PA au format PDF",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-tddui-pp-pa-documentreference-entrant-example.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/tddui-pp-pa-documentreference-entrant-example"
      },
      "name" : "TDDUI PP PA DocumentReference Entrant Example",
      "description" : "Entrant Projet Personnalisé PA au format PDF",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-document-reference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-pa-goal-attente-famille-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-pa-goal-attente-famille-example"
      },
      "name" : "TDDUI PP PA Goal Attente Famille Example",
      "description" : "Exemple des attentes de la famille dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-attente"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-pa-goal-attente-usager-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-pa-goal-attente-usager-example"
      },
      "name" : "TDDUI PP PA Goal Attente Usager Example",
      "description" : "Exemple des attentes de l'usager dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-attente"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-pa-goal-objectif-1-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-pa-goal-objectif-1-example"
      },
      "name" : "TDDUI PP PA Goal Objectif 1 Example",
      "description" : "Exemple d'un objectif dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-pa-goal-objectif-2-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-pa-goal-objectif-2-example"
      },
      "name" : "TDDUI PP PA Goal Objectif 2 Example",
      "description" : "Exemple d'un objectif dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Goal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Goal-tddui-pp-pa-goal-objectif-3-example.html"
      }],
      "reference" : {
        "reference" : "Goal/tddui-pp-pa-goal-objectif-3-example"
      },
      "name" : "TDDUI PP PA Goal Objectif 3 Example",
      "description" : "Exemple d'un objectif dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-goal-objectif"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-tddui-pp-pa-patient-example-pp.html"
      }],
      "reference" : {
        "reference" : "Patient/tddui-pp-pa-patient-example-pp"
      },
      "name" : "TDDUI PP PA Patient Example",
      "description" : "Exemple de la ressource TDDUIPatient dans le cadre d'un projet personnalisé PA",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-tddui-pp-pa-practitioner-ide-example.html"
      }],
      "reference" : {
        "reference" : "Practitioner/tddui-pp-pa-practitioner-ide-example"
      },
      "name" : "TDDUI PP PA Practitioner IDE Example",
      "description" : "Exemple d'un IDE",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-tddui-pp-pa-questionnaire-response-aggir-pa-example.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/tddui-pp-pa-questionnaire-response-aggir-pa-example"
      },
      "name" : "TDDUI PP PA Questionnaire Response AGGIR PA Example",
      "description" : "Grille de réponse AGGIR PA",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-tddui-pp-pa-servicerequest-besoin-1-example.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/tddui-pp-pa-servicerequest-besoin-1-example"
      },
      "name" : "TDDUI PP PA ServiceRequest Besoin 1 Example",
      "description" : "Exemple d'un besoin de l'usager dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-tddui-pp-pa-servicerequest-besoin-2-example.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/tddui-pp-pa-servicerequest-besoin-2-example"
      },
      "name" : "TDDUI PP PA ServiceRequest Besoin 2 Example",
      "description" : "Exemple d'un besoin de l'usager dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-tddui-pp-pa-servicerequest-besoin-3-example.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/tddui-pp-pa-servicerequest-besoin-3-example"
      },
      "name" : "TDDUI PP PA ServiceRequest Besoin 3 Example",
      "description" : "Exemple d'un besoin de l'usager dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-besoin"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-action-1-ergo-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-action-1-ergo-example"
      },
      "name" : "TDDUI PP PA Task Action 1 Ergo Example",
      "description" : "Exemple d'une action de l'objectif 1 réalisée par l'ergothérapeute dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-action-1-ide-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-action-1-ide-example"
      },
      "name" : "TDDUI PP PA Task Action 1 IDE Example",
      "description" : "Exemple d'une action de l'objectif 1 réalisée par l'IDE dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-action-1-kine-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-action-1-kine-example"
      },
      "name" : "TDDUI PP PA Task Action 1 Kine Example",
      "description" : "Exemple d'une action de l'objectif 1 réalisée par le kinésithérapeute dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-action-2-anim-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-action-2-anim-example"
      },
      "name" : "TDDUI PP PA Task Action 2 Anim Example",
      "description" : "Exemple d'une action de l'objectif 1 réalisée par l'animatrice dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-action-2-ide-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-action-2-ide-example"
      },
      "name" : "TDDUI PP PA Task Action 2 IDE Example",
      "description" : "Exemple d'une action de l'objectif 2 réalisée par l'IDE dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-action-3-psy-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-action-3-psy-example"
      },
      "name" : "TDDUI PP PA Task Action 3 Psy Example",
      "description" : "Exemple d'une action de l'objectif 3 réalisée par le psychologue dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-action"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-moyen-ressource-ergo-1-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-moyen-ressource-ergo-1-example"
      },
      "name" : "TDDUI PP PA Task Moyen Ressource Ergo 1 Example",
      "description" : "Exemple des moyens et ressources de l'objectif 1 dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-moyen-ressource-ide-1-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-moyen-ressource-ide-1-example"
      },
      "name" : "TDDUI PP PA Task Moyen Ressource IDE 1 Example",
      "description" : "Exemple des moyens et ressources de l'objectif 1 dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-moyen-ressource-ide-2-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-moyen-ressource-ide-2-example"
      },
      "name" : "TDDUI PP PA Task Moyen Ressource IDE 2 Example",
      "description" : "Exemple des moyens et ressources de l'objectif 2 dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-pp-pa-task-moyen-ressource-kine-1-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-pp-pa-task-moyen-ressource-kine-1-example"
      },
      "name" : "TDDUI PP PA Task Moyen Ressource Kine 1 Example",
      "description" : "Exemple des moyens et ressources de l'objectif 1 dans le cadre du projet personnalisé PA.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-moyen-ressource"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-practitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-practitioner"
      },
      "name" : "TDDUI Practitioner",
      "description" : "Profil de la ressource FRCorePractitionerProfile permettant de représenter un professionnel du médicosocial dans le cadre de TDDUI. Le profil AsPractitionerRoleProfile n'a pas été utilisé car il comportait trop de contraintes non présentes dans les DUI.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-tddui-practitioner-example.html"
      }],
      "reference" : {
        "reference" : "Practitioner/tddui-practitioner-example"
      },
      "name" : "TDDUI Practitioner Example",
      "description" : "Exemple d'un professionnel de santé",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-practitioner-role.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-practitioner-role"
      },
      "name" : "TDDUI Practitioner Role",
      "description" : "Profil de la ressource FRCorePractitionerRole permettant de représenter un Professionnel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-tddui-practitioner-role-example.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/tddui-practitioner-role-example"
      },
      "name" : "TDDUI Practitioner Role Example",
      "description" : "Exemple d'un professionnel de santé",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-profession.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-profession"
      },
      "name" : "TDDUI Profession",
      "description" : "Extension permettant de représenter la profession du professionnel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-qr-participant.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-qr-participant"
      },
      "name" : "TDDUI QR Participant",
      "description" : "Extension permettant d'ajouter le responsable et le porteur de l'évaluation dans un QuestionnaireResponse.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-tddui-questionnaire-response-aggir-pa-example.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/tddui-questionnaire-response-aggir-pa-example"
      },
      "name" : "TDDUI Questionnaire Response AGGIR PA Example",
      "description" : "Grille de réponse AGGIR PA",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-tddui-questionnaire-response-aggir-ph-example.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/tddui-questionnaire-response-aggir-ph-example"
      },
      "name" : "TDDUI Questionnaire Response AGGIR PH Example",
      "description" : "Grille de réponse AGGIR PH",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-tddui-questionnaire-response-serafin-precision-example.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/tddui-questionnaire-response-serafin-precision-example"
      },
      "name" : "TDDUI Questionnaire Response SERAFIN Precision Example",
      "description" : "Evaluation SERAFIN pour un besoin d'hébergement adapté avec précision",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-tddui-questionnaire-response-serafin-sans-precision-example.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/tddui-questionnaire-response-serafin-sans-precision-example"
      },
      "name" : "TDDUI Questionnaire Response SERAFIN Sans Precision Example",
      "description" : "Evaluation SERAFIN pour un besoin d'hébergement adapté sans précision",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-tddui-questionnaire-response-situation-ssiad-example.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/tddui-questionnaire-response-situation-ssiad-example"
      },
      "name" : "TDDUI Questionnaire Response Situation SSIAD Example",
      "description" : "Grille de réponse de la situation SSIAD",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-questionnaire-response"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-questionnaire-response.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-questionnaire-response"
      },
      "name" : "TDDUI QuestionnaireResponse",
      "description" : "Profil de la ressource QuestionnaireResponse utilisé pour transmettre les réponses aux questionnaires dans le cadre des évaluations.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RelatedPerson"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RelatedPerson-tddui-related-person-contact-example.html"
      }],
      "reference" : {
        "reference" : "RelatedPerson/tddui-related-person-contact-example"
      },
      "name" : "TDDUI Related Person Contact Example",
      "description" : "Exemple d'un contact.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-related-person-contact"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-contact-related-person-relashionship.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-contact-related-person-relashionship"
      },
      "name" : "TDDUI Related Person Relashionship",
      "description" : "ValueSet définissant les slices de RelatedPerson.relationship.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-related-person-contact.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-related-person-contact"
      },
      "name" : "TDDUI RelatedPerson Contact",
      "description" : "Profil de la ressource FRCoreRelatedPersonProfile permettant de représenter un contact de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-ressources-used.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-ressources-used"
      },
      "name" : "TDDUI Ressources Used",
      "description" : "Ressources utilisées lors de l’évènement (ex : chambre, matériel médical, véhicule).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-schedule.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-schedule"
      },
      "name" : "TDDUI Schedule",
      "description" : "Profil de la ressource FRCoreScheduleProfile permettant de contenir l'ensemble des présences et absences de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Schedule"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Schedule-tddui-schedule-example.html"
      }],
      "reference" : {
        "reference" : "Schedule/tddui-schedule-example"
      },
      "name" : "TDDUI Schedule Example",
      "description" : "Exemple de la ressource TDDUISchedule.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-schedule"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-serafin.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-serafin"
      },
      "name" : "TDDUI SERAFIN",
      "description" : "ValueSet contenant les codes SERAFIN (prestations directes et indirectes) pour le profil TDDUI Encounter Evenement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-service-request-besoin.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-service-request-besoin"
      },
      "name" : "TDDUI ServiceRequest Besoin",
      "description" : "Profil de la ressource ServiceRequest permettant de représenter les besoins de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-service-request-identifier-besoin.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-service-request-identifier-besoin"
      },
      "name" : "TDDUI ServiceRequest Besoin Identifier",
      "description" : "ValueSet pour la définition des codes d'identifiant de besoin",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-service-request-demande-orientation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-service-request-demande-orientation"
      },
      "name" : "TDDUI ServiceRequest DemandeOrientation",
      "description" : "Profil de la ressource ServiceRequest permettant de représenter la demande d'orientation adressée à la CDAPH.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-tddui-service-request-demande-orientation-example.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/tddui-service-request-demande-orientation-example"
      },
      "name" : "TDDUI ServiceRequest DemandeOrientation Example",
      "description" : "Exemple d'une demande d'orientation.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-service-request-demande-orientation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-service-request-identifier-demande-orientation.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-service-request-identifier-demande-orientation"
      },
      "name" : "TDDUI ServiceRequest DemandeOrientation Identifier",
      "description" : "ValueSet pour la définition des codes d'identifiant de demande d'orientation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-service-request-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-service-request-identifier"
      },
      "name" : "TDDUI ServiceRequest Identifier",
      "description" : "CodeSystem pour la définition des codes d'identifiant des observations",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-servicerequest-supportinginfo.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-servicerequest-supportinginfo"
      },
      "name" : "TDDUI ServiceRequest SupportingInfo",
      "description" : "ValueSet définissant les types d'objet binaire de la demande d'orientation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-slot-identifier.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-slot-identifier"
      },
      "name" : "TDDUI Slot Identifier",
      "description" : "CodeSystem pour la définition des codes d'identifiant de la ressource Slot",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-slot-identifier-presence-absence.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-slot-identifier-presence-absence"
      },
      "name" : "TDDUI Slot Identifier Presence Absence",
      "description" : "ValueSet définissant les types d'identifiants pour la ressource SlotPresenceAbsence.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-slot-presence-absence.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-slot-presence-absence"
      },
      "name" : "TDDUI Slot Presence Absence",
      "description" : "Profil de la ressource FRCoreSlotProfile permettant de représenter les présences et absences de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Slot"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Slot-tddui-slot-presence-absence-example.html"
      }],
      "reference" : {
        "reference" : "Slot/tddui-slot-presence-absence-example"
      },
      "name" : "TDDUI Slot PresenceAbsence Example",
      "description" : "Exemple de la ressource TDDUISlotPresenceAbsence.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-slot-presence-absence"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-status-author.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-status-author"
      },
      "name" : "TDDUI Status Author",
      "description" : "Extension permettant de représenter l'auteur du statut.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-action.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-action"
      },
      "name" : "TDDUI Task Action",
      "description" : "Profil de la ressource Task permettant de représenter les actions réalisées dans le cadre du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-bilan.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-bilan"
      },
      "name" : "TDDUI Task Bilan",
      "description" : "Profil de la ressource Task permettant de représenter le bilan du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-task-input-action.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-task-input-action"
      },
      "name" : "TDDUI Task Input Action",
      "description" : "ValueSet pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les actions du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-task-input-action.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-task-input-action"
      },
      "name" : "TDDUI Task Input Action",
      "description" : "CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les actions du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-task-input-bilan.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-task-input-bilan"
      },
      "name" : "TDDUI Task Input Bilan",
      "description" : "ValueSet pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour le bilan du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-task-input-bilan.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-task-input-bilan"
      },
      "name" : "TDDUI Task Input Bilan",
      "description" : "CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour le bilan du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-task-input-moyen-ressource.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-task-input-moyen-ressource"
      },
      "name" : "TDDUI Task Input Moyen Ressource",
      "description" : "ValueSet  pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les moyens et ressources du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-task-input-moyen-ressource.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-task-input-moyen-ressource"
      },
      "name" : "TDDUI Task Input Moyen Ressource",
      "description" : "CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les moyens et ressources du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-task-input-prestation.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-task-input-prestation"
      },
      "name" : "TDDUI Task Input Prestation",
      "description" : "ValueSet pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les prestations du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-task-input-prestation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-task-input-prestation"
      },
      "name" : "TDDUI Task Input Prestation",
      "description" : "CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les prestations du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-task-input-transport.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-task-input-transport"
      },
      "name" : "TDDUI Task Input Transport",
      "description" : "ValueSet pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les transports dans le cadre du DUI.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-task-input-transport.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-task-input-transport"
      },
      "name" : "TDDUI Task Input Transport",
      "description" : "CodeSystem pour la définition des éléments spécifiques des input dans la ressource Task utilisée pour les transports dans le cadre du DUI.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-moyen-ressource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-moyen-ressource"
      },
      "name" : "TDDUI Task MoyenRessource",
      "description" : "Profil de la ressource Task permettant de représenter les moyens ou ressources utilisées dans le cadre du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-tddui-task-output-bilan.html"
      }],
      "reference" : {
        "reference" : "ValueSet/tddui-task-output-bilan"
      },
      "name" : "TDDUI Task Output Bilan",
      "description" : "ValueSet pour la définition des éléments spécifiques des output dans la ressource Task utilisée pour le bilan du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-tddui-task-output-bilan.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/tddui-task-output-bilan"
      },
      "name" : "TDDUI Task Output Bilan",
      "description" : "CodeSystem pour la définition des éléments spécifiques des output dans la ressource Task utilisée pour le bilan du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-prestation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-prestation"
      },
      "name" : "TDDUI Task Prestation",
      "description" : "Profil de la ressource Task permettant de représenter les prestations du projet personnalisé.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-transport.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-transport"
      },
      "name" : "TDDUI Task Transport",
      "description" : "Profil de la ressource Task permettant de représenter le transport.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-task-transport-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-task-transport-example"
      },
      "name" : "TDDUI Task Transport Example",
      "description" : "Exemple du transport.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-transport"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-task-transport-professionel-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-task-transport-professionel-example"
      },
      "name" : "TDDUI Task Transport Professionel Example",
      "description" : "Exemple du transport du professionnel.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-transport-professionnel"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-transport-professionnel.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-transport-professionnel"
      },
      "name" : "TDDUI Task Transport Professionnel",
      "description" : "Profil de la ressource TDDUITaskTransport permettant de représenter le transport du professionnel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-tddui-task-transport-usager.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/tddui-task-transport-usager"
      },
      "name" : "TDDUI Task Transport Usager",
      "description" : "Profil de la ressource TDDUITaskTransport permettant de représenter le transport de l'usager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Task-tddui-task-transport-usager-example.html"
      }],
      "reference" : {
        "reference" : "Task/tddui-task-transport-usager-example"
      },
      "name" : "TDDUI Task Transport Usager Example",
      "description" : "Exemple du transport de l'usager.",
      "exampleCanonical" : "https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-task-transport-usager"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-TDDUIConsommateur.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/TDDUIConsommateur"
      },
      "name" : "TDDUI-Consommateur",
      "description" : "Le rôle du Consommateur est de recueillir les données d'un logiciel DUI. Il correspond à un SI tiers.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-TDDUIProducteur.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/TDDUIProducteur"
      },
      "name" : "TDDUI-Producteur",
      "description" : "Le rôle de Producteur est de transmettre des données de son logiciel DUI. Il correspond à un logiciel DUI.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-tddui-questionnaire-aggir-pa-ssiad.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/tddui-questionnaire-aggir-pa-ssiad"
      },
      "name" : "Évaluation AGGIR PA SSIAD",
      "description" : "Grille d'évaluation AGGIR PA SSIAD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-tddui-questionnaire-aggir-ph-ssiad.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/tddui-questionnaire-aggir-ph-ssiad"
      },
      "name" : "Évaluation AGGIR PH SSIAD",
      "description" : "Grille d'évaluation AGGIR PH SSIAD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-tddui-questionnaire-situation-ssiad.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/tddui-questionnaire-situation-ssiad"
      },
      "name" : "Évaluation de la situation SSIAD",
      "description" : "Grille d'évaluation de la situation SSIAD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-tddui-questionnaire-serafin.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/tddui-questionnaire-serafin"
      },
      "name" : "Évaluation SERAFIN",
      "description" : "Grille d'évaluation SERAFIN",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Accueil",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "sfe.html"
        }],
        "nameUrl" : "sfe.html",
        "title" : "Volume 1 - Etude fonctionnelle",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "sfe_cas_usage.html"
          }],
          "nameUrl" : "sfe_cas_usage.html",
          "title" : "Cas d'usage",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "sfe_organisation_contexte_metier.html"
          }],
          "nameUrl" : "sfe_organisation_contexte_metier.html",
          "title" : "Organisation du contexte métier",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "sfe_transfert_des_donnees_a_un_tiers.html"
          }],
          "nameUrl" : "sfe_transfert_des_donnees_a_un_tiers.html",
          "title" : "Transfert des données à un tiers",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "sfe_modelisation_contenu.html"
          }],
          "nameUrl" : "sfe_modelisation_contenu.html",
          "title" : "Modélisation du contenu du DUI",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "description_flux.html"
        }],
        "nameUrl" : "description_flux.html",
        "title" : "Volume 2 - Détail des transactions",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "description_flux_synthese.html"
          }],
          "nameUrl" : "description_flux_synthese.html",
          "title" : "Synthèse des flux",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "description_flux_1_transmission_donnees_dui.html"
          }],
          "nameUrl" : "description_flux_1_transmission_donnees_dui.html",
          "title" : "Flux 1 - Transmission de données DUI",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "tests.html"
        }],
        "nameUrl" : "tests.html",
        "title" : "Solutions de tests",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "annexes.html"
        }],
        "nameUrl" : "annexes.html",
        "title" : "Annexes",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "mapping_fonctionnel_FHIR.html"
          }],
          "nameUrl" : "mapping_fonctionnel_FHIR.html",
          "title" : "Mapping FHIR du modèle de contenu DUI",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "annexes_documents_reference.html"
          }],
          "nameUrl" : "annexes_documents_reference.html",
          "title" : "Documents de référence",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "annexes_acronymes.html"
          }],
          "nameUrl" : "annexes_acronymes.html",
          "title" : "Acronymes",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "annexes_codes_professions_roles_modes_exercices.html"
          }],
          "nameUrl" : "annexes_codes_professions_roles_modes_exercices.html",
          "title" : "Professions du médico-social",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "securite.html"
          }],
          "nameUrl" : "securite.html",
          "title" : "Sécurité",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "downloads.html"
          }],
          "nameUrl" : "downloads.html",
          "title" : "Téléchargements et usages",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "problematiques_connues.html"
        }],
        "nameUrl" : "problematiques_connues.html",
        "title" : "Problématiques connues",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changes.html"
        }],
        "nameUrl" : "changes.html",
        "title" : "Historique des changements",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "translationinfo.html"
        }],
        "nameUrl" : "translationinfo.html",
        "title" : "Informations sur la traduction",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```

# TDDUI Observation Periode Scolaire - Médicosocial - Transfert de données DUI v2.4.0

## CodeSystem: TDDUI Observation Periode Scolaire 

 
CodeSystem pour l'Observation de la Période Scolaire. 

Ce système de codes est référencé dans la définition des ensembles de valeurs suivants :

* [TDDUIObservationPeriodeScolaire](ValueSet-tddui-observation-periode-scolaire.md)

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "tddui-observation-periode-scolaire",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://interop.esante.gouv.fr/ig/fhir/tddui/CodeSystem/tddui-observation-periode-scolaire",
  "version" : "2.4.0",
  "name" : "TDDUIObservationPeriodeScolaire",
  "title" : "TDDUI Observation Periode Scolaire",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-22T12:30:17+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "CodeSystem pour l'Observation de la Période Scolaire.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "typeEnseignementSpecialise",
    "display" : "Type enseignement spécialisé"
  },
  {
    "code" : "diplome",
    "display" : "Diplôme"
  },
  {
    "code" : "volumeScolarisation",
    "display" : "Volume de scolarisation"
  }]
}

```

# Annexes - Médicosocial - Transfert de données DUI v2.4.0-ballot

## Annexes

* [Mapping FHIR du modèle de contenu DUI](mapping_fonctionnel_FHIR.md)
* [Documents de référence](annexes_documents_reference.md)
* [Acronymes](annexes_acronymes.md)
* [Sécurité](securite.md)
* [Télerchargement et usages](downloads.md)


# Solutions de tests - Médicosocial - Transfert de données DUI v2.4.0-tru

## Solutions de tests

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Validateurs FHIR

La plateforme de test [EVSClient](https://interop.esante.gouv.fr/evs/default/validator.seam?standard=61) propose un validateur FHIR par profil défini dans ce guide d'implémentation (cf onglet [Ressources de conformité](artifacts.md)).

La documentation de l'outil EVSClient est accessible [ici](https://interop.esante.gouv.fr/gazelle-documentation/EVS-Client/user.html).

### Guide ANS

Le guide d'implémentation de l'ANS décrit sur [cette page](https://interop.esante.gouv.fr/ig/documentation/tests.html) les différents outils de tests à disposition.

